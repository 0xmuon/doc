"""Unit tests for AuthService (fake user repository, real hashing and JWT)."""

import pytest

from app.core import ConflictError, ForbiddenError, UnauthorizedError
from app.core.security import verify_password
from app.models import UserRole
from app.schemas import UserRegister
from app.services import AuthService
from tests.fakes import FakeUserRepository

pytestmark = pytest.mark.anyio


def new_user(**changes) -> UserRegister:
    data = {"username": "Anna", "email": "Anna@Example.com", "full_name": "Anna K", "password": "secret123"}
    return UserRegister(**{**data, **changes})


@pytest.fixture
def service() -> AuthService:
    return AuthService(FakeUserRepository())  # type: ignore[arg-type]


async def test_register_hashes_the_password_and_lowercases(service):
    user = await service.register(new_user())

    assert (user.username, user.email, user.role) == ("anna", "anna@example.com", UserRole.CUSTOMER)
    assert user.hashed_password != "secret123"
    assert verify_password("secret123", user.hashed_password)


async def test_duplicate_username_ignores_case(service):
    await service.register(new_user())

    with pytest.raises(ConflictError):
        await service.register(new_user(username="ANNA", email="other@example.com"))


async def test_duplicate_email_is_rejected(service):
    await service.register(new_user())

    with pytest.raises(ConflictError):
        await service.register(new_user(username="other", email="anna@example.com"))


async def test_login_returns_tokens_that_identify_the_user(service):
    await service.register(new_user())

    tokens = await service.login("anna", "secret123")

    assert (await service.get_user_from_token(tokens.access_token)).username == "anna"
    assert (await service.refresh(tokens.refresh_token)).access_token


async def test_wrong_password_is_rejected(service):
    await service.register(new_user())

    with pytest.raises(UnauthorizedError):
        await service.login("anna", "wrong")


async def test_unknown_user_is_rejected_with_the_same_message(service):
    with pytest.raises(UnauthorizedError, match="Incorrect username or password"):
        await service.login("nobody", "secret123")


async def test_disabled_user_cannot_log_in(service):
    user = await service.register(new_user())
    user.is_active = False

    with pytest.raises(ForbiddenError):
        await service.login("anna", "secret123")
