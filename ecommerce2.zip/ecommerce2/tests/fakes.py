"""
Fakes: in-memory stand-ins for repositories and external services (MOCKING dependencies).

Student notes:
- A service only needs an object with the right METHODS (duck typing), so a dict-backed
  fake works in place of the real repository. Unit tests then need no database: they are
  fast, repeatable, and test only the business rules.
- FakePaymentGateway / FakeNotifier replace the HTTP clients: no network in tests, and each
  test picks the gateway's behaviour ("approve", "decline", "down").
"""

from app.integrations import PaymentDeclinedError, PaymentGatewayError
from app.models import CartItem, Category, Order, OrderStatus, Product, User


class FakeRepository:
    """commit does nothing: the dicts ARE the 'database'."""

    async def commit(self) -> None:
        pass


class FakeUserRepository(FakeRepository):
    def __init__(self):
        self.rows: dict[int, User] = {}

    async def get_by_id(self, user_id: int) -> User | None:
        return self.rows.get(user_id)

    async def get_by_username(self, username: str) -> User | None:
        return next((u for u in self.rows.values() if u.username == username), None)

    async def get_by_email(self, email: str) -> User | None:
        return next((u for u in self.rows.values() if u.email == email), None)

    async def add(self, user: User) -> User:
        user.id = len(self.rows) + 1
        self.rows[user.id] = user
        return user

    async def save(self, user: User) -> User:
        return user


class FakeCategoryRepository(FakeRepository):
    def __init__(self):
        self.rows: dict[int, Category] = {}

    async def get_by_id(self, category_id: int) -> Category | None:
        return self.rows.get(category_id)

    async def get_by_name(self, name: str) -> Category | None:
        return next((c for c in self.rows.values() if c.name.lower() == name.lower()), None)

    async def get_all(self, active_only: bool = True) -> list[Category]:
        return [c for c in self.rows.values() if c.is_active or not active_only]

    async def add(self, category: Category) -> Category:
        category.id = len(self.rows) + 1
        self.rows[category.id] = category
        return category

    async def save(self, category: Category) -> Category:
        return category


class FakeProductRepository(FakeRepository):
    def __init__(self):
        self.rows: dict[int, Product] = {}

    async def get_by_id(self, product_id: int) -> Product | None:
        return self.rows.get(product_id)

    async def get_by_sku(self, sku: str) -> Product | None:
        return next((p for p in self.rows.values() if p.sku == sku), None)

    async def list_active(self, *, category_id=None, skip=0, limit=20) -> list[Product]:
        found = [p for p in self.rows.values() if p.is_active and category_id in (None, p.category_id)]
        return found[skip : skip + limit]

    async def search(self, *, text=None, category_id=None, min_price=None, max_price=None, skip=0, limit=20):
        found = [
            p
            for p in self.rows.values()
            if p.is_active
            and (not text or text.lower() in (p.name + " " + p.description).lower())
            and category_id in (None, p.category_id)
            and (min_price is None or p.price >= min_price)
            and (max_price is None or p.price <= max_price)
        ]
        return found[skip : skip + limit]

    async def get_many_for_update(self, product_ids: list[int]) -> dict[int, Product]:
        return {pid: self.rows[pid] for pid in product_ids if pid in self.rows}

    async def add(self, product: Product) -> Product:
        product.id = len(self.rows) + 1
        self.rows[product.id] = product
        return product

    async def save(self, product: Product) -> Product:
        return product


class FakeCartRepository(FakeRepository):
    def __init__(self):
        self.rows: dict[int, CartItem] = {}
        self.next_id = 1

    async def get_by_id(self, item_id: int) -> CartItem | None:
        return self.rows.get(item_id)

    async def get_for_user(self, user_id: int) -> list[CartItem]:
        return [i for i in self.rows.values() if i.user_id == user_id]

    async def get_line(self, user_id: int, product_id: int) -> CartItem | None:
        return next((i for i in self.rows.values() if i.user_id == user_id and i.product_id == product_id), None)

    async def add(self, item: CartItem) -> CartItem:
        item.id = self.next_id
        self.next_id += 1
        self.rows[item.id] = item
        return item

    async def save(self, item: CartItem) -> CartItem:
        return item

    async def delete(self, item: CartItem) -> None:
        del self.rows[item.id]

    async def clear_for_user(self, user_id: int) -> None:
        for item_id in [i.id for i in self.rows.values() if i.user_id == user_id]:
            del self.rows[item_id]


class FakeOrderRepository(FakeRepository):
    def __init__(self):
        self.rows: dict[int, Order] = {}

    async def get_by_id(self, order_id: int) -> Order | None:
        return self.rows.get(order_id)

    async def list_for_user(self, user_id: int) -> list[Order]:
        return [o for o in reversed(self.rows.values()) if o.user_id == user_id]

    async def list_all(self, status: OrderStatus | None = None) -> list[Order]:
        return [o for o in reversed(self.rows.values()) if status in (None, o.status)]

    async def add_pending(self, order: Order) -> Order:
        order.id = len(self.rows) + 1
        self.rows[order.id] = order
        return order

    async def save(self, order: Order) -> Order:
        return order


class FakePaymentGateway:
    """mode: "approve" (default), "decline" (card refused) or "down" (unreachable)."""

    def __init__(self, mode: str = "approve"):
        self.mode = mode
        self.charges: list[tuple[str, object]] = []

    async def charge(self, order_number, amount, currency="INR") -> str:
        self.charges.append((order_number, amount))
        if self.mode == "down":
            raise PaymentGatewayError("payment gateway timed out")
        if self.mode == "decline":
            raise PaymentDeclinedError("Card declined by the issuing bank")
        return f"PAY-TEST{len(self.charges):04d}"


class FakeNotifier:
    """Records what would have been sent. fail=True simulates a broken mail service."""

    def __init__(self, fail: bool = False):
        self.fail = fail
        self.sent: list[dict] = []

    async def send(self, to: str, subject: str, message: str) -> None:
        if self.fail:
            from app.integrations import NotificationError

            raise NotificationError("notification service is down")
        self.sent.append({"to": to, "subject": subject, "message": message})
