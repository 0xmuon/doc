"""
API tests for authentication: register, login, refresh, protected routes (security validations).
"""

from datetime import timedelta

import pytest

from app.core.security import ACCESS, create_refresh_token, create_token
from tests.conftest import create_user

pytestmark = [pytest.mark.anyio, pytest.mark.integration]

NEW_USER = {"username": "Kavya.R", "email": "Kavya@Example.com", "full_name": "Kavya R", "password": "kavya1234"}


async def log_in(client, username: str, password: str):
    """The OAuth2 password flow: username and password as a FORM, not JSON."""
    return await client.post("/api/auth/login", data={"username": username, "password": password})


def bearer(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


async def test_register_creates_a_customer(client):
    response = await client.post("/api/auth/register", json=NEW_USER)

    assert response.status_code == 201
    body = response.json()
    assert body["username"] == "kavya.r"  # stored in lower case
    assert body["email"] == "kavya@example.com"
    assert body["role"] == "customer"  # self-registration is always a customer
    assert "password" not in body and "hashed_password" not in body


async def test_register_duplicate_is_409(client):
    await client.post("/api/auth/register", json=NEW_USER)

    response = await client.post("/api/auth/register", json={**NEW_USER, "email": "other@example.com"})

    assert response.status_code == 409


async def test_register_invalid_input_is_422_with_request_id(client):
    response = await client.post("/api/auth/register", json={**NEW_USER, "email": "not-an-email", "password": "x"})

    assert response.status_code == 422
    assert response.json()["request_id"] == response.headers["X-Request-ID"]  # traceable error


async def test_login_and_me(client, db):
    await create_user(db, "anna", password="anna1234")

    tokens = (await log_in(client, "Anna", "anna1234")).json()  # username is case-insensitive
    response = await client.get("/api/auth/me", headers=bearer(tokens["access_token"]))

    assert tokens["token_type"] == "bearer"
    assert response.status_code == 200
    assert response.json()["username"] == "anna"


async def test_wrong_password_is_401(client, db):
    await create_user(db, "anna", password="anna1234")

    response = await log_in(client, "anna", "wrong-password")

    assert response.status_code == 401
    assert response.headers["WWW-Authenticate"] == "Bearer"


async def test_protected_route_without_token_is_401(client):
    response = await client.get("/api/auth/me")

    assert response.status_code == 401
    assert "request_id" in response.json()


async def test_bad_token_is_401(client):
    response = await client.get("/api/auth/me", headers=bearer("not-a-token"))

    assert response.status_code == 401


async def test_expired_token_is_401(client, db):
    await create_user(db, "anna")
    expired = create_token("anna", ACCESS, timedelta(seconds=-1))

    response = await client.get("/api/auth/me", headers=bearer(expired))

    assert response.status_code == 401
    assert response.json()["detail"] == "Token has expired"


async def test_refresh_gives_a_new_token_pair(client, db):
    await create_user(db, "anna", password="anna1234")
    tokens = (await log_in(client, "anna", "anna1234")).json()

    response = await client.post("/api/auth/refresh", json={"refresh_token": tokens["refresh_token"]})

    assert response.status_code == 200
    me = await client.get("/api/auth/me", headers=bearer(response.json()["access_token"]))
    assert me.json()["username"] == "anna"


async def test_tokens_are_not_interchangeable(client, db):
    await create_user(db, "anna", password="anna1234")
    tokens = (await log_in(client, "anna", "anna1234")).json()

    refresh_with_access = await client.post("/api/auth/refresh", json={"refresh_token": tokens["access_token"]})
    me_with_refresh = await client.get("/api/auth/me", headers=bearer(create_refresh_token("anna")))

    assert refresh_with_access.status_code == 401
    assert me_with_refresh.status_code == 401


async def test_disabled_user_cannot_log_in(client, db):
    await create_user(db, "anna", password="anna1234", active=False)

    response = await log_in(client, "anna", "anna1234")

    assert response.status_code == 403
