"""Unit tests for CartService: business rules only, with fake repositories (no database)."""

from decimal import Decimal

import pytest

from app.core import BusinessRuleError, ConflictError, NotFoundError
from app.models import Product
from app.schemas import CartAdd, CartUpdate
from app.services import CartService
from tests.fakes import FakeCartRepository, FakeProductRepository

pytestmark = pytest.mark.anyio

USER_ID = 1


@pytest.fixture
def service() -> CartService:
    products = FakeProductRepository()
    products.rows[1] = Product(
        id=1, sku="ELEC-001", name="Headphones", price=Decimal("499.00"), stock=5, category_id=1, is_active=True
    )
    return CartService(FakeCartRepository(), products)  # type: ignore[arg-type]


async def test_add_creates_a_line(service):
    cart = await service.add_item(USER_ID, CartAdd(product_id=1, quantity=2))

    assert [(line.product_id, line.quantity) for line in cart] == [(1, 2)]


async def test_add_again_increases_the_quantity(service):
    await service.add_item(USER_ID, CartAdd(product_id=1, quantity=2))

    cart = await service.add_item(USER_ID, CartAdd(product_id=1, quantity=1))

    assert [line.quantity for line in cart] == [3]


async def test_more_than_stock_is_rejected(service):
    with pytest.raises(ConflictError):
        await service.add_item(USER_ID, CartAdd(product_id=1, quantity=6))


async def test_more_than_the_per_product_limit_is_rejected(service):
    service.products.rows[1].stock = 100

    with pytest.raises(BusinessRuleError):
        await service.add_item(USER_ID, CartAdd(product_id=1, quantity=11))


async def test_inactive_product_is_not_found(service):
    service.products.rows[1].is_active = False

    with pytest.raises(NotFoundError):
        await service.add_item(USER_ID, CartAdd(product_id=1))


async def test_update_sets_the_new_quantity(service):
    line = (await service.add_item(USER_ID, CartAdd(product_id=1)))[0]

    cart = await service.update_item(line, CartUpdate(quantity=4))

    assert cart[0].quantity == 4


async def test_update_of_a_deactivated_product_is_rejected(service):
    line = (await service.add_item(USER_ID, CartAdd(product_id=1)))[0]
    service.products.rows[1].is_active = False

    with pytest.raises(ConflictError):
        await service.update_item(line, CartUpdate(quantity=2))


async def test_remove(service):
    line = (await service.add_item(USER_ID, CartAdd(product_id=1)))[0]

    await service.remove_item(line)

    assert await service.get_cart(USER_ID) == []


async def test_unknown_item_is_not_found(service):
    with pytest.raises(NotFoundError):
        await service.get_item(999)
