"""
Unit tests for OrderService: the checkout/payment rules, with fake repositories and a fake
payment gateway (mocked dependencies: no database, no network).
"""

from decimal import Decimal
from types import SimpleNamespace

import pytest

from app.core import BusinessRuleError, ConflictError, NotFoundError
from app.models import CartItem, OrderStatus, PaymentStatus, Product
from app.services import OrderService
from tests.fakes import FakeCartRepository, FakeOrderRepository, FakePaymentGateway, FakeProductRepository

pytestmark = pytest.mark.anyio

USER_ID = 1


@pytest.fixture
def shop():
    """A product with 5 in stock, a cart holding 2 of it, and the service under test."""
    products = FakeProductRepository()
    product = Product(
        id=1, sku="ELEC-001", name="Headphones", price=Decimal("499.50"), stock=5, category_id=1, is_active=True
    )
    products.rows[1] = product
    cart = FakeCartRepository()
    cart.rows[1] = CartItem(id=1, user_id=USER_ID, product_id=1, product=product, quantity=2)
    gateway = FakePaymentGateway()
    orders = FakeOrderRepository()
    service = OrderService(orders, cart, products, gateway)  # type: ignore[arg-type]
    return SimpleNamespace(service=service, product=product, cart=cart, gateway=gateway, orders=orders)


async def test_checkout_confirms_and_takes_stock(shop):
    order = await shop.service.checkout(USER_ID)

    assert (order.status, order.payment_status) == (OrderStatus.CONFIRMED, PaymentStatus.PAID)
    assert order.total_amount == Decimal("999.00")
    assert order.items[0].unit_price == Decimal("499.50")  # price copied into the order
    assert shop.product.stock == 3
    assert shop.cart.rows == {}
    assert shop.gateway.charges == [(order.order_number, Decimal("999.00"))]


async def test_empty_cart_is_rejected(shop):
    shop.cart.rows.clear()

    with pytest.raises(BusinessRuleError):
        await shop.service.checkout(USER_ID)


async def test_not_enough_stock_changes_nothing(shop):
    shop.product.stock = 1

    with pytest.raises(ConflictError):
        await shop.service.checkout(USER_ID)

    assert shop.product.stock == 1
    assert shop.orders.rows == {}
    assert shop.gateway.charges == []


async def test_gateway_down_fails_the_payment_and_releases_stock(shop):
    shop.gateway.mode = "down"

    order = await shop.service.checkout(USER_ID)

    assert (order.status, order.payment_status) == (OrderStatus.PAYMENT_FAILED, PaymentStatus.FAILED)
    assert order.failure_reason.startswith("Payment service unavailable")
    assert shop.product.stock == 5


async def test_declined_payment_is_recorded(shop):
    shop.gateway.mode = "decline"

    order = await shop.service.checkout(USER_ID)

    assert order.status == OrderStatus.PAYMENT_FAILED
    assert order.failure_reason.startswith("Payment declined")


async def test_retry_after_failure(shop):
    shop.gateway.mode = "down"
    order = await shop.service.checkout(USER_ID)
    shop.gateway.mode = "approve"

    order = await shop.service.retry_payment(order)

    assert (order.status, order.payment_status) == (OrderStatus.CONFIRMED, PaymentStatus.PAID)
    assert order.failure_reason is None
    assert shop.product.stock == 3


async def test_retry_of_a_paid_order_is_rejected(shop):
    order = await shop.service.checkout(USER_ID)

    with pytest.raises(ConflictError):
        await shop.service.retry_payment(order)


async def test_retry_without_stock_is_rejected(shop):
    shop.gateway.mode = "down"
    order = await shop.service.checkout(USER_ID)
    shop.product.stock = 0  # sold out meanwhile

    with pytest.raises(ConflictError):
        await shop.service.retry_payment(order)


async def test_unknown_order_is_not_found(shop):
    with pytest.raises(NotFoundError):
        await shop.service.get_order(999)
