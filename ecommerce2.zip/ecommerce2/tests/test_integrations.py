"""
Tests for the external-service clients: timeout, retry, decline and circuit breaker.

Student notes:
- httpx.MockTransport replaces the network: `handler` decides what each HTTP call returns,
  or raises a timeout. The REAL client code runs, but nothing leaves the machine.
- retry_base_delay=0 so the tests don't sleep.
"""

import httpx
import pytest

from app.core.circuit_breaker import CircuitBreaker, CircuitOpenError
from app.integrations import (
    NotificationClient,
    NotificationError,
    PaymentDeclinedError,
    PaymentGateway,
    PaymentGatewayError,
)

pytestmark = pytest.mark.anyio


def gateway_with(handler, max_attempts: int = 3, breaker_failures: int = 5) -> PaymentGateway:
    return PaymentGateway(
        base_url="http://provider",
        timeout=0.5,
        max_attempts=max_attempts,
        retry_base_delay=0,
        breaker_failures=breaker_failures,
        transport=httpx.MockTransport(handler),
    )


class Recorder:
    """A fake gateway that answers with the given responses, one per call."""

    def __init__(self, *answers):
        self.answers = list(answers)
        self.requests: list[httpx.Request] = []

    def __call__(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        answer = self.answers.pop(0) if len(self.answers) > 1 else self.answers[0]
        if isinstance(answer, Exception):
            raise answer
        return answer


APPROVED = httpx.Response(200, json={"status": "approved", "reference": "PAY-123"})
DOWN = httpx.Response(503, json={"detail": "down"})
DECLINED = httpx.Response(402, json={"detail": "Card declined"})
TIMEOUT = httpx.ReadTimeout("timed out")


async def test_approved_charge_returns_the_reference_and_sends_an_idempotency_key():
    recorder = Recorder(APPROVED)

    reference = await gateway_with(recorder).charge("ORD-1", 100)

    assert reference == "PAY-123"
    assert recorder.requests[0].headers["Idempotency-Key"] == "ORD-1"


async def test_temporary_failures_are_retried():
    recorder = Recorder(DOWN, TIMEOUT, APPROVED)

    reference = await gateway_with(recorder).charge("ORD-1", 100)

    assert reference == "PAY-123"
    assert len(recorder.requests) == 3


async def test_gives_up_after_the_last_attempt():
    recorder = Recorder(TIMEOUT)

    with pytest.raises(PaymentGatewayError, match="timed out"):
        await gateway_with(recorder).charge("ORD-1", 100)

    assert len(recorder.requests) == 3


async def test_a_decline_is_not_retried():
    recorder = Recorder(DECLINED)

    with pytest.raises(PaymentDeclinedError, match="Card declined"):
        await gateway_with(recorder).charge("ORD-1", 100)

    assert len(recorder.requests) == 1


async def test_circuit_opens_and_stops_calling_the_gateway():
    recorder = Recorder(DOWN)
    gateway = gateway_with(recorder, max_attempts=3, breaker_failures=2)

    with pytest.raises(PaymentGatewayError):
        await gateway.charge("ORD-1", 100)  # 2 failures open the circuit, the 3rd attempt is refused
    calls_so_far = len(recorder.requests)
    with pytest.raises(PaymentGatewayError, match="circuit open"):
        await gateway.charge("ORD-2", 100)

    assert calls_so_far == 2
    assert len(recorder.requests) == 2  # no HTTP call while the circuit is open
    assert gateway.breaker.state == "open"


async def test_declines_do_not_trip_the_breaker():
    gateway = gateway_with(Recorder(DECLINED), breaker_failures=1)

    for _ in range(3):
        with pytest.raises(PaymentDeclinedError):
            await gateway.charge("ORD-1", 100)

    assert gateway.breaker.state == "closed"


async def test_half_open_trial_call_closes_the_circuit():
    breaker = CircuitBreaker("test", max_failures=1, reset_seconds=0)

    async def fail():
        raise RuntimeError("down")

    async def succeed():
        return "ok"

    with pytest.raises(RuntimeError):
        await breaker.call(fail)
    assert breaker.state == "open"

    assert await breaker.call(succeed) == "ok"  # reset_seconds=0: the trial call goes through
    assert breaker.state == "closed"


async def test_open_breaker_refuses_calls():
    breaker = CircuitBreaker("test", max_failures=1, reset_seconds=60)

    async def fail():
        raise RuntimeError("down")

    with pytest.raises(RuntimeError):
        await breaker.call(fail)
    with pytest.raises(CircuitOpenError):
        await breaker.call(fail)


async def test_notification_client_sends_and_reports_failures():
    ok = NotificationClient(
        "http://provider", 0.5, 2, 0, transport=httpx.MockTransport(lambda r: httpx.Response(200, json={}))
    )
    broken = NotificationClient(
        "http://provider", 0.5, 2, 0, transport=httpx.MockTransport(lambda r: httpx.Response(503))
    )

    await ok.send("a@example.com", "Hi", "Hello")
    with pytest.raises(NotificationError):
        await broken.send("a@example.com", "Hi", "Hello")
