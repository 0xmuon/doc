"""
API tests for cart, checkout, payments and notifications: the main business flow,
including the async/integration paths (gateway down, declined, retried).
"""

import pytest

from app.models import UserRole
from tests.conftest import create_product, create_user

pytestmark = [pytest.mark.anyio, pytest.mark.integration]


async def add(client, product_id: int, quantity: int = 1):
    return await client.post("/api/cart/add", json={"product_id": product_id, "quantity": quantity})


async def stock_of(client, product_id: int) -> int:
    return (await client.get(f"/api/products/{product_id}")).json()["stock"]


# ---- Cart -----------------------------------------------------------------------------------


async def test_cart_needs_a_token(client):
    response = await client.get("/api/cart")

    assert response.status_code == 401


async def test_add_to_cart(client, customer, product, login_as):
    login_as(customer)

    response = await add(client, product.id, 2)

    assert response.status_code == 201
    body = response.json()
    assert body["total_items"] == 2
    assert body["total"] == 998.0
    assert body["items"][0]["available"] is True


async def test_adding_the_same_product_again_adds_up(client, customer, product, login_as):
    login_as(customer)
    await add(client, product.id, 1)

    response = await add(client, product.id, 2)

    assert len(response.json()["items"]) == 1
    assert response.json()["items"][0]["quantity"] == 3


async def test_add_more_than_stock_is_409(client, db, customer, category, login_as):
    login_as(customer)
    scarce = await create_product(db, category.id, sku="HOME-003", name="Chef's Knife", stock=3)

    response = await add(client, scarce.id, 5)

    assert response.status_code == 409


async def test_add_more_than_per_product_limit_is_422(client, db, customer, category, login_as):
    login_as(customer)
    plenty = await create_product(db, category.id, sku="CLTH-001", name="T-Shirt", stock=500)

    response = await add(client, plenty.id, 11)

    assert response.status_code == 422


async def test_add_unknown_product_is_404(client, customer, login_as):
    login_as(customer)

    response = await add(client, 999)

    assert response.status_code == 404


async def test_admin_has_no_cart(client, admin, product, login_as):
    login_as(admin)

    response = await add(client, product.id)

    assert response.status_code == 403


async def test_update_cart_item(client, customer, product, login_as):
    login_as(customer)
    item_id = (await add(client, product.id)).json()["items"][0]["id"]

    response = await client.put(f"/api/cart/update/{item_id}", json={"quantity": 4})

    assert response.status_code == 200
    assert response.json()["items"][0]["quantity"] == 4


async def test_cannot_touch_someone_elses_cart_item(client, customer, other_customer, product, login_as):
    login_as(customer)
    item_id = (await add(client, product.id)).json()["items"][0]["id"]
    login_as(other_customer)

    update = await client.put(f"/api/cart/update/{item_id}", json={"quantity": 4})
    remove = await client.delete(f"/api/cart/remove/{item_id}")

    assert update.status_code == 403
    assert remove.status_code == 403


async def test_remove_cart_item(client, customer, product, login_as):
    login_as(customer)
    item_id = (await add(client, product.id)).json()["items"][0]["id"]

    response = await client.delete(f"/api/cart/remove/{item_id}")

    assert response.status_code == 204
    assert (await client.get("/api/cart")).json()["items"] == []


# ---- Checkout -------------------------------------------------------------------------------


async def test_checkout_confirms_the_order(client, customer, product, login_as, notifier):
    login_as(customer)
    await add(client, product.id, 2)

    response = await client.post("/api/orders/checkout")

    assert response.status_code == 201
    order = response.json()
    assert (order["status"], order["payment_status"]) == ("Confirmed", "Paid")
    assert order["order_number"].startswith("ORD-")
    assert order["payment_reference"].startswith("PAY-")
    assert order["total_amount"] == 998.0
    assert order["items"][0]["line_total"] == 998.0
    assert await stock_of(client, product.id) == 8  # stock taken
    assert (await client.get("/api/cart")).json()["items"] == []  # cart emptied
    # The confirmation e-mail was sent by a background task, after the response.
    assert [mail["to"] for mail in notifier.sent] == ["customer@example.com"]


async def test_checkout_with_empty_cart_is_422(client, customer, login_as):
    login_as(customer)

    response = await client.post("/api/orders/checkout")

    assert response.status_code == 422


async def test_checkout_of_a_deactivated_product_is_409(client, db, customer, product, login_as):
    login_as(customer)
    await add(client, product.id)
    product.is_active = False
    await db.commit()

    response = await client.post("/api/orders/checkout")

    assert response.status_code == 409
    assert len((await client.get("/api/cart")).json()["items"]) == 1  # nothing changed


async def test_gateway_down_keeps_order_and_stock_consistent(
    client, customer, product, login_as, payment_gateway, notifier
):
    login_as(customer)
    payment_gateway.mode = "down"
    await add(client, product.id, 2)

    response = await client.post("/api/orders/checkout")

    assert response.status_code == 201  # the order exists...
    order = response.json()
    assert (order["status"], order["payment_status"]) == ("Payment Failed", "Failed")  # ...unpaid
    assert "unavailable" in order["failure_reason"]
    assert await stock_of(client, product.id) == 10  # stock released
    assert notifier.sent == []  # no confirmation for an unpaid order


async def test_declined_payment(client, customer, product, login_as, payment_gateway):
    login_as(customer)
    payment_gateway.mode = "decline"
    await add(client, product.id)

    order = (await client.post("/api/orders/checkout")).json()

    assert order["status"] == "Payment Failed"
    assert "declined" in order["failure_reason"]


async def test_a_failed_payment_can_be_retried(client, customer, product, login_as, payment_gateway, notifier):
    login_as(customer)
    payment_gateway.mode = "down"
    await add(client, product.id, 2)
    order_id = (await client.post("/api/orders/checkout")).json()["id"]
    payment_gateway.mode = "approve"  # the gateway is back

    response = await client.post("/api/payments/process", json={"order_id": order_id})

    assert response.status_code == 200
    assert (response.json()["status"], response.json()["payment_status"]) == ("Confirmed", "Paid")
    assert await stock_of(client, product.id) == 8
    assert len(notifier.sent) == 1


async def test_retrying_a_paid_order_is_409(client, customer, product, login_as):
    login_as(customer)
    await add(client, product.id)
    order_id = (await client.post("/api/orders/checkout")).json()["id"]

    response = await client.post("/api/payments/process", json={"order_id": order_id})

    assert response.status_code == 409


async def test_cannot_pay_someone_elses_order(client, customer, other_customer, product, login_as, payment_gateway):
    login_as(customer)
    payment_gateway.mode = "down"
    await add(client, product.id)
    order_id = (await client.post("/api/orders/checkout")).json()["id"]
    login_as(other_customer)

    response = await client.post("/api/payments/process", json={"order_id": order_id})

    assert response.status_code == 403


async def test_broken_mail_service_does_not_break_checkout(client, customer, product, login_as, notifier):
    login_as(customer)
    notifier.fail = True
    await add(client, product.id)

    response = await client.post("/api/orders/checkout")

    assert response.status_code == 201
    assert response.json()["status"] == "Confirmed"


# ---- Order history and access ----------------------------------------------------------------


async def test_my_orders_lists_only_my_orders(client, customer, other_customer, product, login_as):
    login_as(customer)
    await add(client, product.id)
    await client.post("/api/orders/checkout")
    login_as(other_customer)
    await add(client, product.id)
    await client.post("/api/orders/checkout")

    response = await client.get("/api/orders/me")

    assert [o["user_id"] for o in response.json()] == [other_customer.id]


async def test_customer_reads_only_own_orders(client, customer, other_customer, product, login_as):
    login_as(customer)
    await add(client, product.id)
    order_id = (await client.post("/api/orders/checkout")).json()["id"]

    own = await client.get(f"/api/orders/{order_id}")
    login_as(other_customer)
    foreign = await client.get(f"/api/orders/{order_id}")

    assert own.status_code == 200
    assert foreign.status_code == 403  # ABAC: depends on who placed the order


async def test_support_reads_any_order(client, customer, support, product, login_as):
    login_as(customer)
    await add(client, product.id)
    order_id = (await client.post("/api/orders/checkout")).json()["id"]
    login_as(support)

    single = await client.get(f"/api/orders/{order_id}")
    summaries = await client.get("/api/admin/orders", params={"status": "Confirmed"})

    assert single.status_code == 200
    assert [(o["id"], o["item_count"]) for o in summaries.json()] == [(order_id, 1)]


async def test_get_unknown_order_is_404(client, support, login_as):
    login_as(support)

    response = await client.get("/api/orders/999")

    assert response.status_code == 404


# ---- Notifications --------------------------------------------------------------------------


async def test_support_sends_a_notification(client, db, customer, support, login_as, notifier):
    login_as(support)

    response = await client.post(
        "/api/notifications/send",
        json={"user_id": customer.id, "subject": "About your order", "message": "It ships tomorrow."},
    )

    assert response.status_code == 202
    assert notifier.sent[0]["to"] == "customer@example.com"


async def test_customer_cannot_send_notifications(client, db, customer, login_as):
    login_as(customer)
    someone = await create_user(db, "someone", UserRole.CUSTOMER)

    response = await client.post(
        "/api/notifications/send", json={"user_id": someone.id, "subject": "Hi", "message": "Hello"}
    )

    assert response.status_code == 403


async def test_notification_to_unknown_user_is_404(client, support, login_as):
    login_as(support)

    response = await client.post("/api/notifications/send", json={"user_id": 999, "subject": "Hi", "message": "Hi"})

    assert response.status_code == 404
