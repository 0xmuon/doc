"""API tests for health checks, monitoring and request tracing."""

import pytest

pytestmark = [pytest.mark.anyio, pytest.mark.integration]


async def test_health(client):
    response = await client.get("/health")

    assert response.status_code == 200
    assert response.json()["status"] == "healthy"


async def test_health_db(client):
    response = await client.get("/health/db")

    assert response.json() == {"status": "healthy", "database": "connected"}


async def test_client_request_id_is_reused(client):
    response = await client.get("/health", headers={"X-Request-ID": "trace-123"})

    assert response.headers["X-Request-ID"] == "trace-123"


async def test_metrics_count_requests_by_route_template(client, product):
    await client.get(f"/api/products/{product.id}")
    await client.get("/api/products/999")

    response = await client.get("/metrics")

    route = response.json()["GET /api/products/{product_id}"]
    assert route["requests"] >= 2
    assert route["error_rate"] == 0  # a 404 is the client's problem, not a server error
