"""API tests for public product browsing and search."""

import pytest

from tests.conftest import create_category, create_product

pytestmark = [pytest.mark.anyio, pytest.mark.integration]


async def test_browsing_needs_no_token(client, product):
    response = await client.get("/api/products")

    assert response.status_code == 200
    assert [p["sku"] for p in response.json()] == ["ELEC-001"]
    assert response.json()[0]["price"] == 499.0  # money is a JSON number


async def test_list_hides_inactive_products(client, db, product):
    product.is_active = False
    await db.commit()

    response = await client.get("/api/products")

    assert response.json() == []


async def test_list_filters_by_category(client, db, category, product):
    books = await create_category(db, "Books")
    await create_product(db, books.id, sku="BOOK-001", name="Clean Code")

    response = await client.get("/api/products", params={"category_id": books.id})

    assert [p["sku"] for p in response.json()] == ["BOOK-001"]


async def test_get_product(client, product):
    response = await client.get(f"/api/products/{product.id}")

    assert response.status_code == 200
    assert response.json()["name"] == "Wireless Headphones"


async def test_get_unknown_product_is_404(client):
    response = await client.get("/api/products/999")

    assert response.status_code == 404


async def test_get_inactive_product_is_404(client, db, product):
    product.is_active = False
    await db.commit()

    response = await client.get(f"/api/products/{product.id}")

    assert response.status_code == 404


async def test_search_by_text_ignores_case(client, db, category):
    await create_product(db, category.id, sku="ELEC-002", name="Wireless Mouse")
    await create_product(db, category.id, sku="ELEC-003", name="Desk Lamp", description="LED, warm light")

    by_name = await client.get("/api/products/search", params={"q": "MOUSE"})
    by_description = await client.get("/api/products/search", params={"q": "led"})

    assert [p["sku"] for p in by_name.json()] == ["ELEC-002"]
    assert [p["sku"] for p in by_description.json()] == ["ELEC-003"]


async def test_search_by_price_range(client, db, category):
    await create_product(db, category.id, sku="ELEC-002", name="Cable", price="199.00")
    await create_product(db, category.id, sku="ELEC-003", name="Speaker", price="1899.00")

    response = await client.get("/api/products/search", params={"min_price": 100, "max_price": 500})

    assert [p["sku"] for p in response.json()] == ["ELEC-002"]


async def test_search_min_above_max_is_422(client):
    response = await client.get("/api/products/search", params={"min_price": 500, "max_price": 100})

    assert response.status_code == 422


async def test_list_categories(client, db, category):
    await create_category(db, "Books")

    response = await client.get("/api/categories")

    assert [c["name"] for c in response.json()] == ["Books", "Electronics"]
