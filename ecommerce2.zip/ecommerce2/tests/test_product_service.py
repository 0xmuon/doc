"""Unit tests for ProductService and CategoryService (fake repositories)."""

from decimal import Decimal

import pytest

from app.core import BusinessRuleError, ConflictError, NotFoundError
from app.models import Category
from app.schemas import CategoryCreate, CategoryUpdate, ProductCreate, ProductUpdate
from app.services import CategoryService, ProductService
from tests.fakes import FakeCategoryRepository, FakeProductRepository

pytestmark = pytest.mark.anyio


@pytest.fixture
def categories() -> FakeCategoryRepository:
    repository = FakeCategoryRepository()
    repository.rows[1] = Category(id=1, name="Electronics", description=None, is_active=True)
    repository.rows[2] = Category(id=2, name="Old Stuff", description=None, is_active=False)
    return repository


@pytest.fixture
def service(categories) -> ProductService:
    return ProductService(FakeProductRepository(), categories)  # type: ignore[arg-type]


def new_product(**changes) -> ProductCreate:
    data = {"sku": "elec-001", "name": "Headphones", "price": Decimal("499"), "stock": 5, "category_id": 1}
    return ProductCreate(**{**data, **changes})


async def test_create_stores_the_sku_in_upper_case(service):
    product = await service.create_product(new_product())

    assert product.sku == "ELEC-001"
    assert product.is_active is True


async def test_duplicate_sku_ignores_case(service):
    await service.create_product(new_product())

    with pytest.raises(ConflictError):
        await service.create_product(new_product(sku="ELEC-001"))


@pytest.mark.parametrize("category_id", [2, 99])  # inactive, unknown
async def test_category_must_exist_and_be_active(service, category_id):
    with pytest.raises(BusinessRuleError):
        await service.create_product(new_product(category_id=category_id))


async def test_update_to_a_taken_sku_is_rejected(service):
    await service.create_product(new_product())
    second = await service.create_product(new_product(sku="ELEC-002"))

    with pytest.raises(ConflictError):
        await service.update_product(second.id, ProductUpdate(sku="elec-001"))


async def test_deactivated_product_is_hidden_from_customers(service):
    product = await service.create_product(new_product())

    await service.deactivate_product(product.id)

    with pytest.raises(NotFoundError):
        await service.get_product(product.id)
    assert (await service.get_product(product.id, include_inactive=True)).is_active is False


async def test_search_with_min_above_max_is_rejected(service):
    with pytest.raises(BusinessRuleError):
        await service.search_products(min_price=Decimal("10"), max_price=Decimal("5"))


async def test_category_names_are_unique_ignoring_case(categories):
    service = CategoryService(categories)  # type: ignore[arg-type]

    with pytest.raises(ConflictError):
        await service.create_category(CategoryCreate(name="electronics"))


async def test_renaming_a_category_to_its_own_name_in_other_case_is_allowed(categories):
    service = CategoryService(categories)  # type: ignore[arg-type]

    category = await service.update_category(1, CategoryUpdate(name="ELECTRONICS"))

    assert category.name == "ELECTRONICS"
