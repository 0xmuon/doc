"""
Shared test setup: a separate test database, an HTTP client, users and products.

Student notes:
- Tests NEVER touch the real database. PostgreSQL: "<db>_test" next to the real one, created
  on first run. SQLite: a local test file. Every test starts with empty tables.
- `client` talks to the app in memory (no server, no port) and swaps dependencies:
    get_db              -> the test session
    get_session_factory -> sessions on the test DB (for background tasks)
    get_payment_gateway -> FakePaymentGateway (no network)
    get_notifier        -> FakeNotifier (records instead of sending)
- `login_as(user)` skips JWT in API tests: every request is made as `user`. The JWT flow
  itself is tested for real in test_api_auth.py.
"""

from decimal import Decimal

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy import text
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

from app.core import Base, settings
from app.core.database import get_db, get_session_factory
from app.integrations import get_notifier, get_payment_gateway
from app.main import app
from app.models import Category, Product, User, UserRole
from app.repositories import CategoryRepository, ProductRepository, UserRepository
from app.routes.dependencies import get_current_user
from app.schemas import CategoryCreate, ProductCreate, UserRegister
from app.services import AuthService, CategoryService, ProductService
from tests.fakes import FakeNotifier, FakePaymentGateway


def _test_database_url() -> str:
    """postgresql+psycopg://.../ecommerceDB -> .../ecommerceDB_test; SQLite -> a test file."""
    if settings.database_url.startswith("sqlite"):
        return "sqlite+aiosqlite:///./test_ecommerce.db"
    server_url, main_db = settings.database_url.rsplit("/", 1)
    return f"{server_url}/{main_db}_test"


@pytest.fixture(scope="session")
def anyio_backend():
    """Run async tests on asyncio (the event loop FastAPI uses)."""
    return "asyncio"


@pytest.fixture(scope="session")
async def test_engine():
    """Create the test database once per test run, and an engine for it."""
    url = _test_database_url()
    if url.startswith("postgresql"):
        test_db = url.rsplit("/", 1)[1]
        # CREATE DATABASE can't run inside a transaction, hence AUTOCOMMIT.
        admin = create_async_engine(settings.database_url, isolation_level="AUTOCOMMIT")
        async with admin.connect() as conn:
            exists = await conn.scalar(text("SELECT 1 FROM pg_database WHERE datname = :name"), {"name": test_db})
            if not exists:
                await conn.execute(text(f'CREATE DATABASE "{test_db}"'))
        await admin.dispose()

    # NullPool: a new connection every time, so no connection outlives its test.
    engine = create_async_engine(url, poolclass=NullPool)
    yield engine
    await engine.dispose()


@pytest.fixture
async def db(test_engine):
    """An empty test database (all tables dropped and created again) and a session on it."""
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    async with async_sessionmaker(test_engine, expire_on_commit=False)() as session:
        yield session


@pytest.fixture
def payment_gateway() -> FakePaymentGateway:
    return FakePaymentGateway()


@pytest.fixture
def notifier() -> FakeNotifier:
    return FakeNotifier()


@pytest.fixture
async def client(db, test_engine, payment_gateway, notifier):
    """An HTTP client talking to the app, which uses the test database and the fakes."""

    async def use_test_db():
        yield db

    test_session_factory = async_sessionmaker(test_engine, expire_on_commit=False)
    app.dependency_overrides[get_db] = use_test_db
    app.dependency_overrides[get_session_factory] = lambda: test_session_factory
    app.dependency_overrides[get_payment_gateway] = lambda: payment_gateway
    app.dependency_overrides[get_notifier] = lambda: notifier
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as c:
        yield c
    app.dependency_overrides.clear()  # don't leak overrides into the next test


# ---- Test data, created through the real services -------------------------------------------


async def create_user(
    db, username: str, role: UserRole = UserRole.CUSTOMER, password: str = "secret123", active: bool = True
) -> User:
    """Create a user through the real service, so the password is hashed as usual."""
    data = UserRegister(
        username=username, email=f"{username}@example.com", full_name=username.title(), password=password
    )
    user = await AuthService(UserRepository(db)).create_user(data, role)
    if not active:
        user.is_active = False
        await db.commit()
    return user


async def create_category(db, name: str = "Electronics") -> Category:
    return await CategoryService(CategoryRepository(db)).create_category(CategoryCreate(name=name))


async def create_product(
    db,
    category_id: int,
    sku: str = "ELEC-001",
    name: str = "Wireless Headphones",
    price: str = "499.00",
    stock: int = 10,
    description: str = "",
) -> Product:
    data = ProductCreate(
        sku=sku, name=name, description=description, price=Decimal(price), stock=stock, category_id=category_id
    )
    return await ProductService(ProductRepository(db), CategoryRepository(db)).create_product(data)


@pytest.fixture
async def admin(db) -> User:
    return await create_user(db, "admin", UserRole.ADMIN)


@pytest.fixture
async def support(db) -> User:
    return await create_user(db, "support", UserRole.SUPPORT)


@pytest.fixture
async def customer(db) -> User:
    return await create_user(db, "customer", UserRole.CUSTOMER)


@pytest.fixture
async def other_customer(db) -> User:
    return await create_user(db, "other", UserRole.CUSTOMER)


@pytest.fixture
async def category(db) -> Category:
    return await create_category(db)


@pytest.fixture
async def product(db, category) -> Product:
    return await create_product(db, category.id)


@pytest.fixture
def login_as():
    """Call login_as(user): from then on, every request in the test is made as `user`."""

    def log_in(user: User) -> None:
        app.dependency_overrides[get_current_user] = lambda: user

    return log_in
