"""API tests for admin operations and their access rules (admin validations)."""

import pytest

from app.models import UserRole
from tests.conftest import create_user

pytestmark = [pytest.mark.anyio, pytest.mark.integration]


def new_product(category_id: int, **changes) -> dict:
    return {
        "sku": "book-101",
        "name": "Clean Code",
        "description": "A handbook of agile software craftsmanship",
        "price": 799.5,
        "stock": 25,
        "category_id": category_id,
        **changes,
    }


async def test_admin_creates_product(client, admin, category, login_as):
    login_as(admin)

    response = await client.post("/api/admin/products", json=new_product(category.id))

    assert response.status_code == 201
    assert response.json()["sku"] == "BOOK-101"  # stored in upper case
    assert response.json()["price"] == 799.5


async def test_create_product_without_token_is_401(client, category):
    response = await client.post("/api/admin/products", json=new_product(category.id))

    assert response.status_code == 401


@pytest.mark.parametrize("role", [UserRole.CUSTOMER, UserRole.SUPPORT])
async def test_only_admins_create_products(client, db, category, login_as, role):
    login_as(await create_user(db, "someone", role))

    response = await client.post("/api/admin/products", json=new_product(category.id))

    assert response.status_code == 403


async def test_duplicate_sku_is_409(client, admin, category, login_as):
    login_as(admin)
    await client.post("/api/admin/products", json=new_product(category.id))

    response = await client.post("/api/admin/products", json=new_product(category.id, sku="BOOK-101"))

    assert response.status_code == 409


@pytest.mark.parametrize(
    "changes",
    [{"price": -5}, {"price": 0}, {"price": 10.999}, {"stock": -1}, {"sku": "a b"}, {"name": ""}],
)
async def test_invalid_product_input_is_422(client, admin, category, login_as, changes):
    login_as(admin)

    response = await client.post("/api/admin/products", json=new_product(category.id, **changes))

    assert response.status_code == 422


async def test_unknown_category_is_422(client, admin, category, login_as):
    login_as(admin)

    response = await client.post("/api/admin/products", json=new_product(999))

    assert response.status_code == 422


async def test_update_product(client, admin, product, login_as):
    login_as(admin)

    response = await client.put(f"/api/admin/products/{product.id}", json={"price": 549, "stock": 5})

    assert response.status_code == 200
    assert response.json()["price"] == 549.0
    assert response.json()["stock"] == 5
    assert response.json()["name"] == "Wireless Headphones"  # untouched


async def test_update_unknown_product_is_404(client, admin, login_as):
    login_as(admin)

    response = await client.put("/api/admin/products/999", json={"price": 549})

    assert response.status_code == 404


async def test_deactivated_product_disappears_for_customers(client, admin, product, login_as):
    login_as(admin)

    response = await client.delete(f"/api/admin/products/{product.id}")

    assert response.status_code == 204
    assert (await client.get(f"/api/products/{product.id}")).status_code == 404
    # ... and an admin can bring it back
    restored = await client.put(f"/api/admin/products/{product.id}", json={"is_active": True})
    assert restored.json()["is_active"] is True


async def test_create_and_update_category(client, admin, login_as):
    login_as(admin)

    created = await client.post("/api/admin/categories", json={"name": "Books", "description": "All books"})
    updated = await client.put(f"/api/admin/categories/{created.json()['id']}", json={"name": "Books & Comics"})

    assert created.status_code == 201
    assert updated.status_code == 200
    assert updated.json()["name"] == "Books & Comics"


async def test_duplicate_category_ignores_case(client, admin, category, login_as):
    login_as(admin)

    response = await client.post("/api/admin/categories", json={"name": "ELECTRONICS"})

    assert response.status_code == 409


async def test_support_cannot_manage_categories(client, support, login_as):
    login_as(support)

    response = await client.post("/api/admin/categories", json={"name": "Books"})

    assert response.status_code == 403


@pytest.mark.parametrize("role", [UserRole.ADMIN, UserRole.SUPPORT])
async def test_admin_and_support_list_all_orders(client, db, login_as, role):
    login_as(await create_user(db, "staff", role))

    response = await client.get("/api/admin/orders")

    assert response.status_code == 200


async def test_customer_cannot_list_all_orders(client, customer, login_as):
    login_as(customer)

    response = await client.get("/api/admin/orders")

    assert response.status_code == 403


async def test_admin_actions_are_audited(client, admin, category, login_as):
    login_as(admin)
    created = await client.post("/api/admin/products", json=new_product(category.id))

    response = await client.get("/api/admin/audit-logs")

    entry = response.json()[0]
    assert (entry["actor_id"], entry["action"], entry["resource"]) == (admin.id, "create", "products")
    assert entry["resource_id"] == str(created.json()["id"])
    assert entry["request_id"] == created.headers["X-Request-ID"]  # links the row to the log lines


async def test_support_cannot_read_audit_log(client, support, login_as):
    login_as(support)

    response = await client.get("/api/admin/audit-logs")

    assert response.status_code == 403
