"""Routes: HTTP endpoints. main.py includes each router exported here."""

from app.routes.admin import router as admin_router
from app.routes.auth import router as auth_router
from app.routes.cart import router as cart_router
from app.routes.demo import router as demo_router
from app.routes.health import router as health_router
from app.routes.notifications import router as notifications_router
from app.routes.orders import router as orders_router
from app.routes.payments import router as payments_router
from app.routes.products import router as products_router

__all__ = [
    "admin_router",
    "auth_router",
    "cart_router",
    "demo_router",
    "health_router",
    "notifications_router",
    "orders_router",
    "payments_router",
    "products_router",
]
