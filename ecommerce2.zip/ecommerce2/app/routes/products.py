"""
Customer product routes: browse, search, details, categories.

Student notes:
- Browsing is PUBLIC: no token needed. Anyone may look at the shop window.
- Only active products are shown; an inactive one answers 404.
- Route order matters: /products/search is declared BEFORE /products/{product_id},
  otherwise "search" would be read as a product id (and fail with 422).
"""

from decimal import Decimal
from typing import Annotated

from fastapi import APIRouter, Query

from app.routes.dependencies import CategoryServiceDep, ProductServiceDep
from app.schemas import CategoryOut, ProductOut

router = APIRouter(prefix="/api", tags=["Products"])

# The same paging query parameters on every list: ?skip=0&limit=20
Skip = Annotated[int, Query(ge=0, description="How many results to skip")]
Limit = Annotated[int, Query(ge=1, le=100, description="How many results to return (max 100)")]
CategoryFilter = Annotated[int | None, Query(gt=0, description="Only this category")]


@router.get("/products", response_model=list[ProductOut])
async def list_products(
    service: ProductServiceDep, category_id: CategoryFilter = None, skip: Skip = 0, limit: Limit = 20
):
    """Active products, oldest first; [] if there are none."""
    return await service.list_products(category_id=category_id, skip=skip, limit=limit)


@router.get("/products/search", response_model=list[ProductOut])
async def search_products(
    service: ProductServiceDep,
    q: Annotated[str | None, Query(min_length=1, max_length=100, description="Text in name or description")] = None,
    category_id: CategoryFilter = None,
    min_price: Annotated[Decimal | None, Query(ge=0)] = None,
    max_price: Annotated[Decimal | None, Query(ge=0)] = None,
    skip: Skip = 0,
    limit: Limit = 20,
):
    """Search active products by text (case-insensitive), category and price range."""
    return await service.search_products(
        text=q, category_id=category_id, min_price=min_price, max_price=max_price, skip=skip, limit=limit
    )


@router.get("/products/{product_id}", response_model=ProductOut)
async def get_product(product_id: int, service: ProductServiceDep):
    """One product. 404 if it doesn't exist or is inactive."""
    return await service.get_product(product_id)


@router.get("/categories", response_model=list[CategoryOut], tags=["Categories"])
async def list_categories(service: CategoryServiceDep):
    """Active categories, by name."""
    return await service.list_categories()
