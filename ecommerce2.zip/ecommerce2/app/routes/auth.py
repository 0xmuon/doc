"""
Auth routes: register, log in to get tokens, refresh them, and ask "who am I?".

Student notes:
- The OAuth2 password flow: the client POSTs username + password as a FORM to
  /api/auth/login and gets back an access token (and a refresh token). From then on it
  sends the access token, not the password, in the `Authorization: Bearer ...` header.
- In Swagger: click "Authorize", type a username and password (e.g. aman / aman1234
  after seeding). Swagger calls /api/auth/login and adds the header for you.
- register, login and refresh must stay open: you can't need a token to get one.
- /api/auth/me is the quickest way to see what a token means: it returns the token's user.
"""

from typing import Annotated

from fastapi import APIRouter, Depends, status
from fastapi.security import OAuth2PasswordRequestForm

from app.routes.dependencies import AuditDep, AuthServiceDep, CurrentUser
from app.schemas import RefreshRequest, Token, UserOut, UserRegister

router = APIRouter(prefix="/api/auth", tags=["Auth"])


@router.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
async def register(data: UserRegister, service: AuthServiceDep, audit: AuditDep):
    """
    Create a customer account. The password is stored only as a hash and never returned.

    Username and email are stored in lower case and must be unique (409).
    """
    user = await service.register(data)
    audit.record(user.id, "register", "users", user.id)
    return user


@router.post("/login", response_model=Token)
async def login(form: Annotated[OAuth2PasswordRequestForm, Depends()], service: AuthServiceDep):
    """
    Log in with username and password (sent as a form) and get an access + refresh token.

    401 for a wrong username or password, 403 if the account is disabled.
    """
    return await service.login(form.username, form.password)


@router.post("/refresh", response_model=Token)
async def refresh(data: RefreshRequest, service: AuthServiceDep):
    """Swap a refresh token for a new token pair. 401 if it is expired, invalid or not a refresh token."""
    return await service.refresh(data.refresh_token)


@router.get("/me", response_model=UserOut)
async def read_current_user(current_user: CurrentUser):
    """The user the access token belongs to. 401 without a valid token."""
    return current_user
