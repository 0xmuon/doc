"""
Demo: sync vs async, side by side. Call two at once to see the difference:

    curl "localhost:8000/demo/async-blocking?seconds=3" & curl localhost:8000/health

Student notes:
- `def` + time.sleep          -> runs in the thread pool; other requests carry on.
- `async def` + asyncio.sleep -> the event loop serves others while this one waits.
- `async def` + time.sleep    -> THE MISTAKE: blocks the event loop; the whole server stops.
  The same happens with any blocking call inside async def: requests.get(), a sync DB
  driver, password hashing... (that's why auth_service uses asyncio.to_thread).
"""

import asyncio
import time
from typing import Annotated

from fastapi import APIRouter, Query

router = APIRouter(prefix="/demo", tags=["Demo: sync vs async"])

# The same query parameter on every route: ?seconds=1 (between 0 and 5).
Seconds = Annotated[float, Query(gt=0, le=5, description="How long to wait")]


@router.get("/sync-sleep")
def sync_sleep(seconds: Seconds = 1.0):
    """`def` + blocking sleep: runs in the thread pool, other requests carry on."""
    time.sleep(seconds)
    return {"route": "sync-sleep", "slept": seconds}


@router.get("/async-sleep")
async def async_sleep(seconds: Seconds = 1.0):
    """`async def` + awaited sleep: the loop serves others while this one waits."""
    await asyncio.sleep(seconds)
    return {"route": "async-sleep", "slept": seconds}


@router.get("/async-blocking")
async def async_blocking(seconds: Seconds = 1.0):
    """`async def` + blocking sleep: THE MISTAKE. The whole server stops meanwhile."""
    time.sleep(seconds)
    return {"route": "async-blocking", "slept": seconds}
