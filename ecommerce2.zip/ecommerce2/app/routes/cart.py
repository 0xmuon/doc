"""
Cart routes: view, add, update, remove. Customers only, each on their OWN cart.

Student notes:
- RBAC: Depends(authorize("cart", ...)) - only the customer role has cart rules.
- ABAC: update and remove act on ONE cart line, which must belong to the caller. The route
  loads the line first, then asks the policy with owner_id = the line's user_id.
"""

from typing import Annotated

from fastapi import APIRouter, Depends, status

from app.models import User
from app.policy import check_permission
from app.routes.dependencies import CartServiceDep, CurrentUser, authorize
from app.schemas import CartAdd, CartOut, CartUpdate

router = APIRouter(prefix="/api/cart", tags=["Cart"])


@router.get("", response_model=CartOut)
async def view_cart(user: Annotated[User, Depends(authorize("cart", "read"))], service: CartServiceDep):
    """The caller's cart with line totals and the cart total."""
    return CartOut.from_items(await service.get_cart(user.id))


@router.post("/add", response_model=CartOut, status_code=status.HTTP_201_CREATED)
async def add_to_cart(data: CartAdd, user: Annotated[User, Depends(authorize("cart", "add"))], service: CartServiceDep):
    """
    Add a product. If it is already in the cart, the quantities are added up.

    404 unknown/inactive product, 422 over the per-product limit, 409 not enough stock.
    """
    return CartOut.from_items(await service.add_item(user.id, data))


@router.put("/update/{cart_item_id}", response_model=CartOut)
async def update_cart_item(cart_item_id: int, data: CartUpdate, current_user: CurrentUser, service: CartServiceDep):
    """Set a line's quantity. 403 if the line belongs to someone else."""
    item = await service.get_item(cart_item_id)
    # ABAC: the answer depends on who owns this cart line.
    check_permission(current_user, "cart", "update", owner_id=item.user_id)
    return CartOut.from_items(await service.update_item(item, data))


@router.delete("/remove/{cart_item_id}", status_code=status.HTTP_204_NO_CONTENT)
async def remove_cart_item(cart_item_id: int, current_user: CurrentUser, service: CartServiceDep):
    """Remove a line. 204 = success, no body. 403 if the line belongs to someone else."""
    item = await service.get_item(cart_item_id)
    check_permission(current_user, "cart", "remove", owner_id=item.user_id)
    await service.remove_item(item)
