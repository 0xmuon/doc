"""
Order routes: checkout, my order history, one order.

Student notes:
- Checkout is the flow refactored from sync (Week 2) to ASYNC: see services/order_service.py.
  The response comes back as soon as the order is saved and the payment answered; the
  confirmation e-mail and the audit row are background tasks, sent after the response.
- Checkout answers 201 even when the payment failed: the order EXISTS (status
  "Payment Failed") and can be paid later with POST /api/payments/process.
- /orders/me is declared BEFORE /orders/{order_id}, otherwise "me" would be read as an id.
"""

from typing import Annotated

from fastapi import APIRouter, Depends, status

from app.models import OrderStatus, User
from app.policy import check_permission
from app.routes.dependencies import AuditDep, CurrentUser, NotificationsDep, OrderServiceDep, authorize
from app.schemas import OrderOut

router = APIRouter(prefix="/api/orders", tags=["Orders"])


@router.post("/checkout", response_model=OrderOut, status_code=status.HTTP_201_CREATED)
async def checkout(
    user: Annotated[User, Depends(authorize("orders", "checkout"))],
    service: OrderServiceDep,
    notifications: NotificationsDep,
    audit: AuditDep,
):
    """
    Turn the cart into an order and pay for it.

    422 empty cart, 409 a product is unavailable or out of stock (nothing is changed).
    Payment declined or gateway down: 201 with status "Payment Failed", stock released.
    """
    order = await service.checkout(user.id)
    audit.record(user.id, "checkout", "orders", order.id, f"{order.order_number}: {order.status.value}")
    if order.status == OrderStatus.CONFIRMED:
        notifications.order_confirmed(order.id)  # runs after the response is sent
    return order


@router.get("/me", response_model=list[OrderOut])
async def my_orders(user: Annotated[User, Depends(authorize("orders", "read_own"))], service: OrderServiceDep):
    """The caller's orders, newest first; [] if there are none."""
    return await service.list_my_orders(user.id)


@router.get("/{order_id}", response_model=OrderOut)
async def get_order(order_id: int, current_user: CurrentUser, service: OrderServiceDep):
    """One order. Customers: only their own (403). Support and admins: any order."""
    order = await service.get_order(order_id)
    # ABAC: the answer depends on who placed this order.
    check_permission(current_user, "orders", "read", owner_id=order.user_id)
    return order
