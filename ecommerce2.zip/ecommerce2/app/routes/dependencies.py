"""
Shared route dependencies: wiring the layers, current user, authorization, audit, notifications.

Student notes:
- `get_xxx_service(db)` wires the layers for each request: DB session -> repository -> service.
  `service: ProductServiceDep` in a route = "FastAPI, build a ProductService for this request".
- `current_user: CurrentUser` = "FastAPI, check the token and give me the User".
  No/garbled/expired token -> 401, disabled user -> 403.
- `Depends(authorize("products", "create"))` = a REUSABLE permission check (RBAC). It returns
  the checked user, so a route can also use it (e.g. as the audit actor).
- AuditTrail and Notifications are small helper classes that schedule background tasks.
  FastAPI builds them per request, injecting the request's BackgroundTasks object.
"""

from typing import Annotated

from fastapi import BackgroundTasks, Depends
from fastapi.security import OAuth2PasswordBearer

from app.background_tasks import send_order_confirmation, send_user_notification, write_audit_log
from app.core import DBSession, SessionFactory
from app.core.logging_config import request_id_var
from app.integrations import NotifierPort, PaymentGatewayPort, get_notifier, get_payment_gateway
from app.models import User
from app.policy import check_permission
from app.repositories import (
    AuditRepository,
    CartRepository,
    CategoryRepository,
    OrderRepository,
    ProductRepository,
    UserRepository,
)
from app.services import AuthService, CartService, CategoryService, OrderService, ProductService

# Where Swagger's "Authorize" button sends the username and password.
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


# ---- Services, one per request ------------------------------------------------------------


def get_auth_service(db: DBSession) -> AuthService:
    """Wire the layers together for each request: DB session -> repository -> service."""
    return AuthService(UserRepository(db))


def get_category_service(db: DBSession) -> CategoryService:
    return CategoryService(CategoryRepository(db))


def get_product_service(db: DBSession) -> ProductService:
    return ProductService(ProductRepository(db), CategoryRepository(db))


def get_cart_service(db: DBSession) -> CartService:
    return CartService(CartRepository(db), ProductRepository(db))


def get_order_service(
    db: DBSession, gateway: Annotated[PaymentGatewayPort, Depends(get_payment_gateway)]
) -> OrderService:
    return OrderService(OrderRepository(db), CartRepository(db), ProductRepository(db), gateway)


def get_user_repository(db: DBSession) -> UserRepository:
    return UserRepository(db)


def get_audit_repository(db: DBSession) -> AuditRepository:
    return AuditRepository(db)


AuthServiceDep = Annotated[AuthService, Depends(get_auth_service)]
CategoryServiceDep = Annotated[CategoryService, Depends(get_category_service)]
ProductServiceDep = Annotated[ProductService, Depends(get_product_service)]
CartServiceDep = Annotated[CartService, Depends(get_cart_service)]
OrderServiceDep = Annotated[OrderService, Depends(get_order_service)]
UserRepositoryDep = Annotated[UserRepository, Depends(get_user_repository)]
AuditRepositoryDep = Annotated[AuditRepository, Depends(get_audit_repository)]


# ---- Authentication and authorization -------------------------------------------------------


async def get_current_user(token: Annotated[str, Depends(oauth2_scheme)], service: AuthServiceDep) -> User:
    """The logged-in user. 401 for a missing, bad or expired token; 403 if disabled."""
    return await service.get_user_from_token(token)


# `current_user: CurrentUser` = "FastAPI, check the token and give me the User".
CurrentUser = Annotated[User, Depends(get_current_user)]


def authorize(resource: str, action: str):
    """Make a dependency that lets the request in only if the policy allows it."""

    async def check_permission_for_user(current_user: CurrentUser) -> User:
        check_permission(current_user, resource, action)
        return current_user  # so a route can also use the checked user

    return check_permission_for_user


# ---- Background work: audit trail and notifications ----------------------------------------


class AuditTrail:
    """Records "who did what" as a background task (written after the response)."""

    def __init__(self, background_tasks: BackgroundTasks, session_factory: SessionFactory):
        self.background_tasks = background_tasks
        self.session_factory = session_factory

    def record(
        self,
        actor_id: int | None,
        action: str,
        resource: str,
        resource_id: object = None,
        detail: str | None = None,
    ) -> None:
        self.background_tasks.add_task(
            write_audit_log,
            self.session_factory,
            actor_id,
            action,
            resource,
            None if resource_id is None else str(resource_id),
            detail,
            request_id_var.get(),
        )


class Notifications:
    """Schedules e-mails as background tasks (sent after the response)."""

    def __init__(
        self,
        background_tasks: BackgroundTasks,
        session_factory: SessionFactory,
        notifier: Annotated[NotifierPort, Depends(get_notifier)],
    ):
        self.background_tasks = background_tasks
        self.session_factory = session_factory
        self.notifier = notifier

    def order_confirmed(self, order_id: int) -> None:
        self.background_tasks.add_task(
            send_order_confirmation, self.session_factory, self.notifier, order_id, request_id_var.get()
        )

    def to_user(self, user_id: int, subject: str, message: str) -> None:
        self.background_tasks.add_task(
            send_user_notification,
            self.session_factory,
            self.notifier,
            user_id,
            subject,
            message,
            request_id_var.get(),
        )


AuditDep = Annotated[AuditTrail, Depends(AuditTrail)]
NotificationsDep = Annotated[Notifications, Depends(Notifications)]
