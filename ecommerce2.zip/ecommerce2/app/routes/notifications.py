"""
Notification routes: support/admin send a message to a customer.

Student notes:
- 202 Accepted: "I took your request; the work happens later". The message is sent by a
  background task after this response, so the caller never waits for the mail service.
"""

from typing import Annotated

from fastapi import APIRouter, Depends, status

from app.core import NotFoundError
from app.models import User
from app.routes.dependencies import AuditDep, NotificationsDep, UserRepositoryDep, authorize
from app.schemas import NotificationQueued, NotificationRequest

router = APIRouter(prefix="/api/notifications", tags=["Notifications"])


@router.post("/send", response_model=NotificationQueued, status_code=status.HTTP_202_ACCEPTED)
async def send_notification(
    data: NotificationRequest,
    sender: Annotated[User, Depends(authorize("notifications", "send"))],
    users: UserRepositoryDep,
    notifications: NotificationsDep,
    audit: AuditDep,
):
    """Queue an e-mail to a user. 404 if the user doesn't exist."""
    if await users.get_by_id(data.user_id) is None:
        raise NotFoundError(f"User {data.user_id} not found")
    notifications.to_user(data.user_id, data.subject, data.message)
    audit.record(sender.id, "notify", "users", data.user_id, data.subject)
    return NotificationQueued(user_id=data.user_id)
