"""
Health routes: liveness (/health) and readiness (/health/db).

Student notes:
- /health is a plain `def` ON PURPOSE: it does no I/O, so async would gain nothing. FastAPI
  runs sync routes in a thread pool, so they never block the event loop. Sync is fine for
  quick, CPU-light code and for libraries that have no async version.
- /health/db is async: it waits on the database.
"""

from fastapi import APIRouter
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

from app.core import DBSession, ServiceUnavailableError, settings

router = APIRouter(prefix="/health", tags=["Health"])


@router.get("")
def health():
    """The API process is running (does not touch the database)."""
    return {"status": "healthy", "app": settings.app_name, "version": settings.app_version}


@router.get("/db")
async def health_db(db: DBSession):
    """The database can be connected to and answers a trivial query. 503 if not."""
    try:
        await db.execute(text("SELECT 1"))
    except SQLAlchemyError as exc:
        # `from exc` keeps the original database error in the server logs.
        raise ServiceUnavailableError("Database connection failed") from exc
    return {"status": "healthy", "database": "connected"}
