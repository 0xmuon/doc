"""
Payment routes (operational/integration API).

Student notes:
- Payment normally happens inside checkout. This endpoint RETRIES the payment of an order
  whose payment failed (declined card, gateway down): it reserves the stock again and calls
  the gateway again. 409 if the order is already paid or not in "Payment Failed".
- ABAC: customers may only pay their own orders.
"""

from fastapi import APIRouter

from app.models import OrderStatus
from app.policy import check_permission
from app.routes.dependencies import AuditDep, CurrentUser, NotificationsDep, OrderServiceDep
from app.schemas import OrderOut, PaymentRequest

router = APIRouter(prefix="/api/payments", tags=["Payments"])


@router.post("/process", response_model=OrderOut)
async def process_payment(
    data: PaymentRequest,
    current_user: CurrentUser,
    service: OrderServiceDep,
    notifications: NotificationsDep,
    audit: AuditDep,
):
    """Pay a failed order again. Returns the order with its new status."""
    order = await service.get_order(data.order_id)
    check_permission(current_user, "payments", "process", owner_id=order.user_id)
    order = await service.retry_payment(order)
    audit.record(current_user.id, "payment_retry", "orders", order.id, f"{order.order_number}: {order.status.value}")
    if order.status == OrderStatus.CONFIRMED:
        notifications.order_confirmed(order.id)
    return order
