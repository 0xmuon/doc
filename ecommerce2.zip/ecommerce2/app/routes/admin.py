"""
Admin routes: manage products and categories, view all orders, read the audit log.

Student notes:
- Every route is protected by Depends(authorize(...)): the policy decides (policy.csv).
    products/categories -> admin only (support has NO product admin rights)
    orders list         -> admin and support (support troubleshoots orders)
    audit log           -> admin only
- Every change is written to the audit log by a background task (who, what, when).
- DELETE /products/{id} DEACTIVATES the product: customers can't see or buy it any more,
  old orders keep their link. PUT with {"is_active": true} brings it back.
"""

from typing import Annotated

from fastapi import APIRouter, Depends, Query, status

from app.models import OrderStatus, User
from app.routes.dependencies import (
    AuditDep,
    AuditRepositoryDep,
    CategoryServiceDep,
    OrderServiceDep,
    ProductServiceDep,
    authorize,
)
from app.schemas import (
    AuditLogOut,
    CategoryCreate,
    CategoryOut,
    CategoryUpdate,
    OrderSummaryOut,
    ProductCreate,
    ProductOut,
    ProductUpdate,
)

router = APIRouter(prefix="/api/admin", tags=["Admin"])


# ---- Products -------------------------------------------------------------------------------


@router.post("/products", response_model=ProductOut, status_code=status.HTTP_201_CREATED)
async def create_product(
    data: ProductCreate,
    admin: Annotated[User, Depends(authorize("products", "create"))],
    service: ProductServiceDep,
    audit: AuditDep,
):
    """Create a product. 409 duplicate SKU, 422 invalid input or unknown/inactive category."""
    product = await service.create_product(data)
    audit.record(admin.id, "create", "products", product.id, product.sku)
    return product


@router.put("/products/{product_id}", response_model=ProductOut)
async def update_product(
    product_id: int,
    data: ProductUpdate,
    admin: Annotated[User, Depends(authorize("products", "update"))],
    service: ProductServiceDep,
    audit: AuditDep,
):
    """Update a product; only the fields sent are changed. 404 unknown product."""
    product = await service.update_product(product_id, data)
    audit.record(admin.id, "update", "products", product_id, data.model_dump_json(exclude_unset=True))
    return product


@router.delete("/products/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
async def deactivate_product(
    product_id: int,
    admin: Annotated[User, Depends(authorize("products", "delete"))],
    service: ProductServiceDep,
    audit: AuditDep,
):
    """Deactivate a product (soft delete). 204 = success, no body."""
    await service.deactivate_product(product_id)
    audit.record(admin.id, "deactivate", "products", product_id)


# ---- Categories -----------------------------------------------------------------------------


@router.post("/categories", response_model=CategoryOut, status_code=status.HTTP_201_CREATED)
async def create_category(
    data: CategoryCreate,
    admin: Annotated[User, Depends(authorize("categories", "create"))],
    service: CategoryServiceDep,
    audit: AuditDep,
):
    """Create a category. 409 if the name exists (ignoring case)."""
    category = await service.create_category(data)
    audit.record(admin.id, "create", "categories", category.id, category.name)
    return category


@router.put("/categories/{category_id}", response_model=CategoryOut)
async def update_category(
    category_id: int,
    data: CategoryUpdate,
    admin: Annotated[User, Depends(authorize("categories", "update"))],
    service: CategoryServiceDep,
    audit: AuditDep,
):
    """Update a category. 404 unknown, 409 new name already used."""
    category = await service.update_category(category_id, data)
    audit.record(admin.id, "update", "categories", category_id, data.model_dump_json(exclude_unset=True))
    return category


# ---- Orders and audit log -------------------------------------------------------------------


@router.get("/orders", response_model=list[OrderSummaryOut])
async def list_orders(
    _: Annotated[User, Depends(authorize("orders", "list_all"))],
    service: OrderServiceDep,
    order_status: Annotated[OrderStatus | None, Query(alias="status", description="e.g. Confirmed")] = None,
):
    """Order summaries of ALL customers, newest first. Admin and support."""
    return await service.list_orders(order_status)


@router.get("/audit-logs", response_model=list[AuditLogOut])
async def list_audit_logs(
    _: Annotated[User, Depends(authorize("audit_logs", "read"))],
    repository: AuditRepositoryDep,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
):
    """The latest audit entries, newest first. Admin only."""
    return await repository.list_recent(limit)
