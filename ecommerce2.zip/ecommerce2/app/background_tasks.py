"""
Background tasks: work that runs AFTER the response has been sent.

Student notes:
- `background_tasks.add_task(func, args...)` in a route: FastAPI sends the response first,
  then runs func. The customer gets the checkout answer at once; the e-mail and the audit
  row follow a moment later. A slow or broken mail service never delays the response.
- The request's DB session is closed by then, so each task opens its OWN session from the
  session factory. Only ids travel to the task, never ORM objects of the closed session.
- Tasks never raise: a failure is logged ("NOT SENT, keep for later") and that's it.
- The request id is passed along and set again, so the task's log lines still match the
  request that started them (traceable async operations).
- For heavy or must-not-be-lost work, a real queue (Celery, RQ, Arq) is the next step:
  BackgroundTasks run in the same process and are lost if it restarts.
"""

import logging

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from app.core import settings
from app.core.logging_config import request_id_var
from app.integrations import NotifierPort
from app.models import AuditLog
from app.repositories import AuditRepository, OrderRepository, UserRepository

logger = logging.getLogger(__name__)

SessionFactory = async_sessionmaker[AsyncSession]


async def send_order_confirmation(
    session_factory: SessionFactory, notifier: NotifierPort, order_id: int, request_id: str
) -> None:
    """Tell the customer their order is confirmed."""
    token = request_id_var.set(request_id)
    try:
        async with session_factory() as db:
            order = await OrderRepository(db).get_by_id(order_id)
            owner = await UserRepository(db).get_by_id(order.user_id) if order and order.user_id else None
        if order is None or owner is None:
            logger.info("Order %s: no one to notify", order_id)
            return
        subject = f"Order {order.order_number} confirmed"
        message = (
            f"Hi {owner.full_name}, your order {order.order_number} "
            f"({sum(item.quantity for item in order.items)} item(s), "
            f"{order.total_amount} {settings.currency}) is confirmed. "
            f"Payment reference: {order.payment_reference}."
        )
        await notifier.send(owner.email, subject, message)
        logger.info("Order confirmation sent", extra={"context": {"order_id": order_id, "to": owner.email}})
    except Exception as exc:
        # FALLBACK: the order is saved and paid; keep the notification in the log to send later.
        logger.warning("Confirmation for order %s NOT SENT, keep for later (%s)", order_id, type(exc).__name__)
    finally:
        request_id_var.reset(token)


async def send_user_notification(
    session_factory: SessionFactory,
    notifier: NotifierPort,
    user_id: int,
    subject: str,
    message: str,
    request_id: str,
) -> None:
    """A message from support/admin to one customer."""
    token = request_id_var.set(request_id)
    try:
        async with session_factory() as db:
            user = await UserRepository(db).get_by_id(user_id)
        if user is None:
            logger.info("User %s: no one to notify", user_id)
            return
        await notifier.send(user.email, subject, message)
        logger.info("Notification sent", extra={"context": {"user_id": user_id, "to": user.email}})
    except Exception as exc:
        logger.warning("Notification for user %s NOT SENT, keep for later (%s)", user_id, type(exc).__name__)
    finally:
        request_id_var.reset(token)


async def write_audit_log(
    session_factory: SessionFactory,
    actor_id: int | None,
    action: str,
    resource: str,
    resource_id: str | None,
    detail: str | None,
    request_id: str,
) -> None:
    """Store one audit row: who did what to which record."""
    token = request_id_var.set(request_id)
    try:
        entry = AuditLog(
            actor_id=actor_id,
            action=action,
            resource=resource,
            resource_id=resource_id,
            detail=detail[:500] if detail else None,
            request_id=request_id,
        )
        async with session_factory() as db:
            await AuditRepository(db).add(entry)
        logger.info("Audit: %s %s %s", action, resource, resource_id or "", extra={"context": {"actor_id": actor_id}})
    except Exception:
        logger.exception("Audit log write failed")
    finally:
        request_id_var.reset(token)
