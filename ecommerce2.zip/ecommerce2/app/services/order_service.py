"""
Order service: checkout, payment and order history.

Student notes - the checkout flow (async end to end):
  1. Load the cart. Empty cart -> 422.
  2. Lock the products (SELECT ... FOR UPDATE) and check every line: active? enough stock?
     Any problem -> 409, and NOTHING has been changed.
  3. In ONE transaction: create the order "Pending Payment", copy prices into the order
     items, subtract the stock (reserve it), empty the cart. Commit.
  4. Call the payment gateway (non-blocking HTTP, timeout + retry + circuit breaker).
       approved          -> "Confirmed" / "Paid", payment reference stored
       declined or down  -> "Payment Failed" / "Failed", stock given back
     Order status and payment status are always saved together: never "Paid" + "Pending".
  5. The route then schedules background tasks (confirmation e-mail, audit log).

Why async here: step 4 waits on the network for up to seconds. With async, that waiting
costs no worker thread; the event loop serves other customers meanwhile. The DB calls are
async too (psycopg in async mode), so the whole flow never blocks.

A failed payment can be retried with POST /api/payments/process (retry_payment below):
it reserves the stock again and calls the gateway again, with the same Idempotency-Key.
"""

import logging
import uuid
from decimal import Decimal

from app.core import BusinessRuleError, ConflictError, NotFoundError, settings
from app.integrations import PaymentDeclinedError, PaymentGatewayError, PaymentGatewayPort
from app.models import Order, OrderItem, OrderStatus, PaymentStatus, Product
from app.repositories import CartRepository, OrderRepository, ProductRepository

logger = logging.getLogger(__name__)


def new_order_number() -> str:
    """ "ORD-" + 10 random hex characters, e.g. ORD-3F2A9C1B7D. Unguessable, unlike an id."""
    return f"ORD-{uuid.uuid4().hex[:10].upper()}"


class OrderService:
    def __init__(
        self,
        repository: OrderRepository,
        cart: CartRepository,
        products: ProductRepository,
        gateway: PaymentGatewayPort,
    ):
        self.repository = repository
        self.cart = cart
        self.products = products
        self.gateway = gateway

    async def checkout(self, user_id: int) -> Order:
        lines = await self.cart.get_for_user(user_id)
        if not lines:
            raise BusinessRuleError("Your cart is empty")

        products = await self._reserve_stock({line.product_id: line.quantity for line in lines})

        order = Order(
            order_number=new_order_number(),
            user_id=user_id,
            status=OrderStatus.PENDING_PAYMENT,
            payment_status=PaymentStatus.PENDING,
            total_amount=Decimal("0.00"),
        )
        for line in lines:
            product = products[line.product_id]
            order.items.append(
                OrderItem(
                    product_id=product.id,
                    product_name=product.name,  # copied: later renames don't change old orders
                    unit_price=product.price,  # copied: later price changes don't either
                    quantity=line.quantity,
                )
            )
        order.total_amount = sum((item.unit_price * item.quantity for item in order.items), Decimal("0.00"))

        await self.repository.add_pending(order)
        await self.cart.clear_for_user(user_id)
        await self.repository.commit()  # order + reserved stock + empty cart: all or nothing
        logger.info(
            "Order %s created, total %s",
            order.order_number,
            order.total_amount,
            extra={"context": {"order_id": order.id, "user_id": user_id}},
        )
        return await self._charge(order)

    async def retry_payment(self, order: Order) -> Order:
        """Pay a "Payment Failed" order again. Ownership was checked by the route."""
        if order.payment_status == PaymentStatus.PAID:
            raise ConflictError(f"Order {order.order_number} is already paid")
        if order.status != OrderStatus.PAYMENT_FAILED:
            raise ConflictError(
                f"Order {order.order_number} is '{order.status.value}'; only failed payments can be retried"
            )
        if any(item.product_id is None for item in order.items):
            raise ConflictError(f"Order {order.order_number} contains a product that no longer exists")

        await self._reserve_stock({item.product_id: item.quantity for item in order.items if item.product_id})
        order.status = OrderStatus.PENDING_PAYMENT
        order.payment_status = PaymentStatus.PENDING
        order.failure_reason = None
        await self.repository.save(order)  # stock reserved again + status, one commit
        return await self._charge(order)

    async def list_my_orders(self, user_id: int) -> list[Order]:
        return await self.repository.list_for_user(user_id)

    async def list_orders(self, status: OrderStatus | None = None) -> list[Order]:
        return await self.repository.list_all(status)

    async def get_order(self, order_id: int) -> Order:
        order = await self.repository.get_by_id(order_id)
        if order is None:
            raise NotFoundError(f"Order {order_id} not found")
        return order

    async def _charge(self, order: Order) -> Order:
        """Call the gateway and record the outcome. Never raises for gateway problems."""
        try:
            reference = await self.gateway.charge(order.order_number, order.total_amount, settings.currency)
        except PaymentDeclinedError as exc:
            reason = f"Payment declined: {exc}"
        except PaymentGatewayError as exc:
            reason = f"Payment service unavailable: {exc}"
        else:
            order.status = OrderStatus.CONFIRMED
            order.payment_status = PaymentStatus.PAID
            order.payment_reference = reference
            logger.info("Order %s paid (%s)", order.order_number, reference, extra={"context": {"order_id": order.id}})
            return await self.repository.save(order)

        # FALLBACK: keep the order, give the stock back, let the customer retry later.
        await self._release_stock(order)
        order.status = OrderStatus.PAYMENT_FAILED
        order.payment_status = PaymentStatus.FAILED
        order.failure_reason = reason[:255]
        logger.warning("Order %s: %s", order.order_number, reason, extra={"context": {"order_id": order.id}})
        return await self.repository.save(order)

    async def _reserve_stock(self, wanted: dict[int, int]) -> dict[int, Product]:
        """Lock the products, check EVERY line first, then subtract. {product_id: quantity}."""
        products = await self.products.get_many_for_update(list(wanted))
        problem = None
        for product_id, quantity in wanted.items():
            product = products.get(product_id)
            if product is None or not product.is_active:
                problem = f"Product {product_id} is no longer available"
            elif product.stock < quantity:
                problem = f"Only {product.stock} of '{product.name}' left in stock"
            if problem:
                # Nothing was changed yet. The request's session is closed right after the
                # error response, which rolls back and releases the row locks.
                raise ConflictError(problem)
        for product_id, quantity in wanted.items():
            products[product_id].stock -= quantity
        return products

    async def _release_stock(self, order: Order) -> None:
        """Give back the stock reserved for an order whose payment failed (saved by the caller)."""
        ids = [item.product_id for item in order.items if item.product_id is not None]
        products = await self.products.get_many_for_update(ids)
        for item in order.items:
            product = products.get(item.product_id) if item.product_id is not None else None
            if product is not None:
                product.stock += item.quantity
