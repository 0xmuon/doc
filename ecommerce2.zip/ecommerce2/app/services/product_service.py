"""
Product service: browsing for customers, management for admins.

Student notes:
- Customers only ever see ACTIVE products; an inactive product answers 404, as if it were
  gone. Admins can still load and reactivate it (include_inactive=True).
- SKUs are stored in upper case, so "elec-001" and "ELEC-001" are the same product.
- A product must belong to an existing, ACTIVE category (422 otherwise).
"""

from decimal import Decimal

from app.core import BusinessRuleError, ConflictError, NotFoundError
from app.models import Product
from app.repositories import CategoryRepository, ProductRepository
from app.schemas import ProductCreate, ProductUpdate


class ProductService:
    def __init__(self, repository: ProductRepository, categories: CategoryRepository):
        self.repository = repository
        self.categories = categories

    async def list_products(self, *, category_id: int | None = None, skip: int = 0, limit: int = 20) -> list[Product]:
        # No products is not an error: the answer is an empty list (200).
        return await self.repository.list_active(category_id=category_id, skip=skip, limit=limit)

    async def search_products(
        self,
        *,
        text: str | None = None,
        category_id: int | None = None,
        min_price: Decimal | None = None,
        max_price: Decimal | None = None,
        skip: int = 0,
        limit: int = 20,
    ) -> list[Product]:
        if min_price is not None and max_price is not None and min_price > max_price:
            raise BusinessRuleError("min_price can't be greater than max_price")
        return await self.repository.search(
            text=text.strip() if text else None,
            category_id=category_id,
            min_price=min_price,
            max_price=max_price,
            skip=skip,
            limit=limit,
        )

    async def get_product(self, product_id: int, *, include_inactive: bool = False) -> Product:
        product = await self.repository.get_by_id(product_id)
        if product is None or (not product.is_active and not include_inactive):
            raise NotFoundError(f"Product {product_id} not found")
        return product

    async def create_product(self, data: ProductCreate) -> Product:
        sku = data.sku.strip().upper()
        await self._check_sku_free(sku)
        await self._check_category_usable(data.category_id)
        # model_dump() turns the schema into a dict: {"name": "...", "price": ...}.
        # `**` unpacks it into keyword arguments: Product(name="...", price=..., ...).
        product = Product(**data.model_dump(exclude={"sku"}), sku=sku, is_active=True)
        return await self.repository.add(product)

    async def update_product(self, product_id: int, data: ProductUpdate) -> Product:
        product = await self.get_product(product_id, include_inactive=True)
        changes = data.model_dump(exclude_unset=True, exclude_none=True)

        if "sku" in changes:
            changes["sku"] = changes["sku"].strip().upper()
            if changes["sku"] != product.sku:
                await self._check_sku_free(changes["sku"])
        if "category_id" in changes and changes["category_id"] != product.category_id:
            await self._check_category_usable(changes["category_id"])

        for field, value in changes.items():
            setattr(product, field, value)
        return await self.repository.save(product)

    async def deactivate_product(self, product_id: int) -> Product:
        """ "Remove" a product: hide it from customers, keep it for old orders."""
        product = await self.get_product(product_id, include_inactive=True)
        product.is_active = False
        return await self.repository.save(product)

    async def _check_sku_free(self, sku: str) -> None:
        """Business rule: no two products share a SKU."""
        if await self.repository.get_by_sku(sku) is not None:
            raise ConflictError(f"A product with SKU '{sku}' already exists")

    async def _check_category_usable(self, category_id: int) -> None:
        """Business rule: products go into existing, active categories only."""
        category = await self.categories.get_by_id(category_id)
        if category is None or not category.is_active:
            raise BusinessRuleError(f"Category {category_id} does not exist or is inactive")
