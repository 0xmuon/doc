"""
Cart service: business rules for the shopping cart.

Student notes:
- Adding a product that is already in the cart increases that line's quantity.
- Rules checked on every change:
    the product exists and is active                 -> 404 otherwise
    quantity <= MAX_QUANTITY_PER_ITEM                -> 422 otherwise
    quantity <= stock                                -> 409 otherwise
  The cart does NOT reserve stock: checkout checks again, under a row lock.
- Who owns a cart line is checked in the route (ABAC: check_permission with owner_id).
"""

from app.core import BusinessRuleError, ConflictError, NotFoundError, settings
from app.models import CartItem, Product
from app.repositories import CartRepository, ProductRepository
from app.schemas import CartAdd, CartUpdate


class CartService:
    def __init__(self, repository: CartRepository, products: ProductRepository):
        self.repository = repository
        self.products = products

    async def get_cart(self, user_id: int) -> list[CartItem]:
        return await self.repository.get_for_user(user_id)

    async def get_item(self, item_id: int) -> CartItem:
        item = await self.repository.get_by_id(item_id)
        if item is None:
            raise NotFoundError(f"Cart item {item_id} not found")
        return item

    async def add_item(self, user_id: int, data: CartAdd) -> list[CartItem]:
        product = await self.products.get_by_id(data.product_id)
        if product is None or not product.is_active:
            raise NotFoundError(f"Product {data.product_id} not found")

        line = await self.repository.get_line(user_id, product.id)
        new_quantity = data.quantity + (line.quantity if line else 0)
        self._check_quantity(product, new_quantity)

        if line is not None:
            line.quantity = new_quantity
            await self.repository.save(line)
        else:
            item = CartItem(user_id=user_id, product_id=product.id, product=product, quantity=new_quantity)
            await self.repository.add(item)
        return await self.get_cart(user_id)

    async def update_item(self, item: CartItem, data: CartUpdate) -> list[CartItem]:
        """Set a line's quantity. `item` was loaded (and its owner checked) by the route."""
        if not item.product.is_active:
            raise ConflictError(f"'{item.product.name}' is no longer available; remove it from your cart")
        self._check_quantity(item.product, data.quantity)
        item.quantity = data.quantity
        await self.repository.save(item)
        return await self.get_cart(item.user_id)

    async def remove_item(self, item: CartItem) -> None:
        await self.repository.delete(item)

    @staticmethod
    def _check_quantity(product: Product, quantity: int) -> None:
        if quantity > settings.max_quantity_per_item:
            raise BusinessRuleError(f"At most {settings.max_quantity_per_item} units of one product per order")
        if quantity > product.stock:
            raise ConflictError(f"Only {product.stock} of '{product.name}' left in stock")
