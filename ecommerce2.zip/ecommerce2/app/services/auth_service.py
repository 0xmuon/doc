"""
Auth service: registration, login, token refresh and "who is this token?".

Student notes:
- SYNC INSIDE ASYNC: Argon2 hashing is CPU work (~50-100 ms) with no await inside. Called
  directly in an async route it would freeze the event loop for every other request.
  asyncio.to_thread() runs it in a worker thread; the loop keeps serving meanwhile.
  (Compare /demo/async-blocking: the same mistake with time.sleep.)
- Usernames and e-mails are stored in lower case, so "Kavya" and "kavya" are one account.
- One message for "no such user" and "wrong password": don't tell an attacker which it was.
"""

import asyncio

from app.core import ConflictError, ForbiddenError, UnauthorizedError, settings
from app.core.security import (
    ACCESS,
    REFRESH,
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
)
from app.models import User, UserRole
from app.repositories import UserRepository
from app.schemas import Token, UserRegister


class AuthService:
    """Login, tokens and user creation. Uses the user repository to look users up."""

    def __init__(self, repository: UserRepository):
        self.repository = repository

    async def register(self, data: UserRegister) -> User:
        """Self-registration: always a customer."""
        return await self.create_user(data, UserRole.CUSTOMER)

    async def create_user(self, data: UserRegister, role: UserRole) -> User:
        """Create a user with any role (the seed script creates staff accounts with this)."""
        username = data.username.lower()
        email = data.email.lower()
        if await self.repository.get_by_username(username) is not None:
            raise ConflictError(f"Username '{username}' is already taken")
        if await self.repository.get_by_email(email) is not None:
            raise ConflictError(f"Email '{email}' is already registered")
        hashed = await asyncio.to_thread(hash_password, data.password)
        user = User(
            username=username,
            email=email,
            full_name=data.full_name.strip(),
            hashed_password=hashed,
            role=role,
            is_active=True,
        )
        return await self.repository.add(user)

    async def login(self, username: str, password: str) -> Token:
        """Check the username and password, and return a new token pair."""
        user = await self.repository.get_by_username(username.lower())
        valid = user is not None and await asyncio.to_thread(verify_password, password, user.hashed_password)
        if not valid or user is None:
            raise UnauthorizedError("Incorrect username or password")
        self._check_active(user)
        return self._issue_tokens(user)

    async def refresh(self, refresh_token: str) -> Token:
        """Swap a valid refresh token for a new token pair."""
        username = decode_token(refresh_token, REFRESH)
        return self._issue_tokens(await self._get_active_user(username))

    async def get_user_from_token(self, token: str) -> User:
        """Return the user an access token belongs to, if the token and the user are still valid."""
        username = decode_token(token, ACCESS)  # 401 if the token is bad or expired
        return await self._get_active_user(username)

    async def _get_active_user(self, username: str) -> User:
        user = await self.repository.get_by_username(username)
        if user is None:
            raise UnauthorizedError("User no longer exists")
        self._check_active(user)
        return user

    @staticmethod
    def _check_active(user: User) -> None:
        """Business rule: disabled accounts can't log in or use their tokens."""
        if not user.is_active:
            raise ForbiddenError("User account is disabled")

    @staticmethod
    def _issue_tokens(user: User) -> Token:
        return Token(
            access_token=create_access_token(user.username),
            refresh_token=create_refresh_token(user.username),
            expires_in=settings.access_token_expire_minutes * 60,
        )
