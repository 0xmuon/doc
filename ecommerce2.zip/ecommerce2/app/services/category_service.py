"""Category service: business rules for categories."""

from app.core import ConflictError, NotFoundError
from app.models import Category
from app.repositories import CategoryRepository
from app.schemas import CategoryCreate, CategoryUpdate


class CategoryService:
    def __init__(self, repository: CategoryRepository):
        self.repository = repository

    async def list_categories(self) -> list[Category]:
        return await self.repository.get_all(active_only=True)

    async def get_category(self, category_id: int) -> Category:
        category = await self.repository.get_by_id(category_id)
        if category is None:
            raise NotFoundError(f"Category {category_id} not found")
        return category

    async def create_category(self, data: CategoryCreate) -> Category:
        name = data.name.strip()
        await self._check_name_free(name)
        category = Category(name=name, description=data.description, is_active=True)
        return await self.repository.add(category)

    async def update_category(self, category_id: int, data: CategoryUpdate) -> Category:
        category = await self.get_category(category_id)
        # exclude_unset: only fields the client actually sent.
        # exclude_none:  ignore explicit nulls.
        changes = data.model_dump(exclude_unset=True, exclude_none=True)
        if "name" in changes:
            changes["name"] = changes["name"].strip()
            if changes["name"].lower() != category.name.lower():
                await self._check_name_free(changes["name"])
        for field, value in changes.items():
            setattr(category, field, value)
        return await self.repository.save(category)

    async def _check_name_free(self, name: str) -> None:
        """Business rule: category names are unique, ignoring case."""
        if await self.repository.get_by_name(name) is not None:
            raise ConflictError(f"Category '{name}' already exists")
