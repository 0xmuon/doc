"""
The FastAPI application: logging, middleware, error handlers and routers.

Student notes:
- Tables are created at startup with create_all() (fine for learning; real projects use
  Alembic migrations, which can also ALTER existing tables).
- The middleware runs around EVERY request: it gives it an id (or reuses the client's
  X-Request-ID), times it, logs one line, counts it for /metrics and turns any unhandled
  error into a clean 500 that still carries the request id.
"""

import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status

from app import models  # noqa: F401  (registers tables on Base.metadata)
from app.core import Base, engine, register_exception_handlers, settings
from app.core.exceptions import error_response
from app.core.logging_config import request_id_var, setup_logging
from app.core.metrics import metrics_report, record_request
from app.routes import (
    admin_router,
    auth_router,
    cart_router,
    demo_router,
    health_router,
    notifications_router,
    orders_router,
    payments_router,
    products_router,
)

setup_logging()
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(_: FastAPI):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("%s %s started", settings.app_name, settings.app_version)
    yield
    await engine.dispose()  # close the pooled database connections


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="Online Shopping API: JWT auth, RBAC/ABAC with Casbin, async checkout, external integrations.",
    lifespan=lifespan,
)
register_exception_handlers(app)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Give each request an id, time it, log one line and count it for /metrics."""
    request_id = request.headers.get("X-Request-ID") or uuid.uuid4().hex[:8]
    token = request_id_var.set(request_id)  # every log line from here on carries it
    start = time.perf_counter()

    try:
        response = await call_next(request)  # everything else: auth, route, service, DB
    except Exception:
        # Nothing else handled it: a bug, or a failed dependency (e.g. database down).
        # Log the full traceback for us; tell the client only that something failed.
        logger.exception("%s %s failed", request.method, request.url.path)
        response = error_response(status.HTTP_500_INTERNAL_SERVER_ERROR, "Internal server error")

    duration_ms = (time.perf_counter() - start) * 1000
    route = request.scope.get("route")  # the matched route, set by FastAPI
    route_path = route.path if route else "unmatched"
    record_request(request.method, route_path, response.status_code, duration_ms)

    response.headers["X-Request-ID"] = request_id  # the client can quote it
    logger.info(
        "%s %s -> %d (%.1f ms)",
        request.method,
        request.url.path,
        response.status_code,
        duration_ms,
    )
    request_id_var.reset(token)
    return response


@app.get("/", include_in_schema=False)
async def root():
    """Landing response for http://localhost:8000 - points to the useful URLs."""
    return {
        "message": f"Welcome to {settings.app_name}",
        "version": settings.app_version,
        "docs": "/docs",
        "health": "/health",
        "login": "/api/auth/login",
    }


@app.get("/metrics", tags=["Monitoring"])
async def metrics():
    """Request count, error rate (5xx) and average time per route, since startup."""
    return metrics_report()


# Each router brings its own URL prefix (/health, /api/auth, /api/products, ...).
app.include_router(health_router)
app.include_router(auth_router)
app.include_router(products_router)
app.include_router(cart_router)
app.include_router(orders_router)
app.include_router(payments_router)
app.include_router(notifications_router)
app.include_router(admin_router)
app.include_router(demo_router)
