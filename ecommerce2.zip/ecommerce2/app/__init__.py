"""ECommerce API package. Each sub-folder is one layer; see README.md."""
