"""
Payment gateway client: charges an order through an external HTTP service.

Student notes:
- Three layers of protection around every external call:
    timeout          -> never wait more than EXTERNAL_TIMEOUT_SECONDS per attempt
    retry + backoff  -> try again on timeouts / connection errors / 5xx (core/retry.py)
    circuit breaker  -> stop calling a gateway that keeps failing (core/circuit_breaker.py)
- Two error types, because the order flow treats them differently:
    PaymentDeclinedError -> the gateway ANSWERED "no" (HTTP 402). Not retried.
    PaymentGatewayError  -> we could not get an answer. Retried, then reported.
  Either way the order flow catches it and marks the order "Payment Failed": an external
  failure never crashes checkout (see OrderService._charge).
- Idempotency-Key: the order number. If a retry reaches the gateway after a charge that DID
  go through (only the response got lost), the gateway returns the same payment instead of
  charging twice.
- httpx.AsyncClient is non-blocking: while we wait for the gateway, the event loop serves
  other requests. `transport` lets tests plug in a fake network (httpx.MockTransport).
"""

import logging
from decimal import Decimal

import httpx

from app.core.circuit_breaker import CircuitBreaker, CircuitOpenError
from app.core.retry import retry_async

logger = logging.getLogger(__name__)


class PaymentGatewayError(Exception):
    """No usable answer: timeout, connection error, 5xx, or circuit open."""


class PaymentDeclinedError(Exception):
    """The gateway refused the payment (e.g. card declined)."""


class PaymentGateway:
    def __init__(
        self,
        base_url: str,
        timeout: float,
        max_attempts: int,
        retry_base_delay: float,
        breaker_failures: int = 5,
        breaker_reset_seconds: float = 30,
        transport: httpx.AsyncBaseTransport | None = None,
    ):
        self.base_url = base_url
        self.timeout = timeout
        self.max_attempts = max_attempts
        self.retry_base_delay = retry_base_delay
        self.transport = transport
        # ONE breaker per gateway object: it must remember failures across requests.
        self.breaker = CircuitBreaker(
            "payment-gateway", breaker_failures, breaker_reset_seconds, excluded=(PaymentDeclinedError,)
        )

    async def charge(self, order_number: str, amount: Decimal, currency: str = "INR") -> str:
        """Charge `amount` for an order; return the gateway's payment reference."""
        try:
            return await retry_async(
                self._charge_once,
                order_number,
                amount,
                currency,
                attempts=self.max_attempts,
                base_delay=self.retry_base_delay,
                retry_on=(PaymentGatewayError,),
                operation=f"Payment for {order_number}",
            )
        except CircuitOpenError as exc:
            raise PaymentGatewayError("payment gateway is unavailable (circuit open)") from exc

    async def _charge_once(self, order_number: str, amount: Decimal, currency: str) -> str:
        return await self.breaker.call(self._post_charge, order_number, amount, currency)

    async def _post_charge(self, order_number: str, amount: Decimal, currency: str) -> str:
        """One HTTP attempt."""
        body = {"order_number": order_number, "amount": str(amount), "currency": currency}
        try:
            async with httpx.AsyncClient(
                base_url=self.base_url, timeout=self.timeout, transport=self.transport
            ) as client:
                response = await client.post("/payments/charge", json=body, headers={"Idempotency-Key": order_number})
        except httpx.TimeoutException as exc:
            raise PaymentGatewayError("payment gateway timed out") from exc
        except httpx.HTTPError as exc:  # connection refused, DNS failure, ...
            raise PaymentGatewayError(f"payment gateway unreachable ({type(exc).__name__})") from exc

        if response.status_code == 402:
            raise PaymentDeclinedError(_detail(response, "payment declined"))
        if response.status_code >= 400:
            raise PaymentGatewayError(f"payment gateway answered HTTP {response.status_code}")
        return response.json()["reference"]


def _detail(response: httpx.Response, default: str) -> str:
    """The `detail` field of a JSON error body, or `default`."""
    try:
        return str(response.json().get("detail", default))
    except ValueError:
        return default
