"""
Notification client: sends e-mails through an external HTTP service.

Student notes:
- Same protections as the payment gateway: timeout, retry with backoff, circuit breaker.
- Notifications are sent from BACKGROUND TASKS, after the response: a slow or broken mail
  service never delays checkout (see app/background_tasks.py).
"""

import httpx

from app.core.circuit_breaker import CircuitBreaker, CircuitOpenError
from app.core.retry import retry_async


class NotificationError(Exception):
    """The notification could not be delivered to the service."""


class NotificationClient:
    def __init__(
        self,
        base_url: str,
        timeout: float,
        max_attempts: int,
        retry_base_delay: float,
        breaker_failures: int = 5,
        breaker_reset_seconds: float = 30,
        transport: httpx.AsyncBaseTransport | None = None,
    ):
        self.base_url = base_url
        self.timeout = timeout
        self.max_attempts = max_attempts
        self.retry_base_delay = retry_base_delay
        self.transport = transport
        self.breaker = CircuitBreaker("notification-service", breaker_failures, breaker_reset_seconds)

    async def send(self, to: str, subject: str, message: str) -> None:
        try:
            await retry_async(
                self._send_once,
                to,
                subject,
                message,
                attempts=self.max_attempts,
                base_delay=self.retry_base_delay,
                retry_on=(NotificationError,),
                operation=f"Notification to {to}",
            )
        except CircuitOpenError as exc:
            raise NotificationError("notification service is unavailable (circuit open)") from exc

    async def _send_once(self, to: str, subject: str, message: str) -> None:
        await self.breaker.call(self._post, to, subject, message)

    async def _post(self, to: str, subject: str, message: str) -> None:
        try:
            async with httpx.AsyncClient(
                base_url=self.base_url, timeout=self.timeout, transport=self.transport
            ) as client:
                response = await client.post("/notify", json={"to": to, "subject": subject, "message": message})
        except httpx.TimeoutException as exc:
            raise NotificationError("notification service timed out") from exc
        except httpx.HTTPError as exc:
            raise NotificationError(f"notification service unreachable ({type(exc).__name__})") from exc
        if response.status_code >= 400:
            raise NotificationError(f"notification service answered HTTP {response.status_code}")
