"""
Integrations: clients for external services (payment gateway, notifications).

Student notes:
- One shared client object per service, so its circuit breaker remembers failures across
  requests. Routes get them through the dependencies below, which tests override with
  fakes (tests/fakes.py): no real network calls in tests.
- Protocols describe what the services NEED (a `charge` / `send` method), not which class
  provides it. The real clients and the test fakes both fit.
"""

from decimal import Decimal
from typing import Protocol

from app.core import settings
from app.integrations.notification_client import NotificationClient, NotificationError
from app.integrations.payment_gateway import PaymentDeclinedError, PaymentGateway, PaymentGatewayError


class PaymentGatewayPort(Protocol):
    async def charge(self, order_number: str, amount: Decimal, currency: str = "INR") -> str: ...


class NotifierPort(Protocol):
    async def send(self, to: str, subject: str, message: str) -> None: ...


payment_gateway = PaymentGateway(
    base_url=settings.payment_gateway_url,
    timeout=settings.external_timeout_seconds,
    max_attempts=settings.external_max_attempts,
    retry_base_delay=settings.external_retry_base_delay,
)

notification_client = NotificationClient(
    base_url=settings.notification_service_url,
    timeout=settings.external_timeout_seconds,
    max_attempts=settings.external_max_attempts,
    retry_base_delay=settings.external_retry_base_delay,
)


def get_payment_gateway() -> PaymentGatewayPort:
    return payment_gateway


def get_notifier() -> NotifierPort:
    return notification_client


__all__ = [
    "NotificationClient",
    "NotificationError",
    "NotifierPort",
    "PaymentDeclinedError",
    "PaymentGateway",
    "PaymentGatewayError",
    "PaymentGatewayPort",
    "get_notifier",
    "get_payment_gateway",
]
