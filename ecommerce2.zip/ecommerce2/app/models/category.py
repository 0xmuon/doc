"""
Category model: one row in the `categories` table (e.g. Electronics, Books).

Student notes:
- Names are unique, compared case-insensitively by the service ("books" == "Books").
- Categories are never deleted, only deactivated (is_active=False): products and old
  orders still point at them.
"""

from datetime import datetime

from sqlalchemy import DateTime, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core import Base


class Category(Base):
    """One row in the `categories` table."""

    __tablename__ = "categories"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    description: Mapped[str | None] = mapped_column(String(255))
    is_active: Mapped[bool] = mapped_column(default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
