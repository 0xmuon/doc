"""
Order models: `orders` (the header) and `order_items` (its lines).

Student notes:
- Order status and payment status move together:
      Pending Payment / Pending  -> order created, stock reserved, gateway being called
      Confirmed       / Paid     -> the gateway approved the charge
      Payment Failed  / Failed   -> declined or gateway down; stock released, can be retried
  They are never left half-changed: both are saved in the same commit.
- Order items COPY the product name and price at checkout time: if the price changes
  tomorrow, yesterday's order still shows what the customer paid.
- lazy="selectin": loading orders also loads their items with ONE extra query (no lazy
  loading in async code, see models/cart.py).
"""

import enum
from datetime import datetime
from decimal import Decimal

from sqlalchemy import DateTime, Enum, ForeignKey, Numeric, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core import Base


class OrderStatus(enum.Enum):
    PENDING_PAYMENT = "Pending Payment"
    CONFIRMED = "Confirmed"
    PAYMENT_FAILED = "Payment Failed"


class PaymentStatus(enum.Enum):
    PENDING = "Pending"
    PAID = "Paid"
    FAILED = "Failed"


class Order(Base):
    """One row in the `orders` table."""

    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(primary_key=True)
    order_number: Mapped[str] = mapped_column(String(20), unique=True, index=True)  # "ORD-3F2A9C1B7D"
    # Who placed it: a user id, or NULL if that user was deleted.
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), index=True)
    status: Mapped[OrderStatus] = mapped_column(Enum(OrderStatus), default=OrderStatus.PENDING_PAYMENT)
    payment_status: Mapped[PaymentStatus] = mapped_column(Enum(PaymentStatus), default=PaymentStatus.PENDING)
    payment_reference: Mapped[str | None] = mapped_column(String(40))  # from the gateway, e.g. "PAY-..."
    failure_reason: Mapped[str | None] = mapped_column(String(255))
    total_amount: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    items: Mapped[list["OrderItem"]] = relationship(
        back_populates="order", cascade="all, delete-orphan", lazy="selectin", order_by="OrderItem.id"
    )


class OrderItem(Base):
    """One line of an order (the order_details table)."""

    __tablename__ = "order_items"

    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"), index=True)
    product_id: Mapped[int | None] = mapped_column(ForeignKey("products.id", ondelete="SET NULL"))
    product_name: Mapped[str] = mapped_column(String(120))  # copied at checkout
    unit_price: Mapped[Decimal] = mapped_column(Numeric(10, 2))  # copied at checkout
    quantity: Mapped[int]

    order: Mapped[Order] = relationship(back_populates="items")
