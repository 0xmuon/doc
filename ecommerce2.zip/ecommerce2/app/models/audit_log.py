"""
Audit log model: who did what, and when. One row per important action.

Student notes:
- Logs (stdout) are for operators and get rotated away; the audit log is business data
  kept in the database: "who changed the price of ELEC-001 last Tuesday?".
- Rows are written by a background task, AFTER the response: auditing never slows down
  or breaks the user's request (see app/background_tasks.py).
- actor_id is a plain number (no foreign key): the history must survive user deletion.
"""

from datetime import datetime

from sqlalchemy import DateTime, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core import Base


class AuditLog(Base):
    """One row in the `audit_logs` table."""

    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(primary_key=True)
    actor_id: Mapped[int | None] = mapped_column(index=True)  # the user who acted
    action: Mapped[str] = mapped_column(String(50))  # "create", "update", "checkout", ...
    resource: Mapped[str] = mapped_column(String(50))  # "products", "orders", ...
    resource_id: Mapped[str | None] = mapped_column(String(50))
    detail: Mapped[str | None] = mapped_column(String(500))
    request_id: Mapped[str] = mapped_column(String(40), default="-")  # links to the log lines
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
