"""
Models: database tables.

Import every model here so Base.metadata knows about all tables. A model class is only
registered once its file is imported; main.py imports this package before calling
create_all(), so every table listed here gets created.
"""

from app.models.audit_log import AuditLog
from app.models.cart import CartItem
from app.models.category import Category
from app.models.order import Order, OrderItem, OrderStatus, PaymentStatus
from app.models.product import Product
from app.models.user import User, UserRole

__all__ = [
    "AuditLog",
    "CartItem",
    "Category",
    "Order",
    "OrderItem",
    "OrderStatus",
    "PaymentStatus",
    "Product",
    "User",
    "UserRole",
]
