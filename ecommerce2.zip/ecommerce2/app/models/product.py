"""
Product model: one row in the `products` table.

Student notes:
- Money is a Decimal stored as NUMERIC(10, 2), never a float: 0.1 + 0.2 must be 0.30.
- The SKU (stock keeping unit, e.g. "ELEC-001") is the business key: unique, upper case.
- CHECK constraints are a last safety net in the database itself: even a buggy service
  can't store a negative stock or a zero price.
- "Remove product" = deactivate (is_active=False). Old orders keep pointing at it.
"""

from datetime import datetime
from decimal import Decimal

from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Numeric, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core import Base


class Product(Base):
    """One row in the `products` table."""

    __tablename__ = "products"
    __table_args__ = (
        CheckConstraint("price > 0", name="ck_products_price_positive"),
        CheckConstraint("stock >= 0", name="ck_products_stock_not_negative"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    sku: Mapped[str] = mapped_column(String(30), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120), index=True)
    description: Mapped[str] = mapped_column(Text, default="")
    price: Mapped[Decimal] = mapped_column(Numeric(10, 2))
    stock: Mapped[int] = mapped_column(default=0)
    # RESTRICT: a category with products can't be deleted by accident.
    category_id: Mapped[int] = mapped_column(ForeignKey("categories.id", ondelete="RESTRICT"), index=True)
    is_active: Mapped[bool] = mapped_column(default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
