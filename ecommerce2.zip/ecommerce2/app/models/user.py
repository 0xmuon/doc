"""
User model: one row in the `users` table.

Student notes:
- Roles decide what a user may do (rules in app/policy/policy.csv):
    customer -> browse products, manage own cart, place and view own orders
    support  -> view all orders and customer issues, NO product admin rights
    admin    -> manage products and categories, view all orders, audit logs
- Self-registration always creates a customer. Staff accounts come from the seed script.
- The password is stored only as a hash (see core/security.py).
"""

import enum
from datetime import datetime

from sqlalchemy import DateTime, Enum, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core import Base


class UserRole(enum.Enum):
    """What a user may do. New users are customers unless an admin says otherwise."""

    CUSTOMER = "customer"
    SUPPORT = "support"
    ADMIN = "admin"


class User(Base):
    """One row in the `users` table."""

    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(100))
    hashed_password: Mapped[str] = mapped_column(String(255))
    role: Mapped[UserRole] = mapped_column(Enum(UserRole), default=UserRole.CUSTOMER)
    is_active: Mapped[bool] = mapped_column(default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
