"""
Cart model: one row per (user, product) in the `cart_items` table.

Student notes:
- The UNIQUE (user_id, product_id) constraint means one line per product: adding the same
  product again increases the quantity of the existing line (see CartService.add_item).
- lazy="joined": loading a cart item also loads its product in the SAME query. In async
  code a lazy load on attribute access is not allowed (MissingGreenlet error), so
  relationships we read must be loaded up front.
"""

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import DateTime, ForeignKey, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core import Base

if TYPE_CHECKING:  # only for type hints; avoids a circular import at runtime
    from app.models.product import Product


class CartItem(Base):
    """One line in a user's cart."""

    __tablename__ = "cart_items"
    __table_args__ = (UniqueConstraint("user_id", "product_id", name="uq_cart_items_user_product"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id", ondelete="CASCADE"))
    quantity: Mapped[int]
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    product: Mapped["Product"] = relationship(lazy="joined")
