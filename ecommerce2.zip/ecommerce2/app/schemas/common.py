"""
Shared schema types.

Student notes:
- Money is a Decimal inside the app (exact), but a plain JSON number in responses:
  999.5 instead of the string "999.50" that Pydantic would produce for a Decimal.
"""

from decimal import Decimal
from typing import Annotated

from pydantic import PlainSerializer

Money = Annotated[Decimal, PlainSerializer(lambda value: float(value), return_type=float, when_used="json")]
