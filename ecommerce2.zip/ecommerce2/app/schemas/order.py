"""Order and payment schemas."""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, computed_field

from app.models import OrderStatus, PaymentStatus
from app.schemas.common import Money


class OrderItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    product_id: int | None
    product_name: str
    unit_price: Money
    quantity: int

    @computed_field
    @property
    def line_total(self) -> float:
        return float(self.unit_price * self.quantity)


class OrderOut(BaseModel):
    """A full order, with its lines. Returned by checkout, order history, payment retry."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    order_number: str
    user_id: int | None
    status: OrderStatus
    payment_status: PaymentStatus
    payment_reference: str | None
    failure_reason: str | None
    total_amount: Money
    items: list[OrderItemOut]
    created_at: datetime
    updated_at: datetime


class OrderSummaryOut(BaseModel):
    """One row of the admin/support order list: no lines, just their count."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    order_number: str
    user_id: int | None
    status: OrderStatus
    payment_status: PaymentStatus
    total_amount: Money
    items: list[OrderItemOut] = Field(exclude=True)  # read to count, not shown
    created_at: datetime

    @computed_field
    @property
    def item_count(self) -> int:
        return sum(item.quantity for item in self.items)


class PaymentRequest(BaseModel):
    """Body for POST /api/payments/process: retry the payment of a failed order."""

    order_id: int = Field(gt=0)
