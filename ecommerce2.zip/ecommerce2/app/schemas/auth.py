"""
Auth schemas: what POST /api/auth/login and /api/auth/refresh return.

Student notes:
- There is no login request schema here. OAuth2's password flow sends the username and
  password as a FORM, not JSON, so the route uses FastAPI's OAuth2PasswordRequestForm.
  That is what lets Swagger's "Authorize" button log in for you.
- `token_type: "bearer"` tells the client how to send the token back:
  `Authorization: Bearer <access_token>` on every later request.
"""

from pydantic import BaseModel, Field


class Token(BaseModel):
    """Response of login and refresh. Field names follow the OAuth2 standard."""

    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # seconds until the access token expires


class RefreshRequest(BaseModel):
    """Body for POST /api/auth/refresh."""

    refresh_token: str = Field(min_length=10)
