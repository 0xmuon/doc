"""Notification schemas."""

from pydantic import BaseModel, Field


class NotificationRequest(BaseModel):
    """Body for POST /api/notifications/send (support/admin contacting a customer)."""

    user_id: int = Field(gt=0)
    subject: str = Field(min_length=1, max_length=120, pattern=r"\S")
    message: str = Field(min_length=1, max_length=1000, pattern=r"\S")


class NotificationQueued(BaseModel):
    """202 Accepted: the message will be sent in the background, after this response."""

    status: str = "queued"
    user_id: int
