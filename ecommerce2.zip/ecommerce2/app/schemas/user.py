"""User schemas: request and response shapes for users."""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from app.models import UserRole


class UserRegister(BaseModel):
    """Body for POST /api/auth/register. Everyone who registers is a customer."""

    username: str = Field(
        min_length=3,
        max_length=50,
        pattern=r"^[A-Za-z0-9._]+$",
        description="Letters, digits, '.' and '_'. Stored in lower case, e.g. 'kavya.r'",
    )
    email: EmailStr
    full_name: str = Field(min_length=1, max_length=100, pattern=r"\S")
    password: str = Field(min_length=8, max_length=128, description="At least 8 characters")


class UserOut(BaseModel):
    """How a user appears in responses. No password, not even the hash."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    email: str
    full_name: str
    role: UserRole
    is_active: bool
    created_at: datetime
