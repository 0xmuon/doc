"""Category schemas."""

from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field

CategoryName = Annotated[str, Field(min_length=2, max_length=50, pattern=r"\S")]
Description = Annotated[str, Field(max_length=255)]


class CategoryCreate(BaseModel):
    """Body for POST /api/admin/categories."""

    name: CategoryName
    description: Description | None = None


class CategoryUpdate(BaseModel):
    """Body for PUT /api/admin/categories/{id}: only the fields sent are changed."""

    name: CategoryName | None = None
    description: Description | None = None
    is_active: bool | None = None


class CategoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    description: str | None
    is_active: bool
