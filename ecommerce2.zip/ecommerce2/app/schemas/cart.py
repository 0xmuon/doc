"""
Cart schemas.

Student notes:
- The cart response is CALCULATED from the cart lines and their products: prices always
  come from the product table, never from the client.
- `available` warns the customer before checkout: False if the product was deactivated
  or there isn't enough stock any more.
"""

from decimal import Decimal

from pydantic import BaseModel, Field

from app.models import CartItem
from app.schemas.common import Money


class CartAdd(BaseModel):
    """Body for POST /api/cart/add."""

    product_id: int = Field(gt=0)
    quantity: int = Field(1, ge=1, le=100)


class CartUpdate(BaseModel):
    """Body for PUT /api/cart/update/{cart_item_id}: the NEW quantity (not a difference)."""

    quantity: int = Field(ge=1, le=100)


class CartItemOut(BaseModel):
    id: int
    product_id: int
    product_name: str
    unit_price: Money
    quantity: int
    line_total: Money
    available: bool


class CartOut(BaseModel):
    items: list[CartItemOut]
    total_items: int
    total: Money

    @classmethod
    def from_items(cls, items: list[CartItem]) -> "CartOut":
        lines = [
            CartItemOut(
                id=item.id,
                product_id=item.product_id,
                product_name=item.product.name,
                unit_price=item.product.price,
                quantity=item.quantity,
                line_total=item.product.price * item.quantity,
                available=item.product.is_active and item.product.stock >= item.quantity,
            )
            for item in items
        ]
        return cls(
            items=lines,
            total_items=sum(line.quantity for line in lines),
            total=sum((line.line_total for line in lines), Decimal("0.00")),
        )
