"""
Product schemas.

Student notes:
- Constraints live in Annotated types so create and update share them: an update may
  leave out the price, but if it sends one, the same rules apply.
- Price: positive, at most 2 decimals, at most 10 digits. 19.999 is rejected with 422.
"""

from datetime import datetime
from decimal import Decimal
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field

from app.schemas.common import Money

Sku = Annotated[
    str,
    Field(min_length=3, max_length=30, pattern=r"^[A-Za-z0-9-]+$", description="e.g. 'ELEC-001', stored in upper case"),
]
ProductName = Annotated[str, Field(min_length=2, max_length=120, pattern=r"\S")]
Description = Annotated[str, Field(max_length=2000)]
Price = Annotated[Decimal, Field(gt=0, le=Decimal("1000000"), max_digits=10, decimal_places=2)]
Stock = Annotated[int, Field(ge=0, le=100_000)]
CategoryId = Annotated[int, Field(gt=0)]


class ProductCreate(BaseModel):
    """Body for POST /api/admin/products."""

    sku: Sku
    name: ProductName
    description: Description = ""
    price: Price
    stock: Stock = 0
    category_id: CategoryId


class ProductUpdate(BaseModel):
    """Body for PUT /api/admin/products/{id}: every field optional, only those sent change."""

    sku: Sku | None = None
    name: ProductName | None = None
    description: Description | None = None
    price: Price | None = None
    stock: Stock | None = None
    category_id: CategoryId | None = None
    is_active: bool | None = None


class ProductOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    sku: str
    name: str
    description: str
    price: Money
    stock: int
    category_id: int
    is_active: bool
    created_at: datetime
    updated_at: datetime
