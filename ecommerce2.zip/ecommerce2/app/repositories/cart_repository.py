"""Cart repository: database queries for the `cart_items` table."""

from sqlalchemy import delete, select

from app.models import CartItem
from app.repositories.base import BaseRepository


class CartRepository(BaseRepository):
    async def get_by_id(self, item_id: int) -> CartItem | None:
        return await self.db.get(CartItem, item_id)

    async def get_for_user(self, user_id: int) -> list[CartItem]:
        query = select(CartItem).where(CartItem.user_id == user_id).order_by(CartItem.id)
        return list(await self.db.scalars(query))

    async def get_line(self, user_id: int, product_id: int) -> CartItem | None:
        query = select(CartItem).where(CartItem.user_id == user_id, CartItem.product_id == product_id)
        return await self.db.scalar(query)

    async def add(self, item: CartItem) -> CartItem:
        self.db.add(item)
        return await self._save(item)

    async def save(self, item: CartItem) -> CartItem:
        return await self._save(item)

    async def delete(self, item: CartItem) -> None:
        await self.db.delete(item)
        await self.db.commit()

    async def clear_for_user(self, user_id: int) -> None:
        """Empty the cart. NO commit: checkout commits it together with the new order."""
        await self.db.execute(delete(CartItem).where(CartItem.user_id == user_id))
