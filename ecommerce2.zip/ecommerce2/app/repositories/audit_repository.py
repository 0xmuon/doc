"""Audit repository: database queries for the `audit_logs` table."""

from sqlalchemy import select

from app.models import AuditLog
from app.repositories.base import BaseRepository


class AuditRepository(BaseRepository):
    async def add(self, entry: AuditLog) -> AuditLog:
        self.db.add(entry)
        return await self._save(entry)

    async def list_recent(self, limit: int = 50) -> list[AuditLog]:
        query = select(AuditLog).order_by(AuditLog.id.desc()).limit(limit)
        return list(await self.db.scalars(query))
