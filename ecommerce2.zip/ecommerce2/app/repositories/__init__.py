"""Repositories: database queries, one class per table."""

from app.repositories.audit_repository import AuditRepository
from app.repositories.cart_repository import CartRepository
from app.repositories.category_repository import CategoryRepository
from app.repositories.order_repository import OrderRepository
from app.repositories.product_repository import ProductRepository
from app.repositories.user_repository import UserRepository

__all__ = [
    "AuditRepository",
    "CartRepository",
    "CategoryRepository",
    "OrderRepository",
    "ProductRepository",
    "UserRepository",
]
