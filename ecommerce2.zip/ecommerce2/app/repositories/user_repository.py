"""User repository: database queries for the `users` table."""

from sqlalchemy import select

from app.models import User
from app.repositories.base import BaseRepository


class UserRepository(BaseRepository):
    """Database operations for users. Receives the request's AsyncSession."""

    async def get_by_id(self, user_id: int) -> User | None:
        return await self.db.get(User, user_id)

    async def get_by_username(self, username: str) -> User | None:
        return await self.db.scalar(select(User).where(User.username == username))

    async def get_by_email(self, email: str) -> User | None:
        return await self.db.scalar(select(User).where(User.email == email))

    async def add(self, user: User) -> User:
        """Insert a new row."""
        self.db.add(user)
        return await self._save(user)

    async def save(self, user: User) -> User:
        """Persist changes made to an object that was loaded from this session."""
        return await self._save(user)
