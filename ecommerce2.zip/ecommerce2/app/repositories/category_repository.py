"""Category repository: database queries for the `categories` table."""

from sqlalchemy import func, select

from app.models import Category
from app.repositories.base import BaseRepository


class CategoryRepository(BaseRepository):
    async def get_by_id(self, category_id: int) -> Category | None:
        return await self.db.get(Category, category_id)

    async def get_by_name(self, name: str) -> Category | None:
        """Case-insensitive: "books" finds "Books"."""
        return await self.db.scalar(select(Category).where(func.lower(Category.name) == name.lower()))

    async def get_all(self, active_only: bool = True) -> list[Category]:
        query = select(Category).order_by(Category.name)
        if active_only:
            query = query.where(Category.is_active.is_(True))
        return list(await self.db.scalars(query))

    async def add(self, category: Category) -> Category:
        self.db.add(category)
        return await self._save(category)

    async def save(self, category: Category) -> Category:
        return await self._save(category)
