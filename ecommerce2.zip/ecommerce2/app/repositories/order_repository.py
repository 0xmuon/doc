"""Order repository: database queries for the `orders` and `order_items` tables."""

from sqlalchemy import select

from app.models import Order, OrderStatus
from app.repositories.base import BaseRepository


class OrderRepository(BaseRepository):
    async def get_by_id(self, order_id: int) -> Order | None:
        return await self.db.get(Order, order_id)

    async def list_for_user(self, user_id: int) -> list[Order]:
        """A customer's order history, newest first."""
        query = select(Order).where(Order.user_id == user_id).order_by(Order.id.desc())
        return list(await self.db.scalars(query))

    async def list_all(self, status: OrderStatus | None = None) -> list[Order]:
        """Every order (admin/support view), newest first, optionally one status only."""
        query = select(Order).order_by(Order.id.desc())
        if status is not None:
            query = query.where(Order.status == status)
        return list(await self.db.scalars(query))

    async def add_pending(self, order: Order) -> Order:
        """Stage a new order (and its items) WITHOUT committing; flush assigns the id."""
        self.db.add(order)
        await self.db.flush()
        return order

    async def save(self, order: Order) -> Order:
        return await self._save(order)
