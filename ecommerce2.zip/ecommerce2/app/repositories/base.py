"""
Base repository: what every repository shares.

Student notes:
- All repositories of one request share the SAME AsyncSession, so changes made through
  different repositories land in one transaction. commit() through any of them commits all.
- Simple writes (add/save) commit right away. A multi-table flow such as checkout stages
  its changes first and calls commit() once at the end: all or nothing.
- No explicit rollback: if a request fails before commit, closing its session (get_db)
  rolls the uncommitted changes back.
"""

from typing import TypeVar

from sqlalchemy.ext.asyncio import AsyncSession

T = TypeVar("T")


class BaseRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def commit(self) -> None:
        await self.db.commit()

    async def _save(self, obj: T) -> T:
        """Commit, then reload values the database set (id, created_at, updated_at)."""
        await self.db.commit()
        await self.db.refresh(obj)
        return obj
