"""
Product repository: database queries for the `products` table.

Student notes:
- get_many_for_update() uses SELECT ... FOR UPDATE: the rows stay locked until commit, so
  two customers checking out the last unit at the same moment can't both get it. The second
  checkout waits, then sees the new stock. (SQLite has no row locks and ignores it.)
- populate_existing=True: refresh objects already in the session with the fresh row values,
  otherwise SQLAlchemy would hand back the cached (possibly stale) stock.
"""

from decimal import Decimal

from sqlalchemy import or_, select

from app.models import Product
from app.repositories.base import BaseRepository


class ProductRepository(BaseRepository):
    async def get_by_id(self, product_id: int) -> Product | None:
        return await self.db.get(Product, product_id)

    async def get_by_sku(self, sku: str) -> Product | None:
        return await self.db.scalar(select(Product).where(Product.sku == sku))

    async def list_active(self, *, category_id: int | None = None, skip: int = 0, limit: int = 20) -> list[Product]:
        query = select(Product).where(Product.is_active.is_(True))
        if category_id is not None:
            query = query.where(Product.category_id == category_id)
        query = query.order_by(Product.id).offset(skip).limit(limit)
        return list(await self.db.scalars(query))

    async def search(
        self,
        *,
        text: str | None = None,
        category_id: int | None = None,
        min_price: Decimal | None = None,
        max_price: Decimal | None = None,
        skip: int = 0,
        limit: int = 20,
    ) -> list[Product]:
        """Active products matching every filter given. `text` searches name and description."""
        query = select(Product).where(Product.is_active.is_(True))
        if text:
            pattern = f"%{text}%"
            query = query.where(or_(Product.name.ilike(pattern), Product.description.ilike(pattern)))
        if category_id is not None:
            query = query.where(Product.category_id == category_id)
        if min_price is not None:
            query = query.where(Product.price >= min_price)
        if max_price is not None:
            query = query.where(Product.price <= max_price)
        query = query.order_by(Product.name).offset(skip).limit(limit)
        return list(await self.db.scalars(query))

    async def get_many_for_update(self, product_ids: list[int]) -> dict[int, Product]:
        """Load and LOCK these products (ordered by id, so two checkouts never deadlock)."""
        query = (
            select(Product)
            .where(Product.id.in_(product_ids))
            .order_by(Product.id)
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        return {product.id: product for product in await self.db.scalars(query)}

    async def add(self, product: Product) -> Product:
        self.db.add(product)
        return await self._save(product)

    async def save(self, product: Product) -> Product:
        return await self._save(product)
