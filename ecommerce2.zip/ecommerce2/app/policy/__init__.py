"""
Authorization policy: Casbin decides who may do what, using model.conf and policy.csv.

Student notes:
- Routes only ASK ("may this user read orders?") and policy.csv ANSWERS. Changing a
  permission is a one-line edit to policy.csv, readable without knowing Python.
- RBAC (role-based): "admins may create products". The role is enough.
- ABAC (attribute-based): "customers may read an order IF they placed it". The rule needs
  an attribute of the record (`user_id`), so the route loads the record first and passes
  its owner as `owner_id`.
- The files are read once, at startup: after editing policy.csv, `docker compose restart api`.
- Denied = ForbiddenError = 403.
- check_permission() knows nothing about HTTP or FastAPI. Routes reach it two ways:
      Depends(authorize(...))        a dependency (routes/dependencies.py), when only
                                     the role matters (RBAC)
      check_permission(..., owner_id=)  a call inside the route, when the rule needs a
                                     record the route must load first (ABAC)
"""

from pathlib import Path

import casbin

from app.core import ForbiddenError
from app.models import User

POLICY_DIR = Path(__file__).parent  # this folder: model.conf and policy.csv live here

enforcer = casbin.Enforcer(str(POLICY_DIR / "model.conf"), str(POLICY_DIR / "policy.csv"))


def check_permission(user: User, resource: str, action: str, owner_id: int | None = None) -> None:
    """Ask the policy; raise 403 if `user` may not do `action` on `resource`."""
    allowed = enforcer.enforce(user.role.value, user.id, resource, action, owner_id)
    if not allowed:
        raise ForbiddenError(f"Role '{user.role.value}' may not {action} {resource}")
