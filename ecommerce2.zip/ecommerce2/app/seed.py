"""
Seed script: demo users, categories and products. Safe to run more than once
(existing rows are skipped).

    docker compose exec api python -m app.seed

Student notes:
- It goes through the real services, so passwords are hashed and every business rule
  (unique SKU, active category, ...) applies, exactly as through the API.
"""

import asyncio
from decimal import Decimal

from app.core import Base, engine
from app.core.database import SessionLocal
from app.models import UserRole
from app.repositories import CategoryRepository, ProductRepository, UserRepository
from app.schemas import CategoryCreate, ProductCreate, UserRegister
from app.services import AuthService, CategoryService, ProductService

# (username, email, full name, password, role)
USERS = [
    ("priya", "priya@example.com", "Priya Sharma", "priya1234", UserRole.ADMIN),
    ("rahul", "rahul@example.com", "Rahul Verma", "rahul1234", UserRole.SUPPORT),
    ("aman", "aman@example.com", "Aman Gupta", "aman1234", UserRole.CUSTOMER),
    ("kavya", "kavya@example.com", "Kavya Iyer", "kavya1234", UserRole.CUSTOMER),
]

CATEGORIES = {
    "Electronics": "Phones, audio and accessories",
    "Books": "Fiction, non-fiction and technical books",
    "Clothing": "Everyday wear",
    "Home & Kitchen": "Cookware and home essentials",
}

# (sku, name, description, price, stock, category)
PRODUCTS = [
    ("ELEC-001", "Wireless Headphones", "Over-ear, 30h battery, noise cancelling", "2999.00", 25, "Electronics"),
    ("ELEC-002", "USB-C Charger 65W", "Fast charger for laptops and phones", "1499.00", 40, "Electronics"),
    ("ELEC-003", "Bluetooth Speaker", "Portable, water resistant", "1899.00", 15, "Electronics"),
    ("ELEC-004", "Wireless Mouse", "Silent clicks, 2.4 GHz", "599.00", 60, "Electronics"),
    ("BOOK-001", "Clean Code", "A handbook of agile software craftsmanship", "799.00", 30, "Books"),
    ("BOOK-002", "Designing Data-Intensive Applications", "Reliable, scalable systems", "1299.00", 12, "Books"),
    ("BOOK-003", "The Pragmatic Programmer", "From journeyman to master", "899.00", 20, "Books"),
    ("CLTH-001", "Cotton T-Shirt", "Unisex, 100% cotton", "499.00", 100, "Clothing"),
    ("CLTH-002", "Denim Jacket", "Classic blue denim", "2499.00", 8, "Clothing"),
    ("HOME-001", "Non-Stick Frying Pan", "28 cm, induction friendly", "1199.00", 18, "Home & Kitchen"),
    ("HOME-002", "Steel Water Bottle", "1 litre, keeps cold 24h", "699.00", 50, "Home & Kitchen"),
    ("HOME-003", "Chef's Knife", "20 cm stainless steel", "1599.00", 3, "Home & Kitchen"),
]


async def create_users(db) -> None:
    repository = UserRepository(db)
    service = AuthService(repository)
    for username, email, full_name, password, role in USERS:
        if await repository.get_by_username(username) is not None:
            print(f"  = user {username} already exists")
            continue
        data = UserRegister(username=username, email=email, full_name=full_name, password=password)
        await service.create_user(data, role)
        print(f"  + user {username} / {password} ({role.value})")


async def create_categories(db) -> dict[str, int]:
    repository = CategoryRepository(db)
    service = CategoryService(repository)
    ids = {}
    for name, description in CATEGORIES.items():
        category = await repository.get_by_name(name)
        if category is None:
            category = await service.create_category(CategoryCreate(name=name, description=description))
            print(f"  + category {name}")
        ids[name] = category.id
    return ids


async def create_products(db, category_ids: dict[str, int]) -> None:
    repository = ProductRepository(db)
    service = ProductService(repository, CategoryRepository(db))
    for sku, name, description, price, stock, category in PRODUCTS:
        if await repository.get_by_sku(sku) is not None:
            print(f"  = product {sku} already exists")
            continue
        data = ProductCreate(
            sku=sku,
            name=name,
            description=description,
            price=Decimal(price),
            stock=stock,
            category_id=category_ids[category],
        )
        await service.create_product(data)
        print(f"  + product {sku} {name}")


async def main() -> None:
    # Make sure the tables exist, in case the API hasn't started yet.
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with SessionLocal() as db:  # closed automatically at the end of the block
        print("Users:")
        await create_users(db)
        print("Categories:")
        category_ids = await create_categories(db)
        print("Products:")
        await create_products(db, category_ids)
        print("Done.")

    await engine.dispose()  # close the connection pool before the script ends


if __name__ == "__main__":
    asyncio.run(main())
