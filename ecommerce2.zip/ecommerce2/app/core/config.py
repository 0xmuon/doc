"""
Settings: every value comes from an environment variable (see .env.example).

Student notes:
- pydantic-settings reads environment variables by field name (case-insensitive):
  `DATABASE_URL` fills `database_url`. Values are converted and validated by type.
- Fields without a default are REQUIRED: the app refuses to start without them.
- `lru_cache` makes `get_settings()` build the object once; every import shares it.
"""

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """All configuration in one typed object. Defaults apply when a variable is not set."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "ECommerce API"
    app_version: str = "2.0.0"
    # PostgreSQL: postgresql+psycopg://user:password@db:5432/ecommerceDB
    # SQLite:     sqlite+aiosqlite:///./ecommerce.db
    database_url: str
    log_level: str = "INFO"  # the lowest level that is shown (see core/logging_config.py)

    # Access tokens (JWT)
    jwt_secret_key: str  # required: no default on purpose
    jwt_algorithm: str = "HS256"  # HMAC with SHA-256: one shared secret signs and checks
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7

    # Business rules
    max_quantity_per_item: int = 10  # most units of ONE product in a cart line
    currency: str = "INR"

    # External services. "provider" is the fake service container in docker-compose.
    payment_gateway_url: str = "http://provider:9000"
    notification_service_url: str = "http://provider:9000"
    external_timeout_seconds: float = 2.0  # per HTTP attempt
    external_max_attempts: int = 3  # first try + retries
    external_retry_base_delay: float = 0.5  # 0.5s, 1s, 2s ... (exponential backoff)


@lru_cache
def get_settings() -> Settings:
    """Build Settings once. lru_cache returns the same object on every later call."""
    return Settings()  # type: ignore[call-arg]  # required values come from the environment


# The one shared settings object. Other files use: `from app.core import settings`.
settings = get_settings()
