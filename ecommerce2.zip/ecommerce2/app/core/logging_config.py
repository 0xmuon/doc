"""
Structured logging: every log line is ONE line of JSON.

Student notes:
- JSON lines can be searched and filtered by tools (Loki, ELK, CloudWatch): e.g. "all lines
  with request_id = 3f2a9c1b" shows the full story of one request, across layers.
- `request_id_var` is a ContextVar: each request (and each async task) sees its own value.
  The middleware in main.py sets it; every log line and every error response include it.
- Extra fields: logger.info("Order paid", extra={"context": {"order_id": 7}}) adds
  "order_id": 7 to that line. Handy for async flows (payments, notifications).
"""

import json
import logging
from contextvars import ContextVar

from app.core.config import settings

# The current request's id. "-" outside any request (startup, the seed script).
request_id_var: ContextVar[str] = ContextVar("request_id", default="-")


class JsonFormatter(logging.Formatter):
    """Turn a log record into one line of JSON."""

    def format(self, record: logging.LogRecord) -> str:
        line = {
            "time": self.formatTime(record),
            "level": record.levelname,
            "logger": record.name,
            "request_id": request_id_var.get(),
            "message": record.getMessage(),
        }
        context = getattr(record, "context", None)
        if isinstance(context, dict):
            line.update(context)
        if record.exc_info:
            line["exception"] = self.formatException(record.exc_info)  # the traceback
        return json.dumps(line, default=str)


def setup_logging() -> None:
    """Send log lines at or above LOG_LEVEL to the terminal, as JSON."""
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    logging.basicConfig(level=settings.log_level.upper(), handlers=[handler], force=True)
