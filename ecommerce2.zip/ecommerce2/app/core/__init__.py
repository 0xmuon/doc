"""
Core: settings, database setup and app errors, shared by every layer.

Other modules import from here: `from app.core import DBSession, settings`.
Order matters: config must be imported before database, because database uses settings.
(Files INSIDE core/ import each other directly, e.g. `from app.core.config import ...`,
to avoid a circular import through this file.)
"""

from app.core.config import settings
from app.core.database import Base, DBSession, SessionFactory, SessionLocal, engine
from app.core.exceptions import (
    AppError,
    BusinessRuleError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
    ServiceUnavailableError,
    UnauthorizedError,
    register_exception_handlers,
)

__all__ = [
    "AppError",
    "Base",
    "BusinessRuleError",
    "ConflictError",
    "DBSession",
    "ForbiddenError",
    "NotFoundError",
    "ServiceUnavailableError",
    "SessionFactory",
    "SessionLocal",
    "UnauthorizedError",
    "engine",
    "register_exception_handlers",
    "settings",
]
