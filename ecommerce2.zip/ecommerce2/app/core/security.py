"""
Security helpers: password hashing and JWT access/refresh tokens.

Student notes:
- Passwords are stored only as Argon2 hashes. Hashing is slow ON PURPOSE (it makes guessing
  expensive) and CPU-bound, so services call these functions with asyncio.to_thread(): the
  event loop keeps serving other requests meanwhile (see services/auth_service.py).
- Two token types, told apart by the "type" claim:
    access  (30 min) -> sent as `Authorization: Bearer ...` on every request
    refresh (7 days) -> sent only to POST /api/auth/refresh to get a new pair
  A refresh token is refused on normal routes and vice versa.
- The accepted algorithm comes from US, never from the token itself.
"""

from datetime import UTC, datetime, timedelta

import jwt
from pwdlib import PasswordHash

from app.core.config import settings
from app.core.exceptions import UnauthorizedError

ACCESS = "access"
REFRESH = "refresh"

# Argon2 with pwdlib's recommended settings.
password_hash = PasswordHash.recommended()


def hash_password(password: str) -> str:
    """'secret123' -> '$argon2id$v=19$m=65536,t=3,p=4$...' (different every time)."""
    return password_hash.hash(password)


def verify_password(password: str, hashed_password: str) -> bool:
    """True if `password` is the one that produced `hashed_password`."""
    return password_hash.verify(password, hashed_password)


def create_token(subject: str, token_type: str, expires_in: timedelta) -> str:
    """A signed token saying "this is `subject`", valid for `expires_in`."""
    now = datetime.now(UTC)
    payload = {"sub": subject, "type": token_type, "iat": now, "exp": now + expires_in}
    return jwt.encode(payload, settings.jwt_secret_key, algorithm=settings.jwt_algorithm)


def create_access_token(username: str) -> str:
    return create_token(username, ACCESS, timedelta(minutes=settings.access_token_expire_minutes))


def create_refresh_token(username: str) -> str:
    return create_token(username, REFRESH, timedelta(days=settings.refresh_token_expire_days))


def decode_token(token: str, expected_type: str = ACCESS) -> str:
    """Check signature, expiry and type; return the username inside the token."""
    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret_key,
            algorithms=[settings.jwt_algorithm],
            options={"require": ["exp", "sub"]},
        )
    except jwt.ExpiredSignatureError as exc:  # `exp` is in the past
        raise UnauthorizedError("Token has expired") from exc
    except jwt.InvalidTokenError as exc:  # bad signature, garbled token, ...
        raise UnauthorizedError("Invalid token") from exc
    if payload.get("type") != expected_type:
        raise UnauthorizedError(f"Wrong token type: expected an {expected_type} token")
    return payload["sub"]
