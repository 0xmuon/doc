"""
Retry with exponential backoff, for calls to external services.

Student notes:
- Retry only errors that may go away by themselves: timeouts, connection errors, 5xx.
  Never retry a clear "no" (e.g. card declined): the answer will not change.
- Backoff: wait base_delay, then 2x, then 4x ... so a struggling service gets breathing room.
- `await asyncio.sleep()` waits WITHOUT blocking: other requests keep being served.
- Retrying a payment is only safe because each charge carries an Idempotency-Key
  (the order number): the gateway never charges the same order twice.
"""

import asyncio
import logging
from collections.abc import Awaitable, Callable

logger = logging.getLogger(__name__)


async def retry_async[T](
    func: Callable[..., Awaitable[T]],
    *args,
    attempts: int,
    base_delay: float,
    retry_on: tuple[type[Exception], ...],
    operation: str,
) -> T:
    """Run `await func(*args)` up to `attempts` times while it raises one of `retry_on`."""
    for attempt in range(1, attempts + 1):
        try:
            return await func(*args)
        except retry_on as exc:
            if attempt >= attempts:
                logger.warning("%s failed after %d attempts: %s", operation, attempts, exc)
                raise
            delay = base_delay * 2 ** (attempt - 1)
            logger.warning("%s failed (attempt %d/%d: %s); retrying in %.2fs", operation, attempt, attempts, exc, delay)
            await asyncio.sleep(delay)
    raise RuntimeError("retry_async needs attempts >= 1")
