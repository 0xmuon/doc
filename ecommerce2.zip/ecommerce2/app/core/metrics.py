"""
Metrics: totals over ALL requests, per route. Shown at /metrics.

Student notes:
- Logs tell the story of ONE request. Metrics sum up all of them: how many, how many
  failed, how fast. They answer "is the app healthy right now?".
- Error rate counts only 5xx (our failures), not 4xx (the client sent something wrong).
- Routes are counted by TEMPLATE: /api/products/1 and /api/products/2 are both
  "GET /api/products/{product_id}". With real URLs, every id would get its own row.
- The numbers live in memory and start from zero when the app restarts.
"""

# "GET /api/products" -> {"requests": 25, "errors": 5, "total_ms": 200.0}
stats: dict[str, dict] = {}


def record_request(method: str, route: str, status: int, duration_ms: float) -> None:
    """Count one finished request."""
    route_stats = stats.setdefault(f"{method} {route}", {"requests": 0, "errors": 0, "total_ms": 0.0})
    route_stats["requests"] += 1
    route_stats["errors"] += status >= 500  # True counts as 1
    route_stats["total_ms"] += duration_ms


def metrics_report() -> dict:
    """Request count, error rate and average time per route."""
    return {
        route: {
            "requests": s["requests"],
            "error_rate": round(s["errors"] / s["requests"], 3),
            "avg_ms": round(s["total_ms"] / s["requests"], 1),
        }
        for route, s in stats.items()
    }
