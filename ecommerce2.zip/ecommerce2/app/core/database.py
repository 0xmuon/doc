"""
Database: the async engine, the session factory and the `DBSession` dependency.

Student notes:
- The engine manages the connection pool. Creating it does NOT connect; the first query does.
- One request = one AsyncSession = one transaction. Repositories share it, so a service can
  change several tables and commit them together (see OrderService.checkout).
- Background tasks run after the request's session is closed, so they open their own
  session from `SessionFactory`. Tests replace that factory with one for the test database.
"""

from collections.abc import AsyncIterator
from typing import Annotated

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from app.core.config import settings

# pool_pre_ping: test a pooled connection before using it (survives a DB restart).
engine = create_async_engine(settings.database_url, pool_pre_ping=True)

# expire_on_commit=False: objects keep their values after commit, so we can still return them.
SessionLocal = async_sessionmaker(engine, expire_on_commit=False)


class Base(DeclarativeBase):
    """
    Parent class for all database models.

    eager_defaults: values the DATABASE sets (created_at, updated_at) are read back in the
    same INSERT/UPDATE statement. Without it SQLAlchemy would fetch them later, on attribute
    access - a hidden lazy load, which async code forbids (MissingGreenlet error).
    """

    __mapper_args__ = {"eager_defaults": True}


async def get_db() -> AsyncIterator[AsyncSession]:
    """FastAPI dependency: open a session for the request, always close it afterwards."""
    async with SessionLocal() as db:
        yield db


def get_session_factory() -> async_sessionmaker[AsyncSession]:
    """FastAPI dependency: the factory background tasks use to open their own session."""
    return SessionLocal


# Shortcuts for route parameters: `def route(db: DBSession)` means
# "FastAPI, call get_db() and give me the AsyncSession it yields".
DBSession = Annotated[AsyncSession, Depends(get_db)]
SessionFactory = Annotated[async_sessionmaker[AsyncSession], Depends(get_session_factory)]
