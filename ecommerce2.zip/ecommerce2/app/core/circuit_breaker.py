"""
Circuit breaker: stop calling a service that keeps failing, give it time to recover.

Student notes:
- closed    -> calls go through; failures are counted.
- open      -> after `max_failures` failures in a row, calls fail at once with
               CircuitOpenError (no waiting for timeouts) for `reset_seconds`.
- half-open -> after that time, ONE trial call is let through:
               success closes the circuit, failure opens it again.
- `excluded` exceptions are answers, not outages: a "card declined" (HTTP 402) means the
  payment gateway is healthy, so it must not trip the breaker.
"""

import logging
import time
from collections.abc import Awaitable, Callable

logger = logging.getLogger(__name__)


class CircuitOpenError(Exception):
    """Raised instead of calling the service while the breaker is open."""


class CircuitBreaker:
    def __init__(
        self,
        name: str,
        max_failures: int,
        reset_seconds: float,
        excluded: tuple[type[BaseException], ...] = (),
    ):
        self.name = name
        self.max_failures = max_failures
        self.reset_seconds = reset_seconds
        self.excluded = excluded
        self.state = "closed"
        self.failures = 0
        self.opened_at = 0.0

    async def call[T](self, func: Callable[..., Awaitable[T]], *args) -> T:
        """Run `await func(*args)`, unless the breaker is open."""
        if self.state == "open":
            if time.monotonic() - self.opened_at < self.reset_seconds:
                raise CircuitOpenError(f"{self.name} circuit breaker is open")
            self._set_state("half-open")  # time for one trial call

        try:
            result = await func(*args)
        except self.excluded:
            self._record_success()  # the service answered, so it is up
            raise
        except Exception:
            self.failures += 1
            if self.state == "half-open" or self.failures >= self.max_failures:
                self.opened_at = time.monotonic()
                self._set_state("open")
            raise

        self._record_success()
        return result

    def _record_success(self) -> None:
        self.failures = 0
        if self.state == "half-open":
            self._set_state("closed")

    def _set_state(self, state: str) -> None:
        logger.warning("Circuit breaker %s: %s -> %s", self.name, self.state, state)
        self.state = state
