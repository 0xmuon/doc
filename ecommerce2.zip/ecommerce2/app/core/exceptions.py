"""
App errors and the handlers that turn them into JSON responses.

Student notes:
- Services raise these errors; they know nothing about HTTP. The handlers below map each
  error to its status code, so routes never build error responses by hand.
- Every error response carries the request_id: {"detail": "...", "request_id": "3f2a9c1b"}.
  A user reports the id, and we find the matching log lines (traceable errors).
- Three kinds are handled: our AppErrors, FastAPI's validation errors (422) and HTTP errors
  raised by FastAPI itself (e.g. 401 from OAuth2PasswordBearer when the token is missing).
"""

import logging

from fastapi import FastAPI, Request, status
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.logging_config import request_id_var

logger = logging.getLogger(__name__)


class AppError(Exception):
    """Base class for all app errors. Subclasses set the HTTP status code."""

    status_code: int = status.HTTP_400_BAD_REQUEST
    headers: dict[str, str] | None = None

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class UnauthorizedError(AppError):
    """We don't know who the caller is: no token, a bad token, or a wrong password."""

    status_code = status.HTTP_401_UNAUTHORIZED
    headers = {"WWW-Authenticate": "Bearer"}  # tells the client which scheme to use


class ForbiddenError(AppError):
    """We know who the caller is, but they aren't allowed to do this."""

    status_code = status.HTTP_403_FORBIDDEN


class NotFoundError(AppError):
    """The requested record doesn't exist."""

    status_code = status.HTTP_404_NOT_FOUND


class ConflictError(AppError):
    """The request is valid, but not allowed in the record's current state (or a duplicate)."""

    status_code = status.HTTP_409_CONFLICT


class BusinessRuleError(AppError):
    """The input breaks a business rule (e.g. empty cart, unknown category)."""

    status_code = status.HTTP_422_UNPROCESSABLE_CONTENT


class ServiceUnavailableError(AppError):
    """A dependency we need is down (e.g. the database)."""

    status_code = status.HTTP_503_SERVICE_UNAVAILABLE


def error_response(status_code: int, detail: object, headers: dict[str, str] | None = None) -> JSONResponse:
    """The one error format of the API."""
    return JSONResponse(
        status_code=status_code,
        content={"detail": detail, "request_id": request_id_var.get()},
        headers=headers,
    )


def register_exception_handlers(app: FastAPI) -> None:
    """Tell FastAPI how to turn errors into JSON responses."""

    @app.exception_handler(AppError)
    async def handle_app_error(request: Request, exc: AppError) -> JSONResponse:
        logger.warning("%s %s -> %d %s", request.method, request.url.path, exc.status_code, exc.message)
        return error_response(exc.status_code, exc.message, exc.headers)

    @app.exception_handler(RequestValidationError)
    async def handle_validation_error(request: Request, exc: RequestValidationError) -> JSONResponse:
        logger.info("%s %s -> 422 invalid input", request.method, request.url.path)
        return error_response(status.HTTP_422_UNPROCESSABLE_CONTENT, jsonable_encoder(exc.errors()))

    @app.exception_handler(StarletteHTTPException)
    async def handle_http_exception(request: Request, exc: StarletteHTTPException) -> JSONResponse:
        return error_response(exc.status_code, exc.detail, getattr(exc, "headers", None))
