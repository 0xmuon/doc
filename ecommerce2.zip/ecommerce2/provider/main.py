"""
Fake external services: a payment gateway and a notification (e-mail) service.

Runs as its own container (docker-compose service "provider", port 9000), so the API
talks to it over real HTTP, exactly like a third-party service. Swagger: localhost:9000/docs

Switch its behaviour to test the API's timeouts, retries and circuit breaker:

    curl -X PUT localhost:9000/mode/fail      # every call -> 503
    curl -X PUT localhost:9000/mode/slow      # every call waits 10s (API times out after 2s)
    curl -X PUT localhost:9000/mode/flaky     # every 2nd call -> 503 (a retry succeeds)
    curl -X PUT localhost:9000/mode/decline   # payments -> 402 card declined
    curl -X PUT localhost:9000/mode/ok        # back to normal

Payments above 50,000 are always declined (an easy way to see a decline).
"""

import asyncio
import uuid
from decimal import Decimal
from typing import Literal

from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

app = FastAPI(title="Fake External Services (payments + notifications)")

Mode = Literal["ok", "fail", "slow", "flaky", "decline"]
mode: Mode = "ok"
calls = 0
approved: dict[str, str] = {}  # Idempotency-Key -> payment reference
DECLINE_ABOVE = Decimal("50000")


class Charge(BaseModel):
    order_number: str
    amount: Decimal
    currency: str = "INR"


class Notification(BaseModel):
    to: str
    subject: str
    message: str


async def apply_mode() -> None:
    """Fail, wait or pass, depending on the current mode."""
    global calls
    calls += 1
    if mode == "fail" or (mode == "flaky" and calls % 2 == 1):
        raise HTTPException(503, f"Service is down (mode={mode})")
    if mode == "slow":
        await asyncio.sleep(10)


@app.post("/payments/charge")
async def charge(body: Charge, idempotency_key: str | None = Header(None)):
    """Charge a payment. The same Idempotency-Key never charges twice."""
    if idempotency_key and idempotency_key in approved:
        print(f"REPLAY {idempotency_key}: already paid as {approved[idempotency_key]}", flush=True)
        return {"status": "approved", "reference": approved[idempotency_key], "replayed": True}
    await apply_mode()
    if mode == "decline" or body.amount > DECLINE_ABOVE:
        raise HTTPException(402, "Card declined by the issuing bank")
    reference = f"PAY-{uuid.uuid4().hex[:10].upper()}"
    if idempotency_key:
        approved[idempotency_key] = reference
    print(f"CHARGED {body.amount} {body.currency} for {body.order_number}: {reference}", flush=True)
    return {"status": "approved", "reference": reference}


@app.post("/notify")
async def notify(notification: Notification):
    """'Send' an e-mail: printed to this container's logs."""
    await apply_mode()
    print(f"SENT to {notification.to}: [{notification.subject}] {notification.message}", flush=True)
    return {"status": "sent"}


@app.put("/mode/{new_mode}")
async def set_mode(new_mode: Mode):
    """Switch mode: ok, fail, slow, flaky or decline."""
    global mode, calls
    mode, calls = new_mode, 0
    return {"mode": mode}


@app.get("/mode")
async def get_mode():
    return {"mode": mode}
