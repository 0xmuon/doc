# ECommerce API — Week 3 (ECommerce2)

The Week 2 Online Shopping API, enhanced into a secure, observable, async, tested platform:
JWT auth (access + refresh), RBAC/ABAC with Casbin, admin APIs, an external payment gateway
and notification service with timeout / retry / circuit breaker, async checkout with background
tasks, structured logging, traceable errors, metrics, and a unit + integration test suite.

**Stack:** Python 3.12 · FastAPI · SQLAlchemy 2 (async) · PostgreSQL (or SQLite) · Pydantic v2 ·
Casbin · httpx · pytest · ruff · Docker Compose · VS Code (debugpy)

---

## 1. Run it

Same host ports as the logistics project, so stop that one first:

```bash
cd ../logistics2 && docker compose down        # frees 8000, 5433, 5678, 9000
cd ../ecommerce2
cp .env.example .env                           # only if .env is missing; set JWT_SECRET_KEY
docker compose up --build
docker compose exec api python -m app.seed     # demo users, categories, products
```

| Port | What |
|---|---|
| 8000 | API — Swagger at http://localhost:8000/docs |
| 5433 | PostgreSQL (`ecommerceDB`, user/password `ecommerce`) |
| 5678 | debugpy — VS Code "Attach to API in Docker" |
| 9000 | Fake external services — http://localhost:9000/docs |

**Seeded users** (password = name + `1234`)

| User | Role |
|---|---|
| `priya` / `priya1234` | admin |
| `rahul` / `rahul1234` | support |
| `aman` / `aman1234`, `kavya` / `kavya1234` | customer |

In Swagger click **Authorize**, enter a username and password, and every request is sent with the token.

**Without Docker (SQLite):** `pip install -r requirements.txt`, then
`DATABASE_URL=sqlite+aiosqlite:///./ecommerce.db uvicorn app.main:app --reload`
(and `uvicorn provider.main:app --port 9000` in a second terminal, with
`PAYMENT_GATEWAY_URL=http://localhost:9000` and `NOTIFICATION_SERVICE_URL=http://localhost:9000`).
VS Code launch configs for both are in `.vscode/launch.json`.

---

## 2. Endpoints

| Method | Path | Who | Notes |
|---|---|---|---|
| POST | `/api/auth/register` | public | always creates a customer |
| POST | `/api/auth/login` | public | OAuth2 form → access + refresh token |
| POST | `/api/auth/refresh` | refresh token | new token pair |
| GET | `/api/auth/me` | any user | who am I |
| GET | `/api/products` | public | active products, `?category_id&skip&limit` |
| GET | `/api/products/search` | public | `?q&category_id&min_price&max_price` |
| GET | `/api/products/{id}` | public | 404 if inactive |
| GET | `/api/categories` | public | active categories |
| GET | `/api/cart` | customer | own cart with totals |
| POST | `/api/cart/add` | customer | adds up quantities for the same product |
| PUT | `/api/cart/update/{cart_item_id}` | customer, **own line** | new quantity |
| DELETE | `/api/cart/remove/{cart_item_id}` | customer, **own line** | 204 |
| POST | `/api/orders/checkout` | customer | **async flow**, see §4 |
| GET | `/api/orders/me` | customer | order history |
| GET | `/api/orders/{id}` | owner, support, admin | |
| POST | `/api/payments/process` | customer, **own order** | retry a failed payment |
| POST | `/api/notifications/send` | support, admin | 202, sent in background |
| POST | `/api/admin/products` | admin | 409 duplicate SKU |
| PUT | `/api/admin/products/{id}` | admin | partial update |
| DELETE | `/api/admin/products/{id}` | admin | deactivates (soft delete) |
| POST | `/api/admin/categories` | admin | 409 duplicate name (any case) |
| PUT | `/api/admin/categories/{id}` | admin | |
| GET | `/api/admin/orders` | admin, support | order summaries, `?status=Confirmed` |
| GET | `/api/admin/audit-logs` | admin | who did what |
| GET | `/health`, `/health/db`, `/metrics` | public | liveness, readiness, per-route stats |
| GET | `/demo/*` | public | sync vs async demonstration |

---

## 3. Architecture

```
app/
  routes/        API layer: HTTP only (status codes, dependencies, permission checks)
  services/      Service layer: business rules and validations
  repositories/  Repository layer: database queries
  models/        Data layer: SQLAlchemy models (PostgreSQL / SQLite)
  schemas/       Schema layer: Pydantic request/response models
  integrations/  External services: payment gateway, notifications
  policy/        Casbin model.conf + policy.csv (who may do what)
  core/          config, async DB session, security, errors, logging, metrics, retry, circuit breaker
  background_tasks.py  work done after the response (e-mails, audit log)
  seed.py        demo data
provider/        fake external services (own container, port 9000)
tests/           unit tests (fakes, no DB) + integration tests (HTTP + test DB)
```

**Request flow:** route → `Depends` (token → user → policy) → service → repositories → DB.
One request = one async session = one transaction.

### Authentication (Milestone 1)
- Login returns an **access token** (30 min) and a **refresh token** (7 days), told apart by a `type`
  claim; each is refused where the other belongs.
- `OAuth2PasswordBearer` + `get_current_user` protect routes. Missing/invalid/expired token → **401**,
  disabled user → **403**.
- Passwords are Argon2 hashes; hashing runs in `asyncio.to_thread` so it never blocks the event loop.

### Authorization (Milestone 2)
`app/policy/policy.csv` is the single source of truth:

| Role | Can |
|---|---|
| customer | browse, manage **own** cart, check out, view/pay **own** orders |
| admin | manage products and categories, view all orders, audit log |
| support | view all orders, contact customers — **no product admin rights** |

- **RBAC** — `Depends(authorize("products", "create"))`, a reusable dependency.
- **ABAC** — `check_permission(user, "orders", "read", owner_id=order.user_id)`; the rule
  `r.user_id == r.owner_id` lets customers see only their own records.

### Admin APIs (Milestone 3)
Product create/update/deactivate and category create/update (admin only), order summaries (admin
and support), audit log (admin). Duplicate SKU / category name → 409, invalid input → 422, unknown or
inactive category → 422. Every admin change is written to the audit log.

---

## 4. Async vs sync — what was converted and why

**Converted flow: checkout** (Week 2 had a synchronous checkout). It is now `async` end to end:
async route → async service → async repositories (async SQLAlchemy session) → non-blocking HTTP
call to the payment gateway (`httpx.AsyncClient`) → background tasks.

```
POST /api/orders/checkout
 1. load cart                                 (await DB)
 2. lock products FOR UPDATE, check all lines  (await DB)   409 → nothing changed
 3. one commit: order "Pending Payment" + items (prices copied) + stock reserved + cart emptied
 4. charge gateway: timeout 2s, 3 attempts w/ backoff, circuit breaker, Idempotency-Key
      approved          → Confirmed / Paid
      declined or down  → Payment Failed / Failed, stock released   (still 201)
 5. response sent; THEN background tasks: confirmation e-mail, audit row
```

**Why async here:** checkout spends most of its time *waiting* — on the database and above all on
the payment gateway (up to seconds, more with retries). In an async route that waiting costs no
thread: the event loop serves other customers meanwhile. Under load that means far higher
throughput with the same resources.

**Where sync is still fine:**
- `/health` is a plain `def` on purpose: no I/O, nothing to wait for. FastAPI runs sync routes in a
  thread pool, so they don't block the loop either.
- CPU-bound work (password hashing) gains nothing from `async`; it is *offloaded* with
  `asyncio.to_thread` instead.
- Scripts like `seed.py`, and code using libraries without async support.

**The trap** (try `/demo/async-blocking`): a blocking call (`time.sleep`, `requests.get`, a sync DB
driver) inside `async def` freezes the whole server. Rule: in `async def`, only `await` I/O.

**Background tasks** (`BackgroundTasks`) handle confirmation e-mails, support notifications and
audit logs. They run after the response, open their own DB session, never raise (failures are
logged), and keep the request id in their logs. For must-not-lose work, a queue (Celery/Arq) would
be the next step.

---

## 5. External integration (Milestone 4)

`app/integrations/` — `PaymentGateway` and `NotificationClient`:
- **Timeout** per attempt (`EXTERNAL_TIMEOUT_SECONDS`).
- **Retry** with exponential backoff (`EXTERNAL_MAX_ATTEMPTS`, `EXTERNAL_RETRY_BASE_DELAY`), only for
  timeouts / connection errors / 5xx. A **decline (402) is never retried**.
- **Circuit breaker**: after 5 failures in a row calls fail fast for 30 s; declines don't count.
- **Idempotency-Key** = order number, so a retried charge is never taken twice.
- **Graceful failure**: the order is kept as "Payment Failed", stock is released, the customer
  retries with `/api/payments/process`. Order and payment status always change together.

Try it with the fake provider:

```bash
curl -X PUT localhost:9000/mode/flaky     # every 2nd call fails → retries rescue checkout
curl -X PUT localhost:9000/mode/fail      # always 503 → "Payment Failed"
curl -X PUT localhost:9000/mode/slow      # 10 s → timeouts
curl -X PUT localhost:9000/mode/decline   # 402
curl -X PUT localhost:9000/mode/ok
docker compose logs -f provider           # see CHARGED / SENT lines
```

---

## 6. Logging, errors, monitoring, debugging (Milestone 5)

- **Structured logs:** one JSON line per event, each with a `request_id`; async flows add fields
  such as `order_id`. `docker compose logs api | grep <request_id>` shows one request's full story,
  including its background tasks.
- **Traceable errors:** every error body is `{"detail": ..., "request_id": ...}` and the response has
  an `X-Request-ID` header (a client-sent `X-Request-ID` is reused). Unhandled errors → clean 500,
  full traceback in the log only.
- **Custom exceptions:** `UnauthorizedError` 401, `ForbiddenError` 403, `NotFoundError` 404,
  `ConflictError` 409, `BusinessRuleError` 422, `ServiceUnavailableError` 503.
- **Monitoring:** `/metrics` (requests, 5xx error rate, avg ms per route), `/health`, `/health/db`;
  retries and circuit-breaker state changes are logged as warnings.
- **Debugging:** the API runs under debugpy; in VS Code run **Attach to API in Docker**
  and set breakpoints (e.g. in `OrderService.checkout`).

---

## 7. Testing, coverage, linting (Milestone 6)

```bash
docker compose exec api pytest                              # all tests
docker compose exec api pytest --cov=app                    # with coverage (fails below 85%)
docker compose exec api pytest -m "not integration"         # unit tests only
docker compose exec api ruff check .                        # lint
docker compose exec api ruff format --check .               # formatting
```

- **Unit tests** (`test_*_service.py`, `test_integrations.py`): services with in-memory fake
  repositories and a fake gateway; HTTP clients with `httpx.MockTransport` (timeouts, retries,
  declines, circuit breaker). No database, no network.
- **Integration tests** (`test_api_*.py`): the real app over HTTP against a separate test database
  (`ecommerceDB_test`, created automatically; a SQLite file locally), external services replaced by
  fakes through dependency overrides.
- Covered: security (401/403, expired/wrong-type tokens), every role rule, duplicate checks,
  invalid input, checkout success / empty cart / out of stock / gateway down / declined / retry,
  background notifications and audit rows, a broken mail service not breaking checkout.
- Current result: **117 tests, ~97% coverage**.

---

## 8. Git workflow

```bash
git init && git add . && git commit -m "chore: project skeleton"
git branch -M main && git remote add origin <your-repo-url> && git push -u origin main
```

One branch per milestone, merged through a pull request:

| Branch | Milestone |
|---|---|
| `feature/m1-jwt-auth` | JWT authentication, protected routes |
| `feature/m2-rbac-policy` | Casbin RBAC/ABAC, reusable checks |
| `feature/m3-admin-apis` | admin product/category/order APIs |
| `feature/m4-external-integration` | gateway + notifications, retry/timeout/breaker |
| `feature/m5-async-logging` | async checkout, background tasks, logging, errors |
| `feature/m6-tests-coverage` | tests, coverage, lint |

```bash
git switch -c feature/m1-jwt-auth
# ... work, small commits: "feat(auth): add refresh token endpoint"
git push -u origin feature/m1-jwt-auth          # open a PR into main, review, merge
git switch main && git pull                      # start the next branch from fresh main
```

Merge hygiene: run `pytest` and `ruff check .` before every PR; keep each PR to one milestone; never
commit `.env`. On a conflict: `git switch feature/x && git merge main`, edit the files between the
`<<<<<<<` / `>>>>>>>` markers, run the tests, `git add` + `git commit`, push.

---

## 9. Assumptions

- Browsing products is public; cart and orders require a customer token.
- Self-registration creates customers only; staff accounts come from the seed script.
- "Remove product" = deactivate, so past orders keep their product link.
- Stock is reserved at checkout and released if payment fails; the cart itself reserves nothing.
- Max 10 units of one product per cart line (`MAX_QUANTITY_PER_ITEM`). Prices in INR.
- Tables are created with `create_all()` at startup; Alembic migrations would be the production step.
