# ABC Shop — React frontend (User Module)

React 19 + Vite + React Router, written in **JSX only**. Props are type-checked with
**PropTypes** (the JSX equivalent of "strict typing, no `any`").
It calls the FastAPI backend in `../backend`.

## Run

**Option A — everything in Docker** (from `../backend`):

```bash
docker compose up --build          # db, api, provider AND frontend
docker compose exec api python -m app.seed
```
Open http://localhost:5173

**Option B — frontend on your machine** (backend in Docker): needs Node.js 20+.

```bash
cd frontend
npm install
npm run dev                        # http://localhost:5173
```

Log in with a seeded customer: `aman@example.com` / `aman1234`, or register a new account.

## How frontend and backend connect

- The React code calls relative URLs such as `/api/products` (`src/api/*.js`).
- `vite.config.js` proxies `/api` to the backend: `http://localhost:8000` locally,
  `http://api:8000` inside Docker (`VITE_API_PROXY_TARGET`).
- The backend also allows `http://localhost:5173` through **CORS** (`backend/app/main.py`).
- Login stores the JWT access + refresh tokens in `localStorage`; `src/api/client.js` adds
  `Authorization: Bearer ...` and refreshes the access token automatically on a 401.

## Scripts

| Command | What it does |
|---|---|
| `npm run dev` | dev server with hot reload |
| `npm run build` | production build into `dist/` |
| `npm run lint` | ESLint (React Hooks rules) |
| `npm test` | unit tests for the validation rules (Vitest) |

## Folder structure

```
src/
  main.jsx, App.jsx        entry point and routes
  api/                     one file per backend area; client.js does tokens and errors
  context/                 AuthContext (who is logged in), CartContext (the cart)
  hooks/                   useForm, useDebouncedValue, useAddToCart
  utils/                   validators (+ tests), price/date formatting
  components/layout/       Header, Menu, Footer, Layout
  components/common/       FormField, Alert, Loader, Icon, StatusBadge, ProtectedRoute
  components/products/     ProductCard, SearchBar, CategoryFilter
  components/cart/         CartItemRow, CartSummary
  components/orders/       OrderItemsTable, OrderListItem
  pages/                   one component per page
  styles/global.css
```

## Milestones → files

| Milestone | Files |
|---|---|
| 1 Registration & login with validations | `api/client.js`, `api/authApi.js`, `context/AuthContext.jsx`, `hooks/useForm.js`, `utils/validators.js`, `components/common/{FormField,Alert,Icon,Loader}.jsx`, `components/layout/*`, `pages/{RegisterPage,LoginPage,NotFoundPage}.jsx`, `App.jsx`, `main.jsx`, `styles/global.css`, `vite.config.js` |
| 2 Product listing & search | `api/productApi.js`, `hooks/useDebouncedValue.js`, `hooks/useAddToCart.js`, `utils/format.js`, `components/products/*`, `pages/{ProductListPage,ProductDetailsPage}.jsx` |
| 3 Cart management | `api/cartApi.js`, `context/CartContext.jsx`, `components/cart/*`, `components/common/ProtectedRoute.jsx`, `pages/CartPage.jsx` |
| 4 Order history | `api/orderApi.js`, `components/orders/*`, `components/common/StatusBadge.jsx`, `pages/{OrderHistoryPage,OrderDetailsPage}.jsx` |
| 5 Order placement | `pages/CheckoutPage.jsx` (+ Retry Payment in `OrderDetailsPage.jsx`) |
| 6 GitHub | `.gitignore`, this README |

## Assumptions

- Names may contain spaces between words ("Kavya Iyer"); only letters are allowed.
- Products have no images in the API, so cards show the product's initials.
- Prices are in INR, as configured in the backend.
- Admin/support accounts can browse but have no cart (the backend policy forbids it).
