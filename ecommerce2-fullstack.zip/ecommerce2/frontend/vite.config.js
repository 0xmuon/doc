/**
 * Vite config: dev server on port 5173 and the PROXY that connects the frontend to the backend.
 *
 * The React code calls relative URLs like "/api/products". In development the Vite server
 * forwards every "/api/..." request to the FastAPI backend:
 *   - running locally:        http://localhost:8000   (default)
 *   - running in Docker:      http://api:8000         (VITE_API_PROXY_TARGET in docker-compose)
 * The browser only ever talks to localhost:5173, so there is no cross-origin problem.
 * (The backend ALSO allows this origin with CORS, for when VITE_API_BASE_URL is set.)
 */
import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig(({ mode }) => {
  // "" = load every variable, including the ones docker-compose sets (process.env)
  const env = loadEnv(mode, process.cwd(), "");
  const apiTarget = env.VITE_API_PROXY_TARGET || "http://localhost:8000";

  return {
    plugins: [react()],
    server: {
      port: 5173,
      proxy: {
        "/api": { target: apiTarget, changeOrigin: true },
        "/health": { target: apiTarget, changeOrigin: true },
      },
      // Docker on Windows does not forward file-change events; polling notices edits anyway.
      watch: { usePolling: env.VITE_USE_POLLING === "true" },
    },
    test: { environment: "node" },
  };
});
