/**
 * Order details page: every product, quantity and price of one order, plus its status.
 *
 * - GET /api/orders/{id}: the backend answers 403 if the order belongs to someone else.
 * - A "Payment Failed" order shows Retry Payment -> POST /api/payments/process.
 */
import { useEffect, useState } from "react";
import { Link, useLocation, useParams } from "react-router-dom";
import { fetchOrder, retryPayment } from "../api/orderApi";
import Alert, { errorText } from "../components/common/Alert";
import Loader from "../components/common/Loader";
import StatusBadge from "../components/common/StatusBadge";
import OrderItemsTable from "../components/orders/OrderItemsTable";
import { formatDate } from "../utils/format";

export default function OrderDetailsPage() {
  const { orderId } = useParams();
  const location = useLocation();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [retrying, setRetrying] = useState(false);
  const [retryError, setRetryError] = useState("");

  useEffect(() => {
    let ignore = false;
    fetchOrder(orderId)
      .then((loaded) => !ignore && setOrder(loaded))
      .catch((err) => {
        if (ignore) return;
        if (err.status === 403) setError("You can only view your own orders.");
        else if (err.status === 404) setError("Order not found.");
        else setError(errorText(err));
      })
      .finally(() => !ignore && setLoading(false));
    return () => {
      ignore = true;
    };
  }, [orderId]);

  async function handleRetry() {
    setRetrying(true);
    setRetryError("");
    try {
      setOrder(await retryPayment(order.id));
    } catch (err) {
      setRetryError(errorText(err)); // e.g. 409: an item went out of stock meanwhile
    } finally {
      setRetrying(false);
    }
  }

  if (loading) return <Loader text="Loading order..." />;
  if (error || !order) {
    return (
      <section className="page narrow">
        <Alert>{error}</Alert>
        <Link to="/orders">Back to order history</Link>
      </section>
    );
  }

  const failed = order.status === "Payment Failed";

  return (
    <section className="page">
      <Link to="/orders" className="back-link">
        ← Back to order history
      </Link>
      <h1>Order {order.order_number}</h1>

      {location.state?.justPlaced && !failed && <Alert type="success">Thank you! Your order has been placed.</Alert>}
      {failed && (
        <Alert type="error">
          Payment failed: {order.failure_reason ?? "the payment could not be completed"}. Your order is saved; you can
          retry the payment.
        </Alert>
      )}
      <Alert>{retryError}</Alert>

      <dl className="order-meta">
        <dt>Date</dt>
        <dd>{formatDate(order.created_at)}</dd>
        <dt>Status</dt>
        <dd>
          <StatusBadge status={order.status} />
        </dd>
        <dt>Payment</dt>
        <dd>
          {order.payment_method} · <StatusBadge status={order.payment_status} />
        </dd>
        {order.payment_reference && (
          <>
            <dt>Reference</dt>
            <dd>{order.payment_reference}</dd>
          </>
        )}
      </dl>

      <OrderItemsTable items={order.items} total={order.total_amount} />

      {failed && (
        <div className="form-actions">
          <button type="button" className="btn btn-primary" onClick={handleRetry} disabled={retrying}>
            {retrying ? "Retrying payment..." : "Retry Payment"}
          </button>
        </div>
      )}
    </section>
  );
}
