/** Shown for any URL that matches no route. */
import { Link } from "react-router-dom";

export default function NotFoundPage() {
  return (
    <section className="page narrow">
      <h1>Page not found</h1>
      <p>
        The page you are looking for doesn&apos;t exist. <Link to="/">Go to products</Link>
      </p>
    </section>
  );
}
