/**
 * Checkout page: review the order, choose a payment method (Credit Card or Cash on Delivery)
 * and place the order with POST /api/orders/checkout.
 *
 * - Place Order is disabled while the request runs (no double orders on a double click).
 * - Credit Card: the backend charges the payment gateway. If that fails, the order is saved
 *   as "Payment Failed" and can be paid again from its details page (Retry Payment).
 * - Cash on Delivery: confirmed at once, paid on delivery.
 */
import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { PAYMENT_METHODS, placeOrder } from "../api/orderApi";
import Alert, { errorText } from "../components/common/Alert";
import OrderItemsTable from "../components/orders/OrderItemsTable";
import { useCart } from "../context/CartContext";

export default function CheckoutPage() {
  const { cart, loading, refreshCart } = useCart();
  const navigate = useNavigate();
  const [paymentMethod, setPaymentMethod] = useState(PAYMENT_METHODS.CREDIT_CARD);
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState("");

  if (!loading && cart.items.length === 0 && !submitting) return <Navigate to="/cart" replace />;

  async function handlePlaceOrder() {
    setSubmitting(true);
    setServerError("");
    try {
      const order = await placeOrder(paymentMethod);
      await refreshCart(); // the backend emptied the cart
      navigate(`/orders/${order.id}`, { state: { justPlaced: true } });
    } catch (error) {
      setServerError(errorText(error)); // e.g. 409 out of stock: nothing was changed
      setSubmitting(false);
    }
  }

  return (
    <section className="page narrow">
      <h1>Checkout</h1>
      <Alert>{serverError}</Alert>

      <h2>Review your order</h2>
      <OrderItemsTable items={cart.items} total={cart.total} />

      <fieldset className="payment-methods" disabled={submitting}>
        <legend>Payment method</legend>
        {Object.values(PAYMENT_METHODS).map((method) => (
          <label key={method} className="radio">
            <input
              type="radio"
              name="paymentMethod"
              value={method}
              checked={paymentMethod === method}
              onChange={(event) => setPaymentMethod(event.target.value)}
            />
            {method}
          </label>
        ))}
      </fieldset>

      <div className="form-actions">
        <button type="button" className="btn btn-success" onClick={handlePlaceOrder} disabled={submitting}>
          {submitting ? "Placing order..." : "Place Order"}
        </button>
        <Link to="/cart" className="btn btn-outline">
          Back to Cart
        </Link>
      </div>
    </section>
  );
}
