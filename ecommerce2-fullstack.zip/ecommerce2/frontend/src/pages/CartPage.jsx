/**
 * Cart page: cart lines with quantity, price, Remove; total amount and Checkout.
 *
 * - Totals come from the backend after every change, so they always update automatically.
 * - Checkout is enabled only if the cart is not empty (and every line is still available).
 */
import { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import Alert from "../components/common/Alert";
import Loader from "../components/common/Loader";
import CartItemRow from "../components/cart/CartItemRow";
import CartSummary from "../components/cart/CartSummary";
import { useCart } from "../context/CartContext";

export default function CartPage() {
  const { cart, loading, error, refreshCart, updateItem, removeItem } = useCart();
  const navigate = useNavigate();

  // Fresh prices and stock every time the page opens.
  useEffect(() => {
    refreshCart();
  }, [refreshCart]);

  const isEmpty = cart.items.length === 0;
  const allAvailable = cart.items.every((item) => item.available);

  if (loading && isEmpty) return <Loader text="Loading your cart..." />;

  return (
    <section className="page">
      <h1>Your Cart</h1>
      <Alert>{error}</Alert>

      {isEmpty ? (
        <p className="empty-state">
          Your cart is empty. <Link to="/">Browse products</Link>
        </p>
      ) : (
        <>
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Price</th>
                  <th>Qty</th>
                  <th>Subtotal</th>
                  <th aria-label="Actions" />
                </tr>
              </thead>
              <tbody>
                {cart.items.map((item) => (
                  <CartItemRow key={item.id} item={item} onUpdate={updateItem} onRemove={removeItem} />
                ))}
              </tbody>
            </table>
          </div>
          {!allAvailable && (
            <Alert type="warning">Some items are no longer available in that quantity. Update or remove them to check out.</Alert>
          )}
        </>
      )}

      <CartSummary
        totalItems={cart.total_items}
        total={cart.total}
        canCheckout={!isEmpty && allAvailable}
        onCheckout={() => navigate("/checkout")}
      />
    </section>
  );
}
