/**
 * Order history page: the logged-in user's past orders (GET /api/orders/me returns ONLY
 * their own orders - the backend filters by the token's user).
 * No orders -> "No orders found."
 */
import { useEffect, useState } from "react";
import { fetchMyOrders } from "../api/orderApi";
import Alert, { errorText } from "../components/common/Alert";
import Loader from "../components/common/Loader";
import OrderListItem from "../components/orders/OrderListItem";

export default function OrderHistoryPage() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchMyOrders()
      .then(setOrders)
      .catch((err) => setError(errorText(err)))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Loader text="Loading your orders..." />;

  return (
    <section className="page">
      <h1>Order History</h1>
      <Alert>{error}</Alert>
      {!error && orders.length === 0 && <p className="empty-state">No orders found.</p>}
      <div className="order-list">
        {orders.map((order) => (
          <OrderListItem key={order.id} order={order} />
        ))}
      </div>
    </section>
  );
}
