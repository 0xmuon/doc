/**
 * Login page: email and password.
 *
 * - Login is enabled only when both fields are valid, and disabled while the request runs.
 * - Wrong credentials -> the server's 401 message is shown.
 * - After login the user returns to the page they wanted (e.g. /cart), or to the products.
 */
import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import Alert, { errorText } from "../components/common/Alert";
import FormField from "../components/common/FormField";
import { useAuth } from "../context/AuthContext";
import { useForm } from "../hooks/useForm";
import { validateLoginForm } from "../utils/validators";

const EMPTY_FORM = { email: "", password: "" };

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const form = useForm(EMPTY_FORM, validateLoginForm);
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState("");

  const successMessage = location.state?.message ?? "";
  const returnTo = location.state?.from ?? "/";

  async function handleSubmit(event) {
    event.preventDefault();
    form.touchAll();
    if (!form.isValid) return;

    setSubmitting(true);
    setServerError("");
    try {
      await login(form.values);
      navigate(returnTo, { replace: true });
    } catch (error) {
      setServerError(error.status === 401 ? "Invalid email or password" : errorText(error));
    } finally {
      setSubmitting(false);
    }
  }

  function handleReset() {
    form.reset();
    setServerError("");
  }

  return (
    <section className="page auth-page">
      <form className="auth-card" onSubmit={handleSubmit} noValidate>
        <h1>Login</h1>
        {!serverError && <Alert type="success">{successMessage}</Alert>}
        <Alert>{serverError}</Alert>

        <FormField
          label="Email address"
          name="email"
          type="email"
          value={form.values.email}
          error={form.visibleError("email")}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
          autoComplete="email"
        />
        <FormField
          label="Password"
          name="password"
          type="password"
          value={form.values.password}
          error={form.visibleError("password")}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
          autoComplete="current-password"
        />

        <div className="form-actions">
          <button type="submit" className="btn btn-primary" disabled={!form.isValid || submitting}>
            {submitting ? "Logging in..." : "Login"}
          </button>
          <button type="button" className="btn btn-outline" onClick={handleReset} disabled={submitting}>
            Reset
          </button>
        </div>
        <p className="auth-switch">
          Don&apos;t have an account? <Link to="/register">Register</Link>
        </p>
      </form>
    </section>
  );
}
