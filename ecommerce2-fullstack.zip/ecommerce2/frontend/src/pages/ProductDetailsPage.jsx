/**
 * Product details page: everything about one product, with a quantity box and Add to Cart.
 * GET /api/products/{id}: 404 (unknown or inactive product) shows "Product not found".
 */
import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { fetchCategories, fetchProduct } from "../api/productApi";
import Alert, { errorText } from "../components/common/Alert";
import Loader from "../components/common/Loader";
import { useAddToCart } from "../hooks/useAddToCart";
import { formatPrice, initials } from "../utils/format";
import { validateQuantity } from "../utils/validators";

export default function ProductDetailsPage() {
  const { productId } = useParams();
  // The loaded product, remembered with the id it belongs to ("loading" = not loaded for this id yet).
  const [result, setResult] = useState({ id: null, product: null, categoryName: "", error: "" });
  const [quantity, setQuantity] = useState("1");
  const [adding, setAdding] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });
  const addToCart = useAddToCart();

  useEffect(() => {
    let ignore = false;
    Promise.all([fetchProduct(productId), fetchCategories()])
      .then(([product, categories]) => {
        if (ignore) return;
        const categoryName = categories.find((category) => category.id === product.category_id)?.name ?? "";
        setResult({ id: productId, product, categoryName, error: "" });
      })
      .catch((err) => {
        if (ignore) return;
        const error = err.status === 404 ? "Product not found." : errorText(err);
        setResult({ id: productId, product: null, categoryName: "", error });
      });
    return () => {
      ignore = true;
    };
  }, [productId]);

  const { product, categoryName, error } = result;
  const loading = result.id !== productId;

  if (loading) return <Loader text="Loading product..." />;
  if (error || !product) {
    return (
      <section className="page narrow">
        <Alert>{error || "Product not found."}</Alert>
        <Link to="/">Back to products</Link>
      </section>
    );
  }

  const inStock = product.stock > 0;
  const quantityError = inStock ? validateQuantity(quantity, product.stock) : "";

  async function handleAdd() {
    setAdding(true);
    setMessage({ type: "", text: "" });
    try {
      if (await addToCart(product, Number(quantity))) setMessage({ type: "success", text: "Added to cart" });
    } catch (err) {
      setMessage({ type: "error", text: errorText(err) });
    } finally {
      setAdding(false);
    }
  }

  return (
    <section className="page">
      <Link to="/" className="back-link">
        ← Back to products
      </Link>
      <div className="details">
        <div className="details-thumb">{initials(product.name)}</div>
        <div>
          <span className="product-category">{categoryName || "Uncategorised"}</span>
          <h1>{product.name}</h1>
          <p className="product-price large">{formatPrice(product.price)}</p>
          <p>{product.description || "No description available."}</p>
          <dl className="details-list">
            <dt>SKU</dt>
            <dd>{product.sku}</dd>
            <dt>Availability</dt>
            <dd>{inStock ? `${product.stock} in stock` : "Out of Stock"}</dd>
          </dl>

          {inStock ? (
            <div className="details-actions">
              <input
                type="number"
                min="1"
                max={product.stock}
                className={quantityError ? "input qty-input input-invalid" : "input qty-input"}
                value={quantity}
                onChange={(event) => setQuantity(event.target.value)}
                aria-label="Quantity"
              />
              <button type="button" className="btn btn-primary" onClick={handleAdd} disabled={Boolean(quantityError) || adding}>
                {adding ? "Adding..." : "Add to Cart"}
              </button>
            </div>
          ) : (
            <button type="button" className="btn btn-disabled" disabled>
              Out of Stock
            </button>
          )}
          {quantityError && <p className="field-error">{quantityError}</p>}
          {message.text && <p className={`card-message card-message-${message.type}`}>{message.text}</p>}
        </div>
      </div>
    </section>
  );
}
