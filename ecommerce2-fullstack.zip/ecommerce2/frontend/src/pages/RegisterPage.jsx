/**
 * Register page: name, email and password, with the case study's validations.
 *
 * - Register is enabled only when every field is valid, and disabled while the request runs.
 * - Errors show under each field once it was touched (and all of them on submit).
 * - Server errors are shown too: e.g. 409 "Email ... is already registered" (uniqueness is
 *   checked against existing users by the backend).
 * - Reset clears every field.
 * On success the user is sent to the login page.
 */
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Alert, { errorText } from "../components/common/Alert";
import FormField from "../components/common/FormField";
import { useAuth } from "../context/AuthContext";
import { useForm } from "../hooks/useForm";
import { validateRegisterForm } from "../utils/validators";

const EMPTY_FORM = { name: "", email: "", password: "" };

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const form = useForm(EMPTY_FORM, validateRegisterForm);
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState("");
  const [serverFieldErrors, setServerFieldErrors] = useState({});

  async function handleSubmit(event) {
    event.preventDefault();
    form.touchAll();
    if (!form.isValid) return; // never send an invalid form

    setSubmitting(true);
    setServerError("");
    setServerFieldErrors({});
    try {
      await register(form.values);
      navigate("/login", { state: { message: "Registration successful. Please log in." } });
    } catch (error) {
      setServerError(errorText(error));
      // 409 duplicate email -> show it under the email field as well
      if (error.status === 409 && /email/i.test(error.message)) {
        setServerFieldErrors({ email: "This email is already registered" });
      } else {
        const { full_name: name, ...rest } = error.fieldErrors ?? {};
        setServerFieldErrors({ ...rest, ...(name ? { name } : {}) });
      }
    } finally {
      setSubmitting(false);
    }
  }

  function handleReset() {
    form.reset();
    setServerError("");
    setServerFieldErrors({});
  }

  function fieldError(name) {
    return form.visibleError(name) || serverFieldErrors[name] || "";
  }

  return (
    <section className="page auth-page">
      <form className="auth-card" onSubmit={handleSubmit} noValidate>
        <h1>Register</h1>
        <Alert>{serverError}</Alert>

        <FormField
          label="Full Name"
          name="name"
          value={form.values.name}
          error={fieldError("name")}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
          autoComplete="name"
        />
        <FormField
          label="Email address"
          name="email"
          type="email"
          value={form.values.email}
          error={fieldError("email")}
          onChange={(event) => {
            setServerFieldErrors((current) => ({ ...current, email: "" }));
            form.handleChange(event);
          }}
          onBlur={form.handleBlur}
          autoComplete="email"
        />
        <FormField
          label="Password"
          name="password"
          type="password"
          value={form.values.password}
          error={fieldError("password")}
          onChange={form.handleChange}
          onBlur={form.handleBlur}
          autoComplete="new-password"
        />
        <p className="hint">At least 8 characters with an uppercase letter, a lowercase letter, a number and a special character.</p>

        <div className="form-actions">
          <button type="submit" className="btn btn-primary" disabled={!form.isValid || submitting}>
            {submitting ? "Registering..." : "Register"}
          </button>
          <button type="button" className="btn btn-outline" onClick={handleReset} disabled={submitting}>
            Reset
          </button>
        </div>
        <p className="auth-switch">
          Already have an account? <Link to="/login">Login</Link>
        </p>
      </form>
    </section>
  );
}
