/**
 * Product listing page (the landing page): a search bar on top, then a grid of product cards.
 *
 * - The search is optional and filters by name or category as the user types. The text is
 *   debounced (300 ms) and sent to GET /api/products/search; empty text uses GET /api/products.
 * - The category dropdown narrows the list to one category.
 * - Every answer is stored with the search it belongs to (`key`). "Loading" simply means
 *   "the stored answer is not for the current search yet", and answers to old searches are
 *   ignored, so a slow early response can't overwrite what the user typed last.
 */
import { useEffect, useMemo, useState } from "react";
import { fetchCategories, fetchProducts, searchProducts } from "../api/productApi";
import Alert, { errorText } from "../components/common/Alert";
import Loader from "../components/common/Loader";
import CategoryFilter from "../components/products/CategoryFilter";
import ProductCard from "../components/products/ProductCard";
import SearchBar from "../components/products/SearchBar";
import { useAddToCart } from "../hooks/useAddToCart";
import { useDebouncedValue } from "../hooks/useDebouncedValue";

export default function ProductListPage() {
  const [searchText, setSearchText] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [categories, setCategories] = useState([]);
  const [categoryError, setCategoryError] = useState("");
  const [result, setResult] = useState({ key: null, products: [], error: "" });
  const debouncedText = useDebouncedValue(searchText.trim(), 300);
  const addToCart = useAddToCart();

  const searchKey = `${debouncedText}|${categoryId}`;
  const loading = result.key !== searchKey;

  // Categories: once, for the dropdown and the names on the cards.
  useEffect(() => {
    fetchCategories()
      .then(setCategories)
      .catch((err) => setCategoryError(errorText(err)));
  }, []);

  // Products: again whenever the (debounced) search text or the category changes.
  useEffect(() => {
    let ignore = false;
    const request = debouncedText
      ? searchProducts({ text: debouncedText, categoryId })
      : fetchProducts({ categoryId });
    request
      .then((products) => !ignore && setResult({ key: searchKey, products, error: "" }))
      .catch((err) => !ignore && setResult({ key: searchKey, products: [], error: errorText(err) }));
    return () => {
      ignore = true;
    };
  }, [debouncedText, categoryId, searchKey]);

  const categoryNames = useMemo(
    () => Object.fromEntries(categories.map((category) => [category.id, category.name])),
    [categories],
  );

  return (
    <section className="page">
      <div className="toolbar">
        <SearchBar value={searchText} onChange={setSearchText} />
        <CategoryFilter categories={categories} value={categoryId} onChange={setCategoryId} />
      </div>

      <Alert>{result.error || categoryError}</Alert>
      {loading && <Loader text="Loading products..." />}
      {!loading && !result.error && result.products.length === 0 && <p className="empty-state">No products found.</p>}

      {!loading && (
        <div className="product-grid">
          {result.products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              categoryName={categoryNames[product.category_id]}
              onAddToCart={addToCart}
            />
          ))}
        </div>
      )}
    </section>
  );
}
