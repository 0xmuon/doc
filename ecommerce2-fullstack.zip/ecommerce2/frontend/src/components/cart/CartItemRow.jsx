/**
 * CartItemRow: one cart line - product, price, quantity input, subtotal, Remove.
 *
 * Quantity validation (case study): positive whole number, not above the available stock.
 * An invalid value shows an error and is NOT sent. A valid change is sent to the backend
 * 500 ms after the user stops typing; the totals then update from the server's answer.
 */
import { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { formatPrice } from "../../utils/format";
import { validateQuantity } from "../../utils/validators";
import { errorText } from "../common/Alert";

export default function CartItemRow({ item, onUpdate, onRemove }) {
  const [quantity, setQuantity] = useState(String(item.quantity));
  const [syncedQuantity, setSyncedQuantity] = useState(item.quantity);
  const [busy, setBusy] = useState(false);
  const [serverError, setServerError] = useState("");

  const validationError = validateQuantity(quantity, item.stock);

  // Keep the input in step when the server's quantity changes (e.g. after a re-load).
  // (Adjusting state while rendering is React's recommended way; an effect would render twice.)
  if (item.quantity !== syncedQuantity) {
    setSyncedQuantity(item.quantity);
    setQuantity(String(item.quantity));
  }

  // Debounced auto-save of a valid, changed quantity.
  useEffect(() => {
    if (validationError || Number(quantity) === item.quantity) return undefined;
    const timer = setTimeout(async () => {
      setBusy(true);
      setServerError("");
      try {
        await onUpdate(item.id, Number(quantity));
      } catch (error) {
        setServerError(errorText(error));
      } finally {
        setBusy(false);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [quantity, validationError, item.id, item.quantity, onUpdate]);

  async function handleRemove() {
    setBusy(true);
    setServerError("");
    try {
      await onRemove(item.id);
    } catch (error) {
      setServerError(errorText(error));
      setBusy(false);
    }
  }

  return (
    <tr>
      <td>
        <span className="cart-product">{item.product_name}</span>
        {!item.available && <span className="field-error">Not available in this quantity</span>}
      </td>
      <td>{formatPrice(item.unit_price)}</td>
      <td>
        <input
          type="number"
          min="1"
          max={item.stock}
          step="1"
          className={validationError ? "input qty-input input-invalid" : "input qty-input"}
          value={quantity}
          onChange={(event) => setQuantity(event.target.value)}
          aria-label={`Quantity of ${item.product_name}`}
          disabled={busy}
        />
        {(validationError || serverError) && <p className="field-error">{validationError || serverError}</p>}
      </td>
      <td>{formatPrice(item.line_total)}</td>
      <td>
        <button type="button" className="btn btn-danger btn-small" onClick={handleRemove} disabled={busy}>
          Remove
        </button>
      </td>
    </tr>
  );
}

export const cartItemShape = PropTypes.shape({
  id: PropTypes.number.isRequired,
  product_id: PropTypes.number.isRequired,
  product_name: PropTypes.string.isRequired,
  unit_price: PropTypes.number.isRequired,
  quantity: PropTypes.number.isRequired,
  stock: PropTypes.number.isRequired,
  line_total: PropTypes.number.isRequired,
  available: PropTypes.bool.isRequired,
});

CartItemRow.propTypes = {
  item: cartItemShape.isRequired,
  onUpdate: PropTypes.func.isRequired,
  onRemove: PropTypes.func.isRequired,
};
