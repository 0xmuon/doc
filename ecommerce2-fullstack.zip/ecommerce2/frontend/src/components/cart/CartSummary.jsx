/** CartSummary: item count, total amount and the Checkout button (enabled only if the cart isn't empty). */
import PropTypes from "prop-types";
import { formatPrice } from "../../utils/format";

export default function CartSummary({ totalItems, total, canCheckout, onCheckout }) {
  return (
    <div className="cart-summary">
      <p>
        Items: <strong>{totalItems}</strong>
      </p>
      <p className="cart-total">
        Total: <strong>{formatPrice(total)}</strong>
      </p>
      <button type="button" className="btn btn-success" onClick={onCheckout} disabled={!canCheckout}>
        Checkout
      </button>
    </div>
  );
}

CartSummary.propTypes = {
  totalItems: PropTypes.number.isRequired,
  total: PropTypes.number.isRequired,
  canCheckout: PropTypes.bool.isRequired,
  onCheckout: PropTypes.func.isRequired,
};
