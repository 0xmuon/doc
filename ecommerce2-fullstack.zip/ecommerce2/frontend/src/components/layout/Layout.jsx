/**
 * Layout: the page frame shared by every route.
 * Header and Footer stay; <Outlet /> is the Main Content area where the current page renders.
 */
import { Outlet } from "react-router-dom";
import Footer from "./Footer";
import Header from "./Header";

export default function Layout() {
  return (
    <div className="app-shell">
      <Header />
      <main className="main-content">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
