/**
 * Menu: links to the different sections of the app. NavLink highlights the current page.
 * Logged-out users see Login/Register; customers see Cart and Orders.
 */
import { NavLink } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

const linkClass = ({ isActive }) => (isActive ? "menu-link active" : "menu-link");

export default function Menu() {
  const { isLoggedIn, isCustomer } = useAuth();

  return (
    <nav className="menu" aria-label="Main navigation">
      <NavLink to="/" end className={linkClass}>
        Products
      </NavLink>
      {isCustomer && (
        <>
          <NavLink to="/cart" className={linkClass}>
            Cart
          </NavLink>
          <NavLink to="/orders" className={linkClass}>
            Orders
          </NavLink>
        </>
      )}
      {!isLoggedIn && (
        <>
          <NavLink to="/login" className={linkClass}>
            Login
          </NavLink>
          <NavLink to="/register" className={linkClass}>
            Register
          </NavLink>
        </>
      )}
    </nav>
  );
}
