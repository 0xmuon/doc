/** Footer (bottom of every page): auxiliary links, copyright and contact details. */
import { Link } from "react-router-dom";
import Icon from "../common/Icon";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <h3 className="footer-title">ABC Shop</h3>
          <p>Your one-stop shop for the latest products and unbeatable deals. Fast shipping and 24/7 support.</p>
        </div>
        <div>
          <h3 className="footer-title">Shop</h3>
          <Link to="/">All Products</Link>
          <Link to="/cart">Cart</Link>
          <Link to="/orders">My Orders</Link>
        </div>
        <div>
          <h3 className="footer-title">Customer Service</h3>
          <span>Help Center</span>
          <span>Returns</span>
          <span>Shipping</span>
        </div>
        <div>
          <h3 className="footer-title">Contact</h3>
          <span className="footer-contact">
            <Icon name="mail" size={16} /> support@abcshop.example
          </span>
          <span className="footer-contact">
            <Icon name="phone" size={16} /> +91 98765 43210
          </span>
        </div>
      </div>
      <div className="container footer-bottom">© {new Date().getFullYear()} ABC Shop. All rights reserved.</div>
    </footer>
  );
}
