/**
 * Header (top of every page): brand name, site navigation (Menu) and the profile icon.
 * The cart icon shows how many items are in the cart.
 */
import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { useCart } from "../../context/CartContext";
import Icon from "../common/Icon";
import Menu from "./Menu";

export default function Header() {
  const { user, isCustomer, logout } = useAuth();
  const { cart } = useCart();
  const navigate = useNavigate();
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef(null);

  // Close the profile dropdown when the user clicks anywhere else.
  useEffect(() => {
    function handleClick(event) {
      if (profileRef.current && !profileRef.current.contains(event.target)) setProfileOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  function handleLogout() {
    setProfileOpen(false);
    logout();
    navigate("/login");
  }

  return (
    <header className="header">
      <div className="container header-inner">
        <Link to="/" className="brand">
          <span className="brand-mark">A</span> ABC Shop
        </Link>

        <Menu />

        <div className="header-actions">
          {isCustomer && (
            <Link to="/cart" className="icon-button" aria-label={`Cart, ${cart.total_items} items`}>
              <Icon name="cart" />
              {cart.total_items > 0 && <span className="cart-count">{cart.total_items}</span>}
            </Link>
          )}

          <div className="profile" ref={profileRef}>
            <button
              type="button"
              className="icon-button"
              aria-label="Profile"
              aria-expanded={profileOpen}
              onClick={() => setProfileOpen((open) => !open)}
            >
              <Icon name="user" />
            </button>
            {profileOpen && (
              <div className="profile-menu">
                {user ? (
                  <>
                    <p className="profile-name">{user.full_name}</p>
                    <p className="profile-email">{user.email}</p>
                    {isCustomer && (
                      <Link to="/orders" onClick={() => setProfileOpen(false)}>
                        My Orders
                      </Link>
                    )}
                    <button type="button" className="link-button" onClick={handleLogout}>
                      Logout
                    </button>
                  </>
                ) : (
                  <>
                    <Link to="/login" onClick={() => setProfileOpen(false)}>
                      Login
                    </Link>
                    <Link to="/register" onClick={() => setProfileOpen(false)}>
                      Register
                    </Link>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
