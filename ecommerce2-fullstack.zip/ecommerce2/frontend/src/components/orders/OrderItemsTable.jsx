/** OrderItemsTable: every product of an order with quantity, price and subtotal. */
import PropTypes from "prop-types";
import { formatPrice } from "../../utils/format";

export default function OrderItemsTable({ items, total }) {
  return (
    <div className="table-wrap">
      <table className="table">
        <thead>
          <tr>
            <th>Product</th>
            <th>Qty</th>
            <th>Price</th>
            <th>Subtotal</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item, index) => (
            <tr key={`${item.product_id}-${index}`}>
              <td>{item.product_name}</td>
              <td>{item.quantity}</td>
              <td>{formatPrice(item.unit_price)}</td>
              <td>{formatPrice(item.line_total)}</td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <td colSpan={3} className="text-right">
              Total
            </td>
            <td>
              <strong>{formatPrice(total)}</strong>
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
}

export const orderItemShape = PropTypes.shape({
  product_id: PropTypes.number,
  product_name: PropTypes.string.isRequired,
  unit_price: PropTypes.number.isRequired,
  quantity: PropTypes.number.isRequired,
  line_total: PropTypes.number.isRequired,
});

OrderItemsTable.propTypes = {
  items: PropTypes.arrayOf(orderItemShape).isRequired,
  total: PropTypes.number.isRequired,
};
