/** OrderListItem: one row of the order history - number, date, total, status, View Details. */
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import { formatDate, formatPrice } from "../../utils/format";
import StatusBadge from "../common/StatusBadge";

export default function OrderListItem({ order }) {
  const itemCount = order.items.reduce((sum, item) => sum + item.quantity, 0);
  return (
    <article className="order-row">
      <div>
        <p className="order-number">Order {order.order_number}</p>
        <p className="muted">
          {formatDate(order.created_at)} · {itemCount} item(s)
        </p>
      </div>
      <StatusBadge status={order.status} />
      <p className="order-total">{formatPrice(order.total_amount)}</p>
      <Link to={`/orders/${order.id}`} className="btn btn-outline btn-small">
        View Details
      </Link>
    </article>
  );
}

OrderListItem.propTypes = {
  order: PropTypes.shape({
    id: PropTypes.number.isRequired,
    order_number: PropTypes.string.isRequired,
    status: PropTypes.string.isRequired,
    total_amount: PropTypes.number.isRequired,
    created_at: PropTypes.string.isRequired,
    items: PropTypes.arrayOf(PropTypes.shape({ quantity: PropTypes.number.isRequired })).isRequired,
  }).isRequired,
};
