/**
 * ProtectedRoute: wraps pages that need a logged-in user (cart, checkout, orders).
 *
 * - Still checking the stored token -> show a loader.
 * - Not logged in -> go to /login, remembering where the user wanted to go.
 * - Logged in with the wrong role (e.g. admin on the cart page) -> explain instead of
 *   letting the backend answer 403 on every call. The backend still enforces this itself.
 */
import PropTypes from "prop-types";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import Alert from "./Alert";
import Loader from "./Loader";

export default function ProtectedRoute({ children, roles }) {
  const { user, initializing } = useAuth();
  const location = useLocation();

  if (initializing) return <Loader text="Checking your session..." />;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  if (roles && !roles.includes(user.role)) {
    return (
      <section className="page narrow">
        <Alert type="warning">
          This page is for customer accounts. You are logged in as <strong>{user.role}</strong>.
        </Alert>
      </section>
    );
  }
  return children;
}

ProtectedRoute.propTypes = {
  children: PropTypes.node.isRequired,
  roles: PropTypes.arrayOf(PropTypes.string),
};
