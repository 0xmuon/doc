/** Alert: a coloured message box for server errors and success notes. */
import PropTypes from "prop-types";

export default function Alert({ type = "error", children }) {
  if (!children) return null;
  return (
    <div className={`alert alert-${type}`} role={type === "error" ? "alert" : "status"}>
      {children}
    </div>
  );
}

Alert.propTypes = {
  type: PropTypes.oneOf(["error", "success", "info", "warning"]),
  children: PropTypes.node,
};

/** The message for an ApiError, with the backend request id so failures can be traced. */
export function errorText(error) {
  if (!error) return "";
  return error.requestId ? `${error.message} (ref: ${error.requestId})` : error.message;
}
