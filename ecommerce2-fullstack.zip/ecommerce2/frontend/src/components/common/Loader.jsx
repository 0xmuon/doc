/** Loader: shown while data is being fetched. */
import PropTypes from "prop-types";

export default function Loader({ text = "Loading..." }) {
  return (
    <div className="loader" role="status">
      <span className="spinner" aria-hidden="true" />
      {text}
    </div>
  );
}

Loader.propTypes = {
  text: PropTypes.string,
};
