/** StatusBadge: order / payment status as a coloured pill ("Confirmed", "Payment Failed", ...). */
import PropTypes from "prop-types";

const TONES = {
  Confirmed: "success",
  Paid: "success",
  "Pending Payment": "warning",
  Pending: "warning",
  "Payment Failed": "danger",
  Failed: "danger",
};

export default function StatusBadge({ status }) {
  return <span className={`badge badge-${TONES[status] ?? "neutral"}`}>{status}</span>;
}

StatusBadge.propTypes = {
  status: PropTypes.string.isRequired,
};
