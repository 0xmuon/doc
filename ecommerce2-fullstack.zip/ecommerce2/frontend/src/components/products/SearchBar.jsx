/**
 * SearchBar: optional text input that filters products by name or category as the user types.
 * The page debounces the value before calling the API.
 */
import PropTypes from "prop-types";
import Icon from "../common/Icon";

export default function SearchBar({ value, onChange }) {
  return (
    <div className="search-bar">
      <Icon name="search" />
      <input
        type="search"
        placeholder="Search products by name or category..."
        value={value}
        maxLength={100}
        onChange={(event) => onChange(event.target.value)}
        aria-label="Search products"
      />
    </div>
  );
}

SearchBar.propTypes = {
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
};
