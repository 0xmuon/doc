/**
 * ProductCard: one product in the listing grid - name, category, price and Add to Cart.
 *
 * Validation from the case study:
 * - Add to Cart is enabled only if the product is in stock (stock > 0); otherwise the card
 *   shows "Out of Stock".
 * - No field is left blank: missing values show a fallback text.
 * The parent page decides what "add" does (call the cart API, or send a guest to login).
 */
import { useState } from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import { formatPrice, initials } from "../../utils/format";
import { errorText } from "../common/Alert";

export default function ProductCard({ product, categoryName, onAddToCart }) {
  const [adding, setAdding] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });
  const inStock = product.stock > 0;

  async function handleAdd() {
    setAdding(true);
    setMessage({ type: "", text: "" });
    try {
      const added = await onAddToCart(product);
      if (added) setMessage({ type: "success", text: "Added to cart" });
    } catch (error) {
      setMessage({ type: "error", text: errorText(error) });
    } finally {
      setAdding(false);
    }
  }

  return (
    <article className="product-card">
      <Link to={`/products/${product.id}`} className="product-thumb" aria-label={`View ${product.name}`}>
        {initials(product.name)}
      </Link>
      <div className="product-body">
        <span className="product-category">{categoryName || "Uncategorised"}</span>
        <h3 className="product-name">
          <Link to={`/products/${product.id}`}>{product.name}</Link>
        </h3>
        <p className="product-description">{product.description || "No description available."}</p>
        <p className="product-price">{formatPrice(product.price)}</p>

        {inStock ? (
          <button type="button" className="btn btn-primary btn-block" onClick={handleAdd} disabled={adding}>
            {adding ? "Adding..." : "Add to Cart"}
          </button>
        ) : (
          <button type="button" className="btn btn-disabled btn-block" disabled>
            Out of Stock
          </button>
        )}
        {message.text && <p className={`card-message card-message-${message.type}`}>{message.text}</p>}
      </div>
    </article>
  );
}

export const productShape = PropTypes.shape({
  id: PropTypes.number.isRequired,
  sku: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  description: PropTypes.string,
  price: PropTypes.number.isRequired,
  stock: PropTypes.number.isRequired,
  category_id: PropTypes.number.isRequired,
});

ProductCard.propTypes = {
  product: productShape.isRequired,
  categoryName: PropTypes.string,
  onAddToCart: PropTypes.func.isRequired,
};
