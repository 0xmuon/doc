/** CategoryFilter: dropdown to show one category only ("" = all categories). */
import PropTypes from "prop-types";

export default function CategoryFilter({ categories, value, onChange }) {
  return (
    <select
      className="select"
      value={value}
      onChange={(event) => onChange(event.target.value)}
      aria-label="Filter by category"
    >
      <option value="">All categories</option>
      {categories.map((category) => (
        <option key={category.id} value={category.id}>
          {category.name}
        </option>
      ))}
    </select>
  );
}

CategoryFilter.propTypes = {
  categories: PropTypes.arrayOf(PropTypes.shape({ id: PropTypes.number.isRequired, name: PropTypes.string.isRequired }))
    .isRequired,
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
};
