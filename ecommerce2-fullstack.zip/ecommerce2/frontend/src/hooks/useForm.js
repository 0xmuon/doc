/**
 * useForm: a small reusable hook for controlled forms with validation.
 *
 * - `values` are kept in state; every keystroke calls handleChange.
 * - `errors` are recalculated from the values by `validate` on every render.
 * - A field shows its error once it was "touched" (left) or the form was submitted,
 *   so the user isn't shouted at before typing anything.
 * - `isValid` lets the page disable the submit button until every field is valid.
 * - `reset` sets every field back to blank (the "Reset" button).
 */
import { useCallback, useMemo, useState } from "react";

export function useForm(initialValues, validate) {
  const [values, setValues] = useState(initialValues);
  const [touched, setTouched] = useState({});

  const errors = useMemo(() => validate(values), [values, validate]);
  const isValid = Object.values(errors).every((message) => !message);

  const handleChange = useCallback((event) => {
    const { name, value } = event.target;
    setValues((current) => ({ ...current, [name]: value }));
  }, []);

  const handleBlur = useCallback((event) => {
    const { name } = event.target;
    setTouched((current) => ({ ...current, [name]: true }));
  }, []);

  /** Mark every field touched (on submit), so all messages show. */
  const touchAll = useCallback(() => {
    setTouched(Object.fromEntries(Object.keys(initialValues).map((name) => [name, true])));
  }, [initialValues]);

  const reset = useCallback(() => {
    setValues(initialValues);
    setTouched({});
  }, [initialValues]);

  /** The message to show under a field (empty until it was touched). */
  const visibleError = (name) => (touched[name] ? errors[name] : "");

  return { values, errors, isValid, handleChange, handleBlur, touchAll, reset, visibleError };
}
