/**
 * useAddToCart: what an "Add to Cart" button does, shared by the listing and details pages.
 *
 * - Guest -> send to the login page (and come back here afterwards). Returns false.
 * - Logged in, but not a customer (admin/support) -> error: only customers have a cart.
 * - Customer -> POST /api/cart/add through the CartContext. Returns true.
 */
import { useCallback } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";

export function useAddToCart() {
  const { isLoggedIn, isCustomer } = useAuth();
  const { addItem } = useCart();
  const navigate = useNavigate();
  const location = useLocation();

  return useCallback(
    async (product, quantity = 1) => {
      if (!isLoggedIn) {
        navigate("/login", { state: { from: location.pathname, message: "Please log in to add items to your cart." } });
        return false;
      }
      if (!isCustomer) throw new Error("Only customer accounts can add items to a cart.");
      await addItem(product.id, quantity);
      return true;
    },
    [isLoggedIn, isCustomer, addItem, navigate, location.pathname],
  );
}
