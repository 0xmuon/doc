/**
 * useDebouncedValue: returns `value` only after it stopped changing for `delayMs`.
 * The product search uses it so typing "head" sends ONE request, not four.
 */
import { useEffect, useState } from "react";

export function useDebouncedValue(value, delayMs = 300) {
  const [debounced, setDebounced] = useState(value);

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delayMs);
    return () => clearTimeout(timer); // a new keystroke cancels the previous timer
  }, [value, delayMs]);

  return debounced;
}
