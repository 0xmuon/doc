/**
 * App: the routes. Every page renders inside <Layout> (Header + Main Content + Footer).
 *
 *   /                 product listing + search    (public)
 *   /products/:id     product details             (public)
 *   /register, /login                             (public)
 *   /cart, /checkout, /orders, /orders/:id        (customers only, via ProtectedRoute)
 */
import { Route, Routes } from "react-router-dom";
import ProtectedRoute from "./components/common/ProtectedRoute";
import Layout from "./components/layout/Layout";
import CartPage from "./pages/CartPage";
import CheckoutPage from "./pages/CheckoutPage";
import LoginPage from "./pages/LoginPage";
import NotFoundPage from "./pages/NotFoundPage";
import OrderDetailsPage from "./pages/OrderDetailsPage";
import OrderHistoryPage from "./pages/OrderHistoryPage";
import ProductDetailsPage from "./pages/ProductDetailsPage";
import ProductListPage from "./pages/ProductListPage";
import RegisterPage from "./pages/RegisterPage";

const CUSTOMER_ONLY = ["customer"];

function customerPage(page) {
  return <ProtectedRoute roles={CUSTOMER_ONLY}>{page}</ProtectedRoute>;
}

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<ProductListPage />} />
        <Route path="products/:productId" element={<ProductDetailsPage />} />
        <Route path="register" element={<RegisterPage />} />
        <Route path="login" element={<LoginPage />} />
        <Route path="cart" element={customerPage(<CartPage />)} />
        <Route path="checkout" element={customerPage(<CheckoutPage />)} />
        <Route path="orders" element={customerPage(<OrderHistoryPage />)} />
        <Route path="orders/:orderId" element={customerPage(<OrderDetailsPage />)} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
