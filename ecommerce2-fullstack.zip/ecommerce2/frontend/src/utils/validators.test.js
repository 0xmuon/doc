// Unit tests for the validation rules. Run: npm test
import { describe, expect, it } from "vitest";
import {
  validateEmail,
  validateLoginForm,
  validateName,
  validateNewPassword,
  validateQuantity,
  validateRegisterForm,
} from "./validators";

describe("validateName", () => {
  it("requires a name", () => expect(validateName("  ")).toBe("Name is required"));
  it("needs 6 characters", () => expect(validateName("Aman")).toMatch(/at least 6/));
  it("allows letters only", () => expect(validateName("Kavya1")).toMatch(/letters only/));
  it("accepts a full name", () => expect(validateName("Kavya Iyer")).toBe(""));
});

describe("validateEmail", () => {
  it("requires an email", () => expect(validateEmail("")).toBe("Email is required"));
  it("rejects a bad format", () => expect(validateEmail("kavya@shop")).toMatch(/valid email/));
  it("accepts a valid email", () => expect(validateEmail("kavya@example.com")).toBe(""));
});

describe("validateNewPassword", () => {
  it.each([
    ["Ab1!", /at least 8/],
    ["abcdefg1!", /uppercase/],
    ["ABCDEFG1!", /lowercase/],
    ["Abcdefgh!", /number/],
    ["Abcdefg12", /special/],
  ])("rejects %s", (password, message) => expect(validateNewPassword(password)).toMatch(message));
  it("accepts a strong password", () => expect(validateNewPassword("Kavya@123")).toBe(""));
});

describe("validateQuantity", () => {
  it("rejects zero, negatives and decimals", () => {
    expect(validateQuantity("0", 5)).toMatch(/positive/);
    expect(validateQuantity("-1", 5)).toMatch(/positive/);
    expect(validateQuantity("1.5", 5)).toMatch(/positive/);
  });
  it("cannot exceed the stock", () => expect(validateQuantity("6", 5)).toBe("Only 5 in stock"));
  it("accepts a valid quantity", () => expect(validateQuantity("2", 5)).toBe(""));
});

describe("form validators", () => {
  it("returns one message per register field", () => {
    expect(validateRegisterForm({ name: "", email: "", password: "" })).toEqual({
      name: "Name is required",
      email: "Email is required",
      password: "Password is required",
    });
  });
  it("login only needs a password to be present", () => {
    expect(validateLoginForm({ email: "a@b.co", password: "x" })).toEqual({ email: "", password: "" });
  });
});
