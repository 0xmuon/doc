/** Display helpers: prices in rupees, readable dates. */

const priceFormatter = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" });
const dateFormatter = new Intl.DateTimeFormat("en-IN", { dateStyle: "medium" });

export function formatPrice(amount) {
  return priceFormatter.format(Number(amount) || 0);
}

/** The backend sends UTC timestamps; ones without a zone (SQLite) are treated as UTC. */
export function formatDate(isoText) {
  if (!isoText) return "";
  const hasZone = /[zZ]|[+-]\d\d:\d\d$/.test(isoText);
  return dateFormatter.format(new Date(hasZone ? isoText : `${isoText}Z`));
}

/** "Wireless Headphones" -> "WH": the product tile shows initials (the API has no images). */
export function initials(text) {
  return text
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word[0].toUpperCase())
    .join("");
}
