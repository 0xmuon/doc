/**
 * Form validation rules, exactly as the case study's "Validation Instructions" describe.
 * Each validator returns an error message, or "" when the value is valid.
 * They are plain functions, so they are easy to unit-test (validators.test.js).
 */

export const MAX_QUANTITY_PER_ITEM = Number(import.meta.env.VITE_MAX_QUANTITY_PER_ITEM) || 10;

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const NAME_PATTERN = /^[A-Za-z]+( [A-Za-z]+)*$/; // letters only; single spaces between words

/** Name: required, minimum 6 characters, letters only. */
export function validateName(value) {
  const name = value.trim();
  if (!name) return "Name is required";
  if (name.length < 6) return "Name must be at least 6 characters";
  if (!NAME_PATTERN.test(name)) return "Name can contain letters only";
  return "";
}

/** Email: required, valid format. (Uniqueness is checked by the server on submit.) */
export function validateEmail(value) {
  const email = value.trim();
  if (!email) return "Email is required";
  if (!EMAIL_PATTERN.test(email)) return "Enter a valid email address";
  return "";
}

/** Password (register): min 8, one uppercase, one lowercase, one number, one special character. */
export function validateNewPassword(value) {
  if (!value) return "Password is required";
  if (value.length < 8) return "Password must be at least 8 characters";
  if (!/[A-Z]/.test(value)) return "Password must include an uppercase letter";
  if (!/[a-z]/.test(value)) return "Password must include a lowercase letter";
  if (!/[0-9]/.test(value)) return "Password must include a number";
  if (!/[^A-Za-z0-9]/.test(value)) return "Password must include a special character";
  return "";
}

/** Password (login): required. */
export function validateRequiredPassword(value) {
  return value ? "" : "Password is required";
}

/** Cart quantity: a positive whole number, not above the stock or the per-product limit. */
export function validateQuantity(value, stock) {
  const text = String(value).trim();
  if (!text) return "Quantity is required";
  if (!/^\d+$/.test(text) || Number(text) < 1) return "Quantity must be a positive whole number";
  const quantity = Number(text);
  if (quantity > stock) return `Only ${stock} in stock`;
  if (quantity > MAX_QUANTITY_PER_ITEM) return `At most ${MAX_QUANTITY_PER_ITEM} per product`;
  return "";
}

/** Whole register form -> { name, email, password } error messages. */
export function validateRegisterForm(values) {
  return {
    name: validateName(values.name),
    email: validateEmail(values.email),
    password: validateNewPassword(values.password),
  };
}

/** Whole login form -> { email, password } error messages. */
export function validateLoginForm(values) {
  return {
    email: validateEmail(values.email),
    password: validateRequiredPassword(values.password),
  };
}
