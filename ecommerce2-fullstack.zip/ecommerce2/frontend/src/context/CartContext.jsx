/**
 * CartContext: the logged-in customer's cart, shared by the header badge, product cards,
 * the cart page and checkout.
 *
 * The backend is the source of truth: every action calls the API and replaces the local
 * cart with the cart the server returns (prices, totals and stock always come from the
 * server, never calculated from what the user typed).
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import PropTypes from "prop-types";
import { addToCart, fetchCart, removeCartItem, updateCartItem } from "../api/cartApi";
import { useAuth } from "./AuthContext";

const EMPTY_CART = { items: [], total_items: 0, total: 0 };

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const { isCustomer } = useAuth();
  const [cart, setCart] = useState(EMPTY_CART);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const refreshCart = useCallback(async () => {
    if (!isCustomer) {
      setCart(EMPTY_CART);
      return;
    }
    setLoading(true);
    setError("");
    try {
      setCart(await fetchCart());
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [isCustomer]);

  // Load the cart when a customer logs in.
  useEffect(() => {
    if (!isCustomer) return undefined;
    let ignore = false;
    fetchCart()
      .then((loaded) => !ignore && setCart(loaded))
      .catch((err) => !ignore && setError(err.message));
    return () => {
      ignore = true;
    };
  }, [isCustomer]);

  // Each action returns the server's new cart; errors are thrown to the caller to display.
  const addItem = useCallback(async (productId, quantity = 1) => {
    const updated = await addToCart(productId, quantity);
    setCart(updated);
    return updated;
  }, []);

  const updateItem = useCallback(async (cartItemId, quantity) => {
    const updated = await updateCartItem(cartItemId, quantity);
    setCart(updated);
    return updated;
  }, []);

  const removeItem = useCallback(
    async (cartItemId) => {
      await removeCartItem(cartItemId); // 204: no body, so reload the cart
      await refreshCart();
    },
    [refreshCart],
  );

  // After logout nobody has a cart: show an empty one.
  const visibleCart = isCustomer ? cart : EMPTY_CART;

  const value = useMemo(
    () => ({ cart: visibleCart, loading, error, refreshCart, addItem, updateItem, removeItem }),
    [visibleCart, loading, error, refreshCart, addItem, updateItem, removeItem],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

CartProvider.propTypes = {
  children: PropTypes.node.isRequired,
};

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used inside <CartProvider>");
  return context;
}
