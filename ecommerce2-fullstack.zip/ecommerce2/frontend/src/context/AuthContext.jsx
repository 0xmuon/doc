/**
 * AuthContext: who is logged in, shared with every component.
 *
 * - On page load: if a token is stored, GET /api/auth/me tells us who it belongs to.
 * - login(): POST /api/auth/login -> save tokens -> GET /api/auth/me.
 * - logout(): forget the tokens and the user.
 * - If the API client finds the session expired (refresh failed), it calls logout for us.
 *
 * Components read it with: const { user, login, logout } = useAuth();
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import PropTypes from "prop-types";
import { fetchCurrentUser, loginUser, registerUser } from "../api/authApi";
import { setSessionExpiredHandler, tokenStore } from "../api/client";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  // true until a stored token has been checked with the backend (no token -> nothing to check)
  const [initializing, setInitializing] = useState(() => Boolean(tokenStore.getAccess()));

  const logout = useCallback(() => {
    tokenStore.clear();
    setUser(null);
  }, []);

  // Restore the session after a page reload.
  useEffect(() => {
    setSessionExpiredHandler(logout);
    if (!tokenStore.getAccess()) return;
    fetchCurrentUser()
      .then(setUser)
      .catch(() => logout())
      .finally(() => setInitializing(false));
  }, [logout]);

  const login = useCallback(async (credentials) => {
    const tokens = await loginUser(credentials);
    tokenStore.save(tokens);
    const currentUser = await fetchCurrentUser();
    setUser(currentUser);
    return currentUser;
  }, []);

  const register = useCallback((form) => registerUser(form), []);

  const value = useMemo(
    () => ({
      user,
      initializing,
      isLoggedIn: user !== null,
      isCustomer: user?.role === "customer",
      login,
      logout,
      register,
    }),
    [user, initializing, login, logout, register],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

AuthProvider.propTypes = {
  children: PropTypes.node.isRequired,
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside <AuthProvider>");
  return context;
}
