/**
 * API client: the ONE place that talks HTTP to the FastAPI backend.
 *
 * - Adds `Authorization: Bearer <access token>` to protected calls.
 * - If the access token has expired (401), it calls POST /api/auth/refresh ONCE with the
 *   refresh token, saves the new pair and repeats the original request.
 * - Turns every backend error into an ApiError with a readable message, the HTTP status,
 *   the backend's request_id (for tracing) and per-field messages for 422 responses.
 */

// "" = same origin: requests go to the Vite dev server, which proxies /api to the backend.
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "";

const ACCESS_TOKEN_KEY = "abcshop.accessToken";
const REFRESH_TOKEN_KEY = "abcshop.refreshToken";

export class ApiError extends Error {
  /**
   * @param {string} message      readable message for the UI
   * @param {number} status       HTTP status (0 = server unreachable)
   * @param {string|null} requestId  backend request id, quoted in error messages
   * @param {Object<string,string>} fieldErrors  e.g. { email: "value is not a valid email" }
   */
  constructor(message, status, requestId = null, fieldErrors = {}) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.requestId = requestId;
    this.fieldErrors = fieldErrors;
  }
}

// ---- Token storage (localStorage keeps the user logged in across page reloads) ----------

export const tokenStore = {
  getAccess: () => localStorage.getItem(ACCESS_TOKEN_KEY),
  getRefresh: () => localStorage.getItem(REFRESH_TOKEN_KEY),
  save(tokens) {
    localStorage.setItem(ACCESS_TOKEN_KEY, tokens.access_token);
    localStorage.setItem(REFRESH_TOKEN_KEY, tokens.refresh_token);
  },
  clear() {
    localStorage.removeItem(ACCESS_TOKEN_KEY);
    localStorage.removeItem(REFRESH_TOKEN_KEY);
  },
};

// AuthContext registers a function here: "the session is over, log the user out".
let onSessionExpired = () => {};
export function setSessionExpiredHandler(handler) {
  onSessionExpired = handler;
}

// ---- Error parsing ----------------------------------------------------------------------

/** Backend error body: {"detail": "..." | [{loc, msg}, ...], "request_id": "..."} */
export function parseError(status, body) {
  const detail = body?.detail;
  const fieldErrors = {};
  let message = "Something went wrong. Please try again.";

  if (typeof detail === "string") {
    message = detail;
  } else if (Array.isArray(detail)) {
    // 422 from FastAPI validation: one entry per invalid field
    for (const problem of detail) {
      const field = problem.loc?.[problem.loc.length - 1];
      const text = String(problem.msg ?? "is invalid").replace(/^Value error, /, "");
      if (field) fieldErrors[field] = text;
    }
    message = Object.entries(fieldErrors)
      .map(([field, text]) => `${field}: ${text}`)
      .join("; ") || message;
  }
  return new ApiError(message, status, body?.request_id ?? null, fieldErrors);
}

async function readJson(response) {
  if (response.status === 204) return null;
  const text = await response.text();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

// ---- Refresh -----------------------------------------------------------------------------

let refreshing = null; // shared promise: many parallel 401s trigger ONE refresh call

async function refreshTokens() {
  const refreshToken = tokenStore.getRefresh();
  if (!refreshToken) return false;
  if (!refreshing) {
    refreshing = fetch(`${API_BASE_URL}/api/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: refreshToken }),
    })
      .then(async (response) => {
        if (!response.ok) return false;
        tokenStore.save(await response.json());
        return true;
      })
      .catch(() => false)
      .finally(() => {
        refreshing = null;
      });
  }
  return refreshing;
}

// ---- The request function ----------------------------------------------------------------

/**
 * @param {string} path  e.g. "/api/products"
 * @param {object} options
 * @param {string} [options.method="GET"]
 * @param {object} [options.body]   sent as JSON
 * @param {object} [options.form]   sent as a URL-encoded form (OAuth2 login)
 * @param {object} [options.query]  query string parameters; empty values are skipped
 * @param {boolean} [options.auth=true]  attach the access token
 */
export async function apiRequest(path, { method = "GET", body, form, query, auth = true } = {}, isRetry = false) {
  const url = new URL(`${API_BASE_URL}${path}`, window.location.origin);
  Object.entries(query ?? {}).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") url.searchParams.set(key, value);
  });

  const headers = {};
  let payload;
  if (form) {
    headers["Content-Type"] = "application/x-www-form-urlencoded";
    payload = new URLSearchParams(form);
  } else if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }
  const accessToken = tokenStore.getAccess();
  if (auth && accessToken) headers.Authorization = `Bearer ${accessToken}`;

  let response;
  try {
    response = await fetch(url, { method, headers, body: payload });
  } catch {
    throw new ApiError("Cannot reach the server. Is the backend running?", 0);
  }

  // Expired access token: refresh once, then repeat the same request.
  if (response.status === 401 && auth && accessToken && !isRetry) {
    if (await refreshTokens()) {
      return apiRequest(path, { method, body, form, query, auth }, true);
    }
    tokenStore.clear();
    onSessionExpired();
  }

  const data = await readJson(response);
  if (!response.ok) throw parseError(response.status, data);
  return data;
}
