/** Cart endpoints (backend: app/routes/cart.py). Customer token required. */
import { apiRequest } from "./client";

/** GET /api/cart -> { items: [...], total_items, total } */
export function fetchCart() {
  return apiRequest("/api/cart");
}

/** POST /api/cart/add - adding a product already in the cart increases its quantity. */
export function addToCart(productId, quantity = 1) {
  return apiRequest("/api/cart/add", { method: "POST", body: { product_id: productId, quantity } });
}

/** PUT /api/cart/update/{cart_item_id} - sets the NEW quantity. */
export function updateCartItem(cartItemId, quantity) {
  return apiRequest(`/api/cart/update/${cartItemId}`, { method: "PUT", body: { quantity } });
}

/** DELETE /api/cart/remove/{cart_item_id} - 204, no body. */
export function removeCartItem(cartItemId) {
  return apiRequest(`/api/cart/remove/${cartItemId}`, { method: "DELETE" });
}
