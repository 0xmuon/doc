/** Auth endpoints (backend: app/routes/auth.py). */
import { apiRequest } from "./client";

/** POST /api/auth/register - the form's "name" is the backend's full_name. */
export function registerUser({ name, email, password }) {
  return apiRequest("/api/auth/register", {
    method: "POST",
    auth: false,
    body: { full_name: name.trim(), email: email.trim(), password },
  });
}

/**
 * POST /api/auth/login - OAuth2 password flow: a FORM with "username" and "password".
 * The backend accepts an e-mail address in the "username" field.
 */
export function loginUser({ email, password }) {
  return apiRequest("/api/auth/login", {
    method: "POST",
    auth: false,
    form: { username: email.trim(), password },
  });
}

/** GET /api/auth/me - who the stored token belongs to. */
export function fetchCurrentUser() {
  return apiRequest("/api/auth/me");
}
