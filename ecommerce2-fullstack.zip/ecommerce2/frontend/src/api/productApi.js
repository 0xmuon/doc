/** Product and category endpoints (backend: app/routes/products.py). Public: no token needed. */
import { apiRequest } from "./client";

const PAGE_SIZE = 100; // the backend's maximum page size

/** GET /api/products?category_id= - active products. */
export function fetchProducts({ categoryId } = {}) {
  return apiRequest("/api/products", { auth: false, query: { category_id: categoryId, limit: PAGE_SIZE } });
}

/** GET /api/products/search?q=&category_id= - text matches name, description or category name. */
export function searchProducts({ text, categoryId } = {}) {
  return apiRequest("/api/products/search", {
    auth: false,
    query: { q: text, category_id: categoryId, limit: PAGE_SIZE },
  });
}

/** GET /api/products/{id} */
export function fetchProduct(productId) {
  return apiRequest(`/api/products/${productId}`, { auth: false });
}

/** GET /api/categories - active categories, used for names and the dropdown. */
export function fetchCategories() {
  return apiRequest("/api/categories", { auth: false });
}
