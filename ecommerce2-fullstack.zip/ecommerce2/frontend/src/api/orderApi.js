/** Order and payment endpoints (backend: app/routes/orders.py, payments.py). */
import { apiRequest } from "./client";

export const PAYMENT_METHODS = {
  CREDIT_CARD: "Credit Card",
  CASH_ON_DELIVERY: "Cash on Delivery",
};

/** POST /api/orders/checkout - turns the cart into an order. */
export function placeOrder(paymentMethod) {
  return apiRequest("/api/orders/checkout", { method: "POST", body: { payment_method: paymentMethod } });
}

/** GET /api/orders/me - only the logged-in user's orders, newest first. */
export function fetchMyOrders() {
  return apiRequest("/api/orders/me");
}

/** GET /api/orders/{id} - 403 if the order belongs to someone else. */
export function fetchOrder(orderId) {
  return apiRequest(`/api/orders/${orderId}`);
}

/** POST /api/payments/process - retry the payment of a "Payment Failed" order. */
export function retryPayment(orderId) {
  return apiRequest("/api/payments/process", { method: "POST", body: { order_id: orderId } });
}
