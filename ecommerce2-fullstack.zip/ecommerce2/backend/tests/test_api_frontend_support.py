"""
API tests for what the React frontend relies on: CORS, e-mail login, register without a
username, search by category name, stock in the cart, Cash on Delivery checkout.
"""

import pytest

from tests.conftest import create_category, create_product, create_user

pytestmark = [pytest.mark.anyio, pytest.mark.integration]


async def test_cors_allows_the_react_dev_server(client):
    response = await client.options(
        "/api/products",
        headers={"Origin": "http://localhost:5173", "Access-Control-Request-Method": "GET"},
    )

    assert response.headers["access-control-allow-origin"] == "http://localhost:5173"


async def test_register_with_name_email_password_only(client):
    response = await client.post(
        "/api/auth/register",
        json={"full_name": "Kavya Iyer", "email": "Kavya.R@Example.com", "password": "Kavya@123"},
    )

    assert response.status_code == 201
    assert response.json()["email"] == "kavya.r@example.com"
    assert response.json()["username"].startswith("kavya.r_")


async def test_login_with_email(client, db):
    await create_user(db, "anna", password="Anna@1234")

    response = await client.post("/api/auth/login", data={"username": "ANNA@example.com", "password": "Anna@1234"})

    assert response.status_code == 200
    assert response.json()["access_token"]


async def test_search_matches_category_name(client, db, category):
    books = await create_category(db, "Books")
    await create_product(db, books.id, sku="BOOK-001", name="Clean Code")
    await create_product(db, category.id, sku="ELEC-009", name="Speaker")

    response = await client.get("/api/products/search", params={"q": "book"})

    assert [p["sku"] for p in response.json()] == ["BOOK-001"]


async def test_cart_lines_include_stock(client, customer, product, login_as):
    login_as(customer)

    response = await client.post("/api/cart/add", json={"product_id": product.id, "quantity": 1})

    assert response.json()["items"][0]["stock"] == 10


async def test_cash_on_delivery_skips_the_gateway(client, customer, product, login_as, payment_gateway):
    login_as(customer)
    payment_gateway.mode = "down"  # would fail a card payment
    await client.post("/api/cart/add", json={"product_id": product.id, "quantity": 2})

    response = await client.post("/api/orders/checkout", json={"payment_method": "Cash on Delivery"})

    order = response.json()
    assert response.status_code == 201
    assert (order["status"], order["payment_status"], order["payment_method"]) == (
        "Confirmed",
        "Pending",
        "Cash on Delivery",
    )
    assert payment_gateway.charges == []
