# ECommerce2 — full stack

```
backend/    FastAPI API (JWT, Casbin, async checkout, payments)   -> see backend/README.md
frontend/   React (JSX) user interface                            -> see frontend/README.md
```

Start everything from `backend/`:

```bash
cd backend
docker compose up --build
docker compose exec api python -m app.seed
```

| URL | What |
|---|---|
| http://localhost:5173 | React app |
| http://localhost:8000/docs | API (Swagger) |
| http://localhost:9000/docs | fake payment / notification provider |
